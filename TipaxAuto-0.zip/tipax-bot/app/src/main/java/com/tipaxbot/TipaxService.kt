package com.tipaxbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.Toast
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.abs

const val SENDER_FALLBACK_STREET = "تهران شوش"   // اگر استعلام فرستنده جواب نداد
const val BUBBLE_WRAP_RIAL = "200000"             // ۲۰ هزار تومان
const val MIN_VALUE_RIAL = 10_000_000L            // حداقل ارزش مرسوله در فرم تیپاکس

class Job(val f: Map<String, String>, val delivery: String, val ptype: String, val pkg: String)

object Bridge {
    @Volatile var service: TipaxService? = null
    @Volatile var finished = false
}

class Fail(msg: String) : RuntimeException(msg)

class N(
    val node: AccessibilityNodeInfo,
    val text: String,
    val cls: String,
    val r: Rect,
    val clickable: Boolean,
    val checkable: Boolean = false,
    val checked: Boolean = false
) {
    val cx: Int get() = r.centerX()
    val cy: Int get() = r.centerY()
    val isEdit: Boolean get() = cls.endsWith("EditText")
}

fun fa(s: String?): String {
    if (s == null) return ""
    return s.replace('ي', 'ی').replace('ى', 'ی').replace('ك', 'ک')
        .replace('أ', 'ا').replace('إ', 'ا').replace('ؤ', 'و').replace('ئ', 'ی').replace('ة', 'ه')
        .replace("\u0640", "").replace(Regex("[\\u064B-\\u065F]"), "")
        .replace('\u200c', ' ').replace(Regex("\\s+"), " ").trim()
}

private val PLACEHOLDERS: Set<String> = listOf(
    "نام", "نام خانوادگی", "کد ملی", "کد مشتری", "شماره تلفن همراه", "شماره تلفن ثابت",
    "کد پستی فرستنده", "کد پستی گیرنده"
).map { fa(it) }.toSet()

class TipaxService : AccessibilityService() {

    private val main = Handler(Looper.getMainLooper())
    @Volatile private var worker: Thread? = null
    @Volatile private var stop = false
    private var W = 1080
    private var H = 2340

    override fun onServiceConnected() {
        super.onServiceConnected()
        Bridge.service = this
        val dm = resources.displayMetrics
        W = dm.widthPixels
        H = dm.heightPixels
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        Bridge.service = null
        stop = true
        return super.onUnbind(intent)
    }

    // ------------------------------------------------------------ entry
    fun startJob(job: Job) {
        if (worker?.isAlive == true) {
            toast("یک کار در حال اجراست")
            return
        }
        stop = false
        worker = Thread {
            try {
                run(job)
                Bridge.finished = true
                toast("✓ فرم مرسوله پر شد. حالا بارکد برچسب را اسکن کن؛ ثبت نهایی و پرداخت با خودت")
            } catch (e: InterruptedException) {
                toast("متوقف شد")
            } catch (e: Exception) {
                toast("✗ " + (e.message ?: e.toString()))
            }
        }.also { it.start() }
    }

    private fun toast(s: String) {
        main.post { Toast.makeText(applicationContext, s, Toast.LENGTH_LONG).show() }
    }

    private fun sleep(ms: Long) = Thread.sleep(ms)
    private fun checkStop() { if (stop) throw InterruptedException() }

    // ------------------------------------------------------------ screen reading
    private fun snapshot(): List<N> {
        val root = rootInActiveWindow ?: return emptyList()
        val out = ArrayList<N>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val r = Rect()
            n.getBoundsInScreen(r)
            val cls = n.className?.toString() ?: ""
            val isEdit = cls.endsWith("EditText")
            var t = if (n.isShowingHintText) "" else (n.text?.toString() ?: "")
            if (t.isEmpty() && !isEdit) t = n.contentDescription?.toString() ?: ""
            if (n.isVisibleToUser && !r.isEmpty) out.add(N(n, t, cls, r, n.isClickable, n.isCheckable, n.isChecked))
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return out
    }

    private fun find(
        text: String,
        contains: Boolean = true,
        clickable: Boolean? = null,
        nodes: List<N> = snapshot(),
        edit: Boolean = false
    ): List<N> {
        val t = fa(text)
        val vis = nodes.filter { n ->
            fa(n.text).isNotEmpty() &&
                n.cy > H * 0.04 && n.cy < H * 0.97 &&
                (edit || !n.isEdit) &&
                (clickable == null || n.clickable == clickable)
        }
        var hits = vis.filter { fa(it.text) == t }
        if (hits.isEmpty() && contains) hits = vis.filter { fa(it.text).contains(t) }
        return hits.sortedWith(compareBy({ it.r.top }, { -it.r.left }))
    }

    private fun edits(nodes: List<N> = snapshot()): List<N> = nodes.filter { it.isEdit }

    private fun isEmpty(e: N): Boolean = e.text.isBlank() || fa(e.text) in PLACEHOLDERS

    private fun wait(
        text: String,
        timeout: Long = 8000,
        clickable: Boolean? = null,
        contains: Boolean = true
    ): List<N> {
        val end = System.currentTimeMillis() + timeout
        while (System.currentTimeMillis() < end) {
            checkStop()
            val h = find(text, contains, clickable)
            if (h.isNotEmpty()) return h
            sleep(400)
        }
        return emptyList()
    }

    // ------------------------------------------------------------ actions
    private fun gesture(path: Path, dur: Long) {
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, dur)).build()
        val latch = CountDownLatch(1)
        val ok = dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { latch.countDown() }
            override fun onCancelled(gestureDescription: GestureDescription?) { latch.countDown() }
        }, null)
        if (ok) latch.await(3, TimeUnit.SECONDS)
        sleep(250)
    }

    private fun tap(x: Int, y: Int) {
        val p = Path()
        p.moveTo(x.toFloat(), y.toFloat())
        gesture(p, 60)
    }

    private fun swipeBy(dy: Int) {
        val y0 = (H * 0.8).toInt()
        val y1 = y0 - minOf(dy, (H * 0.6).toInt())
        val p = Path()
        p.moveTo((W / 2).toFloat(), y0.toFloat())
        p.lineTo((W / 2).toFloat(), y1.toFloat())
        gesture(p, 400)
        sleep(500)
    }

    private fun swipeRaw(y0: Int, y1: Int) {
        val p = Path()
        p.moveTo((W / 2).toFloat(), y0.toFloat())
        p.lineTo((W / 2).toFloat(), y1.toFloat())
        gesture(p, 300)
        sleep(400)
    }

    private fun tapText(text: String, timeout: Long = 8000, pick: Int = 0, contains: Boolean = true): N {
        val h = wait(text, timeout, contains = contains)
        if (h.isEmpty()) throw Fail("پیدا نشد: $text")
        val n = h[minOf(pick, h.size - 1)]
        tap(n.cx, n.cy)
        sleep(900)
        return n
    }

    private fun scrollTo(text: String, alignTop: Boolean = false, tries: Int = 14): N {
        var prev = ""
        for (i in 0 until tries) {
            checkStop()
            val ns = snapshot()
            val hit = find(text, nodes = ns)
            if (hit.isNotEmpty()) {
                var n = hit[0]
                if (alignTop && n.cy > H * 0.5) {
                    swipeBy((n.cy - H * 0.25).toInt())
                    n = find(text).firstOrNull() ?: n
                }
                return n
            }
            val sig = ns.joinToString("|") { it.text + it.r.top }
            if (sig == prev) break
            prev = sig
            swipeBy((H * 0.4).toInt())
        }
        throw Fail("پیدا نشد: $text")
    }

    private fun put(e: N, value: String) {
        tap(e.cx, e.cy)
        sleep(350)
        e.node.refresh()
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value)
        var ok = e.node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (!ok) {
            e.node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            sleep(200)
            ok = e.node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        }
        if (!ok) throw Fail("نوشتن در فیلد ممکن نشد")
        sleep(300)
    }

    private fun hideKb() {
        val shown = windows.any { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD }
        if (shown) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            sleep(500)
        }
    }

    private fun dismissDialogs(): Boolean {
        for (t in listOf("تایید", "ادامه", "OK", "باشه", "بستن", "بله")) {
            val h = find(t, contains = false)
            if (h.isNotEmpty()) {
                tap(h[0].cx, h[0].cy)
                sleep(500)
                return true
            }
        }
        return false
    }

    // ------------------------------------------------------------ field lookup
    private fun editBelow(label: String, scroll: Boolean = true): N {
        if (scroll) scrollTo(label, true)
        val ns = snapshot()
        val lab = find(label, nodes = ns).firstOrNull() ?: throw Fail("پیدا نشد: $label")
        val c = edits(ns).filter { it.r.top >= lab.r.bottom - 10 }
        return c.minByOrNull { it.r.top } ?: throw Fail("فیلد زیر «$label» پیدا نشد")
    }

    /** فیلدی که هم‌ردیف برچسب است (مثل قیمت‌های بسته‌بندی). */
    private fun editBeside(label: String): N {
        scrollTo(label, true)
        val ns = snapshot()
        val lab = find(label, nodes = ns).firstOrNull() ?: throw Fail("پیدا نشد: $label")
        val e = edits(ns).minByOrNull { abs(it.cy - lab.cy) } ?: throw Fail("فیلد کنار «$label» پیدا نشد")
        if (abs(e.cy - lab.cy) > 110) throw Fail("فیلد کنار «$label» پیدا نشد")
        return e
    }

    private fun addressGroup(label: String): Map<String, N> {
        scrollTo(label, true)
        val ns = snapshot()
        val lab = find(label, nodes = ns).firstOrNull() ?: throw Fail("پیدا نشد: $label")
        val es = edits(ns).filter { it.r.top >= lab.r.bottom - 10 }.sortedBy { it.r.top }
        val rows = ArrayList<MutableList<N>>()
        for (e in es) {
            if (rows.isNotEmpty() && abs(e.r.top - rows.last()[0].r.top) < 40) rows.last().add(e)
            else rows.add(mutableListOf(e))
        }
        val flat = rows.flatMap { row -> row.sortedByDescending { it.r.left } }   // راست به چپ
        val names = listOf("main", "sub", "alley", "plate", "unit", "address")
        val m = LinkedHashMap<String, N>()
        for (i in 0 until minOf(names.size, flat.size)) m[names[i]] = flat[i]
        return m
    }

    private fun tapNear(text: String, ref: N) {
        val hits = find(text, contains = false)
        if (hits.isEmpty()) throw Fail("پیدا نشد: $text")
        val n = hits.minByOrNull { abs(it.cy - ref.cy) }!!
        tap(n.cx, n.cy)
        sleep(800)
    }

    private fun goNext() {
        for (t in listOf("مرحله بعدی", "صفحه بعدی")) {
            try {
                scrollTo(t, tries = 6)
                tapText(t, timeout = 2000)
                return
            } catch (e: Fail) {
                continue
            }
        }
        throw Fail("دکمه بعدی پیدا نشد")
    }

    // ------------------------------------------------------------ screens
    private fun waitName(w: String, timeout: Long = 8000): Boolean {
        val end = System.currentTimeMillis() + timeout
        while (System.currentTimeMillis() < end) {
            checkStop()
            sleep(1000)
            val ns = snapshot()
            val lab = find("نام $w", nodes = ns).firstOrNull() ?: continue
            val e = edits(ns).filter { it.r.top >= lab.r.bottom - 10 }.minByOrNull { it.r.top }
            if (e != null && !isEmpty(e)) return true
        }
        return false
    }

    /** شماره -> استعلام -> (اگر جواب نداد) نام و نام‌خانوادگی از متن. خروجی: استعلام موفق بود؟ */
    private fun fillParty(sender: Boolean, name: String, family: String, mobile: String, postal: String): Boolean {
        val w = if (sender) "فرستنده" else "گیرنده"
        if (mobile.isEmpty()) throw Fail("موبایل $w خالی است")
        val lab = "شماره تلفن همراه $w"
        put(editBelow(lab), mobile)
        hideKb()
        tapNear("استعلام", editBelow(lab))
        val found = waitName(w)
        if (!found) {
            dismissDialogs()
            if (name.isNotEmpty()) { put(editBelow("نام $w"), name); hideKb() }
            if (family.isNotEmpty()) { put(editBelow("نام خانوادگی $w"), family); hideKb() }
        }
        if (postal.isNotEmpty()) {
            val e = editBelow("کد پستی $w")
            if (isEmpty(e)) { put(e, postal); hideKb() }
        }
        return found
    }

    private fun fillAddress(label: String, main: String? = null, plate: String? = null, unit: String? = null) {
        val items = listOf("main" to main, "alley" to " ", "plate" to plate, "unit" to unit)
        for ((key, value) in items) {
            if (value.isNullOrEmpty() && key != "alley") continue
            val g = addressGroup(label)
            val e = g[key] ?: continue
            put(e, value ?: "")
            hideKb()
        }
    }

    private fun pickCity(province: String, cities: List<String>, opened: Boolean = false): String? {
        if (!opened) {
            scrollTo("انتخاب شهر", true)
            tapText("انتخاب شهر")
            sleep(1200)
        }
        for (city in cities.filter { it.isNotBlank() }) {
            checkStop()
            val es = edits()
            if (es.isEmpty()) throw Fail("صفحه‌ی جستجوی شهر باز نشد")
            put(es[0], city)
            sleep(1500)
            val ns = snapshot()
            val hits = find(city, contains = false, nodes = ns)
            if (hits.isNotEmpty()) {
                val prov = if (province.isNotEmpty()) find(province, contains = false, nodes = ns) else emptyList()
                val best = hits.firstOrNull { h -> prov.any { abs(h.cy - it.cy) < 45 } } ?: hits[0]
                tap(best.cx, best.cy)
                sleep(1000)
                return city
            }
        }
        return null
    }

    // ------------------------------------------------------------ warnings / pickers
    /**
     * بعد از «مرحله بعدی» گیرنده (طبق فیلم) دو هشدار پشت‌سرهم می‌آید:
     *  ۱) «هشدار اعتبارسنجی آدرس» ← دکمه‌ی «تأیید»
     *  ۲) «مقصد انتخاب شده <<...>> می‌باشد. آیا ادامه می‌دهید؟» ← دکمه‌ی «ادامه»
     * تا وقتی صفحه‌ی بعد ([untilText]) پیدا شود، هر کدام را که بود می‌زند.
     */
    private fun passWarnings(untilText: String, timeout: Long = 20000): Boolean {
        val end = System.currentTimeMillis() + timeout
        while (System.currentTimeMillis() < end) {
            checkStop()
            sleep(600)
            val ns = snapshot()
            val btn = listOf("تایید", "ادامه").firstNotNullOfOrNull { t ->
                find(t, contains = false, nodes = ns).firstOrNull()
            }
            if (btn != null) {
                tap(btn.cx, btn.cy)
                sleep(800)
                continue
            }
            if (find(untilText, nodes = ns).isNotEmpty()) return true
        }
        return find(untilText).isNotEmpty()
    }

    private fun pickerOpen(ns: List<N> = snapshot()): Boolean =
        find("CANCEL", contains = false, nodes = ns).isNotEmpty() &&
            find("OK", contains = false, nodes = ns).isNotEmpty()

    private fun drag(x: Int, y0: Int, y1: Int, dur: Long = 350) {
        val p = Path()
        p.moveTo(x.toFloat(), y0.toFloat())
        p.lineTo(x.toFloat(), y1.toFloat())
        gesture(p, dur)
        sleep(350)
    }

    /**
     * پنجره‌ی چرخان (OK / CANCEL) را روی آیتم [target] می‌برد و OK می‌زند.
     * آیتم وسط = انتخاب‌شده؛ آیتم کناری با یک لمس یک قدم می‌آید؛ اگر دیده نشد چرخ را می‌کشد.
     */
    private fun selectInPicker(target: String) {
        val t = fa(target)
        var dir = -1                  // -1: انگشت به بالا ← آیتم‌های بعدی
        var prevSig = ""
        var same = 0
        var reversals = 0
        var tapStuck = 0
        for (i in 0 until 80) {
            checkStop()
            val ns = snapshot()
            val ok = find("OK", contains = false, nodes = ns).firstOrNull()
                ?: throw Fail("پنجره‌ی انتخاب بسته شد")
            val cancel = find("CANCEL", contains = false, nodes = ns).firstOrNull()
            val items = ns.filter {
                it.node != ok.node && it.node != cancel?.node &&
                    fa(it.text).isNotEmpty() && it.r.bottom <= ok.r.top + 8
            }.sortedBy { it.cy }
            val center = items.firstOrNull { it.isEdit } ?: items.getOrNull(items.size / 2)
            val hit = items.firstOrNull { fa(it.text) == t }
            if (hit != null) {
                if (center == null || abs(hit.cy - center.cy) < 45) {
                    tap(ok.cx, ok.cy)
                    sleep(1000)
                    return
                }
                if (tapStuck < 3) {                       // آیتم کناری را لمس کن تا وسط بیاید
                    tap(hit.cx, hit.cy)
                    sleep(450)
                    tapStuck++
                    continue
                }
            }
            tapStuck = 0
            val itemH = if (items.size >= 2)
                maxOf(90, abs(items.last().cy - items.first().cy) / (items.size - 1)) else 170
            val cx = center?.cx ?: (W / 2)
            val cy = center?.cy ?: (ok.cy - 340)
            if (hit != null && center != null) {          // هدف کنار است ولی لمس جواب نداد: یک قدم بکش
                val up = hit.cy > center.cy
                drag(cx, cy + (if (up) itemH / 2 else -itemH / 2), cy + (if (up) -itemH / 2 else itemH / 2), 500)
                continue
            }
            val sig = items.joinToString("|") { it.text }
            if (sig == prevSig) same++ else same = 0
            prevSig = sig
            if (same >= 2) {                              // به انتهای لیست رسیدیم؛ جهت را برگردان
                dir = -dir
                reversals++
                same = 0
                if (reversals > 2) break
            }
            val d = (itemH * 1.7).toInt()
            drag(cx, cy - dir * d / 2, cy + dir * d / 2)
        }
        throw Fail("گزینه‌ی «$target» در پنجره پیدا نشد")
    }

    // ------------------------------------------------------------ shipment
    private fun addShipment(job: Job) {
        val f = job.f

        // صفحه‌ی «لیست مرسوله‌ها» ← افزودن مرسوله
        tapText("افزودن مرسوله")

        // «نوع بسته» ← دکمه‌ی «انتخاب نوع کالا» لیست (مینی پک / بسته / ...) را باز می‌کند
        val opener = wait("انتخاب نوع کالا", 8000)
        if (opener.isNotEmpty()) {
            tap(opener[0].cx, opener[0].cy)
            sleep(1000)
        }
        val names = if (job.ptype.startsWith("پاک")) listOf("پاکت", "پاکات") else listOf(job.ptype)
        var typeHit: N? = null
        for (nm in names) {
            typeHit = wait(nm, 6000, contains = false).firstOrNull()
            if (typeHit != null) break
        }
        if (typeHit == null) throw Fail("پیدا نشد: ${job.ptype}")
        tap(typeHit.cx, typeHit.cy)
        sleep(1200)

        // نوع بسته بندی ← ملزومات بسته بندی. پنجره‌ی انتخاب بعد از انتخاب نوع، معمولاً خودش باز می‌شود.
        var open = false
        for (i in 0 until 8) {
            if (pickerOpen()) { open = true; break }
            sleep(400)
        }
        if (!open) {
            scrollTo("نوع بسته بندی", true)
            val ns = snapshot()
            val lab = find("نوع بسته بندی", nodes = ns).firstOrNull() ?: throw Fail("پیدا نشد: نوع بسته بندی")
            val tgt = ns.filter { it.r.top >= lab.r.bottom - 5 && (it.clickable || it.isEdit) }
                .minByOrNull { it.r.top }
            if (tgt != null) tap(tgt.cx, tgt.cy) else tap(W / 2, lab.r.bottom + 75)
            for (i in 0 until 6) {
                sleep(500)
                if (pickerOpen()) { open = true; break }
            }
        }
        if (!open) throw Fail("پنجره‌ی نوع بسته بندی باز نشد")
        selectInPicker("ملزومات بسته بندی")
        sleep(800)

        // نایلون حباب‌دار = ۲۰ هزار تومان
        put(editBeside("هزینه نایلون حبابدار"), BUBBLE_WRAP_RIAL)
        hideKb()

        // ارزش مرسوله: حداقل ۱۰,۰۰۰,۰۰۰ ریال (طبق «حداقل 10000000 ریال» در فرم)
        val declared = (f["value_rial"] ?: "").filter { it.isDigit() }.toLongOrNull() ?: 0L
        put(editBelow("ارزش مرسوله"), maxOf(declared, MIN_VALUE_RIAL).toString())
        hideKb()

        val dims = listOf(
            Triple("وزن مرسوله", "weight_kg", "1"), Triple("طول", "length_cm", "30"),
            Triple("عرض", "width_cm", "20"), Triple("ارتفاع", "height_cm", "20")
        )
        for ((label, key, def) in dims) {
            put(editBelow(label), (f[key] ?: "").ifBlank { def })
            hideKb()
        }

        scrollTo("افزودن مرسوله")
        tapText("افزودن مرسوله")

        // بعد از افزودن، صفحه‌ی اسکن بارکد باز می‌شود («بارکد به صورت اتوماتیک اسکن خواهد شد»)
        if (wait("اسکن خواهد شد", 9000).isEmpty()) {
            val msg = snapshot().map { it.text.trim() }.filter { it.length > 3 }.take(4).joinToString(" | ")
            throw Fail("صفحه‌ی اسکن باز نشد. $msg")
        }
    }

    // ------------------------------------------------------------ main flow
    private fun run(job: Job) {
        val f = job.f
        fun g(k: String): String = f[k] ?: ""
        toast("شروع ثبت…")

        // صفحه‌ی اصلی؛ اگر اپ روی صفحه‌ی دیگری (مثل «جمع آوری مرسوله») باز شد، با Back برمی‌گردیم
        var home = wait("ثبت قرارداد و سفارش", 25000)
        var backs = 0
        while (home.isEmpty() && backs < 3) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            sleep(1200)
            home = wait("ثبت قرارداد و سفارش", 4000)
            backs++
        }
        if (home.isEmpty()) throw Fail("صفحه‌ی اصلی تیپاکس پیدا نشد")
        tapText("ثبت قرارداد و سفارش")
        wait("مشخصات قرارداد", 10000)

        // سوییچ «ثبت قرارداد» را روشن کن (با روشن شدن، بخش «جمع آوری در پلاک مبدا» ظاهر می‌شود)
        tapText("ثبت قرارداد", contains = false)
        if (wait("جمع آوری در پلاک مبدا", 4000).isEmpty()) {
            val lab = find("ثبت قرارداد", contains = false).firstOrNull()
            if (lab != null) {
                val sw = snapshot().filter { it.checkable && abs(it.cy - lab.cy) < 60 }
                    .minByOrNull { abs(it.cx - lab.cx) }
                if (sw != null) tap(sw.cx, sw.cy) else tap(lab.cx - 170, lab.cy)   // سوییچ سمت چپِ برچسب است
                sleep(900)
            }
        }
        tapText("صفحه بعدی", contains = false)

        // فرستنده
        wait("مشخصات فرستنده", 10000)
        val found = fillParty(true, g("sender_name"), g("sender_family"), g("sender_mobile"), g("sender_postal"))
        if (found) fillAddress("آدرس دقیق فرستنده")
        else fillAddress("آدرس دقیق فرستنده", main = SENDER_FALLBACK_STREET)
        goNext()
        passWarnings("مشخصات گیرنده", 4000)

        // گیرنده
        wait("مشخصات گیرنده", 10000)
        fillParty(false, g("receiver_name"), g("receiver_family"), g("receiver_mobile"), g("receiver_postal"))

        val cities = listOf(g("receiver_city")) + g("receiver_nearby").split(",").map { it.trim() }
        val prov = g("receiver_province")
        val chosen = pickCity(prov, cities)
        if (chosen == null) {
            toast("شهر در لیست نبود؛ خودت یکی انتخاب کن")
            if (wait("آدرس دقیق گیرنده", 180000).isEmpty()) throw Fail("شهر انتخاب نشد")
        }
        fillAddress(
            "آدرس دقیق گیرنده",
            main = g("receiver_street").ifEmpty { null },
            plate = g("receiver_plate").ifEmpty { null },
            unit = g("receiver_unit").ifEmpty { null }
        )

        scrollTo(job.delivery)
        val hits = find(job.delivery, clickable = true).ifEmpty { find(job.delivery) }
        if (hits.isEmpty()) throw Fail("پیدا نشد: ${job.delivery}")
        tap(hits.last().cx, hits.last().cy)
        sleep(800)
        goNext()

        // دو هشدار: «اعتبارسنجی آدرس» (تأیید) و «مقصد انتخاب شده ... آیا ادامه می‌دهید؟» (ادامه)
        if (!passWarnings("افزودن مرسوله", 20000)) throw Fail("بعد از هشدارها، صفحه‌ی مرسوله باز نشد")

        // مرسوله
        addShipment(job)
    }
}
