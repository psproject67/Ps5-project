package com.tipaxbot

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.UUID

/**
 * کلاینت API فارسی‌هوش (OCR):
 *   POST https://farsihoosh.ir/api/ocr?model=bina-0.2-rizeh
 *   Authorization: Bearer fh_live_...
 *   multipart/form-data  -> file=<image>   (۱ تصویر، حداکثر ۳ مگابایت)
 * خروجی API فقط متن است؛ پس متن را اینجا به همان ساختار JSON برچسب تبدیل می‌کنیم.
 */
object FarsiHoosh {

    const val DEFAULT_MODEL = "bina-0.2-rizeh"
    const val DEFAULT_ENDPOINT = "https://farsihoosh.ir/api/ocr"
    const val MAX_BYTES = 3 * 1024 * 1024 - 64 * 1024   // کمی کمتر از ۳MB برای اطمینان

    fun isFarsiHoosh(apiKey: String, base: String): Boolean =
        apiKey.startsWith("fh_") || base.contains("farsihoosh", ignoreCase = true)

    // ------------------------------------------------------------ HTTP
    fun ocr(apiKey: String, model: String, base: String, jpeg: ByteArray): String {
        if (jpeg.size > MAX_BYTES) throw RuntimeException("حجم عکس بیشتر از ۳ مگابایت است")
        val m = if (model.isBlank() || model.contains("/")) DEFAULT_MODEL else model.trim()
        val url = endpoint(base, m)

        var last = ""
        for (attempt in 1..3) {
            val boundary = "----tipax" + UUID.randomUUID().toString().replace("-", "")
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 30000
            conn.readTimeout = 120000
            conn.doOutput = true
            conn.setRequestProperty("Authorization", "Bearer ${apiKey.trim()}")
            conn.setRequestProperty("Accept", "application/json")
            conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")

            val head = "--$boundary\r\n" +
                "Content-Disposition: form-data; name=\"file\"; filename=\"label.jpg\"\r\n" +
                "Content-Type: image/jpeg\r\n\r\n"
            val tail = "\r\n--$boundary--\r\n"
            conn.setFixedLengthStreamingMode(head.length + jpeg.size + tail.length)
            conn.outputStream.use {
                it.write(head.toByteArray(Charsets.UTF_8))
                it.write(jpeg)
                it.write(tail.toByteArray(Charsets.UTF_8))
            }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val resp = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""

            when {
                code == 401 || code == 403 -> throw RuntimeException("کلید API فارسی‌هوش درست نیست ($code)")
                code == 413 -> throw RuntimeException("حجم عکس زیاد است (413)")
                code == 402 -> throw RuntimeException("اعتبار حساب فارسی‌هوش تمام شده (402)")
                code == 429 || code >= 500 -> {
                    last = "API $code: ${resp.take(150)}"
                    Thread.sleep(3000L * attempt)
                    continue
                }
                code !in 200..299 -> throw RuntimeException("API $code: ${resp.take(300)}")
            }

            val text = textFromResponse(resp)
            if (text.isBlank()) { last = "متنی در عکس خوانده نشد"; continue }
            return text
        }
        throw RuntimeException(last.ifEmpty { "پاسخ خالی" })
    }

    private fun endpoint(base: String, model: String): String {
        var u = base.trim()
        if (u.isEmpty()) u = DEFAULT_ENDPOINT
        if (!u.startsWith("http")) u = "https://$u"
        u = u.substringBefore("?").trimEnd('/')
        if (!u.endsWith("/api/ocr")) {
            u = if (u.contains("/api/")) u else u.substringBefore("/api") + "/api/ocr"
        }
        return u + "?model=" + URLEncoder.encode(model, "UTF-8")
    }

    // ------------------------------------------------------------ response -> text
    private val TEXT_KEYS = listOf("text", "full_text", "fulltext", "ocr_text", "content", "transcript", "result", "output")
    private val SKIP_KEYS = setOf(
        "model", "id", "status", "success", "message", "error", "usage", "time", "duration",
        "confidence", "score", "bbox", "box", "polygon", "points", "version", "request_id", "credits"
    )

    fun textFromResponse(resp: String): String {
        val t = resp.trim()
        if (t.isEmpty()) return ""
        val any: Any = try {
            if (t.startsWith("[")) JSONArray(t) else JSONObject(t)
        } catch (e: Exception) {
            return t   // پاسخ متن ساده بود
        }
        if (any is JSONObject) {
            val err = any.opt("error")
            if (err != null && err != JSONObject.NULL && err.toString().isNotBlank() && err != false)
                throw RuntimeException("API: " + err.toString().take(200))
            if (any.optBoolean("success", true).not())
                throw RuntimeException("API: " + any.optString("message", "ناموفق").take(200))
        }
        return collect(any).trim()
    }

    private fun collect(n: Any?): String = when (n) {
        is String -> n
        is JSONArray -> {
            val parts = ArrayList<String>()
            for (i in 0 until n.length()) collect(n.opt(i)).takeIf { it.isNotBlank() }?.let(parts::add)
            parts.joinToString("\n")
        }
        is JSONObject -> {
            var found: String? = null
            for (k in TEXT_KEYS) {
                if (n.has(k)) {
                    val s = collect(n.opt(k))
                    if (s.isNotBlank()) { found = s; break }
                }
            }
            found ?: run {
                for (k in listOf("lines", "pages", "blocks", "results", "data", "words")) {
                    if (n.has(k)) {
                        val s = collect(n.opt(k))
                        if (s.isNotBlank()) return@run s
                    }
                }
                val parts = ArrayList<String>()
                for (k in n.keys()) if (k !in SKIP_KEYS)
                    collect(n.opt(k)).takeIf { it.isNotBlank() }?.let(parts::add)
                parts.joinToString("\n")
            }
        }
        else -> ""
    }

    // ------------------------------------------------------------ text -> label JSON
    private val PROVINCES = listOf(
        "آذربایجان شرقی", "آذربایجان غربی", "اردبیل", "اصفهان", "البرز", "ایلام", "بوشهر", "تهران",
        "چهارمحال و بختیاری", "خراسان جنوبی", "خراسان رضوی", "خراسان شمالی", "خوزستان", "زنجان",
        "سمنان", "سیستان و بلوچستان", "فارس", "قزوین", "قم", "کردستان", "کرمان", "کرمانشاه",
        "کهگیلویه و بویراحمد", "گلستان", "گیلان", "لرستان", "مازندران", "مرکزی", "هرمزگان", "همدان", "یزد"
    )
    private val STOP_WORDS = listOf(
        "آدرس", "استان", "شهر", "کد پستی", "کدپستی", "موبایل", "همراه", "تلفن", "پلاک", "واحد",
        "خیابان", "خ ", "ارزش", "تیپاکس", "نام"
    )

    private fun norm(s: String): String {
        val sb = StringBuilder()
        for (ch in s) sb.append(
            when (ch) {
                in '۰'..'۹' -> '0' + (ch - '۰')
                in '٠'..'٩' -> '0' + (ch - '٠')
                'ي' -> 'ی'
                'ك' -> 'ک'
                '\u200c' -> ' '
                else -> ch
            }
        )
        return sb.toString()
    }


    // ------------------------------------------------------------ شهر/استان (تطبیق تقریبی)
    private val CITY_DATA = """
آذربایجان شرقی:تبریز,مراغه,مرند,اهر,میانه,بناب,سراب,شبستر,هشترود
آذربایجان غربی:ارومیه,خوی,میاندوآب,بوکان,مهاباد,سلماس,پیرانشهر,نقده,اشنویه
اردبیل:اردبیل,پارس‌آباد,مشگین‌شهر,خلخال,گرمی
اصفهان:اصفهان,کاشان,نجف‌آباد,خمینی‌شهر,شاهین‌شهر,شهرضا,فلاورجان,نطنز,اردستان,گلپایگان,زرین‌شهر
البرز:کرج,فردیس,نظرآباد,ساوجبلاغ,اشتهارد,طالقان
ایلام:ایلام,دهلران,ایوان,آبدانان,مهران
بوشهر:بوشهر,برازجان,گناوه,کنگان,خورموج,عسلویه
تهران:تهران,شهریار,اسلامشهر,ورامین,پاکدشت,قدس,ملارد,دماوند,پردیس,رباط‌کریم,بومهن,لواسان,فیروزکوه
چهارمحال و بختیاری:شهرکرد,بروجن,فارسان,لردگان,فرخشهر
خراسان جنوبی:بیرجند,قائن,طبس,فردوس,نهبندان
خراسان رضوی:مشهد,نیشابور,سبزوار,تربت‌حیدریه,کاشمر,قوچان,تایباد,گناباد,تربت‌جام,چناران,سرخس,درگز
خراسان شمالی:بجنورد,شیروان,اسفراین,آشخانه,جاجرم,فاروج
خوزستان:اهواز,آبادان,دزفول,خرمشهر,ماهشهر,بهبهان,ایذه,اندیمشک,شوشتر,مسجدسلیمان,رامهرمز,سوسنگرد
زنجان:زنجان,ابهر,خرمدره
سمنان:سمنان,شاهرود,دامغان,گرمسار,مهدیشهر
سیستان و بلوچستان:زاهدان,چابهار,زابل,ایرانشهر,سراوان,خاش,کنارک
فارس:شیراز,مرودشت,جهرم,فسا,کازرون,داراب,فیروزآباد,آباده,اقلید,لامرد
قزوین:قزوین,تاکستان,بوئین‌زهرا,آبیک
قم:قم
کردستان:سنندج,سقز,مریوان,بانه,قروه,بیجار,کامیاران
کرمان:کرمان,رفسنجان,سیرجان,جیرفت,زرند,کهنوج,بردسیر
کرمانشاه:کرمانشاه,اسلام‌آباد غرب,سنقر,کنگاور,هرسین,پاوه,جوانرود,صحنه,قصرشیرین
کهگیلویه و بویراحمد:یاسوج,دهدشت,گچساران,دوگنبدان
گلستان:گرگان,گنبدکاووس,علی‌آباد,آق‌قلا,بندر ترکمن,کردکوی,مینودشت,آزادشهر
گیلان:رشت,انزلی,لاهیجان,لنگرود,آستارا,تالش,فومن,صومعه‌سرا,رودسر,املش
لرستان:خرم‌آباد,بروجرد,دورود,الیگودرز,کوهدشت,ازنا,الشتر
مازندران:ساری,بابل,آمل,قائمشهر,بابلسر,نوشهر,چالوس,تنکابن,رامسر,محمودآباد,بهشهر,نکا
مرکزی:اراک,ساوه,خمین,محلات,دلیجان,شازند
هرمزگان:بندرعباس,میناب,قشم,کیش,بندرلنگه,جاسک
همدان:همدان,ملایر,نهاوند,تویسرکان,اسدآباد
یزد:یزد,میبد,اردکان,بافق,ابرکوه,تفت
"""

    private val CITIES: List<Pair<String, String>> by lazy {
        val out = ArrayList<Pair<String, String>>()
        for (line in CITY_DATA.trim().lines()) {
            val prov = line.substringBefore(":").trim()
            for (c in line.substringAfter(":").split(",")) if (c.isNotBlank()) out.add(c.trim() to prov)
        }
        out
    }

    /** حروف هم‌صدا را یکی می‌کند و همه‌ی غیرحروف‌ها (فاصله، نیم‌فاصله...) را حذف می‌کند */
    private fun fold(s: String): String {
        val sb = StringBuilder()
        for (ch in norm(s)) {
            if (ch !in '\u0600'..'\u06FF' || ch == '\u200c') continue
            sb.append(when (ch) {
                'چ' -> 'ج'; 'گ' -> 'ک'; 'پ' -> 'ب'; 'ژ' -> 'ز'
                'آ', 'أ', 'إ' -> 'ا'; 'ة' -> 'ه'; 'ؤ' -> 'و'; 'ئ' -> 'ی'
                else -> ch
            })
        }
        return sb.toString().filter { it.isLetter() }
    }

    private fun lev(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]; d[0] = i
            for (j in 1..b.length) {
                val tmp = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return d[b.length]
    }

    /** نزدیک‌ترین شهر شناخته‌شده به کلمات متن (۱ تا ۳ کلمه‌ی پشت‌سرهم) */
    fun findCity(text: String): Pair<String, String>? {
        val words = norm(text).split(Regex("[\\s،,:;\\-–|/()]+")).filter { it.isNotBlank() }
        var best: Pair<String, String>? = null
        var bestD = 99
        val known = CITIES.map { Triple(it.first, it.second, fold(it.first)) }
        for (i in words.indices) for (n in 1..3) {
            if (i + n > words.size) break
            val cand = fold(words.subList(i, i + n).joinToString(""))
            if (cand.length < 2) continue
            for ((name, prov, f) in known) {
                val tol = when { f.length <= 3 -> 0; f.length <= 5 -> 1; else -> 2 }
                if (cand.length < f.length - tol - 1 || cand.length > f.length + tol + 1) continue
                val d = lev(cand, f)
                if (d <= tol && d < bestD) { bestD = d; best = name to prov }
            }
        }
        return best
    }

    private fun allMobiles(s: String): List<String> {
        val out = LinkedHashSet<String>()
        for (m in Regex("""(?:\+?98|0)?\s*9[\d\s\-]{9,14}""").findAll(s)) {
            var d = digitsOf(m.value)
            if (d.startsWith("98") && d.length == 12) d = "0" + d.substring(2)
            if (d.length == 10 && d.startsWith("9")) d = "0$d"
            if (d.length == 11 && d.startsWith("09")) out.add(d)
        }
        // OCR گاهی عدد را برعکس می‌خواند (۰۹... -> ...۹۰)
        for (m in Regex("""\d[\d\s\-]{9,14}\d""").findAll(s)) {
            val d = digitsOf(m.value)
            if (d.length == 11 && d.endsWith("90")) out.add(d.reversed())
        }
        return out.toList()
    }

    private fun digitsOf(s: String) = s.filter { it.isDigit() }

    private fun mobileIn(s: String): String? = allMobiles(s).firstOrNull()

    private fun postalIn(s: String): String? =
        Regex("""\d[\d\s\-]{8,12}\d""").findAll(s)
            .map { digitsOf(it.value) }
            .firstOrNull { it.length == 10 && !it.startsWith("09") }

    private fun nameFrom(sec: String): Pair<String?, String?> {
        for (raw in sec.lines()) {
            var l = raw.replace(Regex("""(نام و نام خانوادگی|نام خانوادگی|نام)\s*:?"""), " ")
            l = l.replace(Regex("""(^|\s)(آقای|اقای|خانم|جناب|سرکار|دکتر|مهندس|شرکت|فروشگاه)(?=\s|$)"""), " ")
            l = l.replace(Regex("""[\d:؛،,\-_.()/\\]"""), " ").trim()
            if (l.isEmpty()) continue
            if (STOP_WORDS.any { it.trim().isNotEmpty() && l.contains(it.trim()) && it.trim() != "نام" }) continue
            val w = l.split(Regex("""\s+""")).filter { it.length > 1 }
            if (w.isEmpty()) continue
            return w.first() to (w.drop(1).joinToString(" ").ifEmpty { null })
        }
        return null to null
    }

    fun toLabelJson(rawText: String): JSONObject {
        val text = norm(rawText)
        val iS = text.indexOf("فرستنده")
        val iR = text.indexOf("گیرنده")

        var sender = ""
        var receiver = ""
        when {
            iS >= 0 && iR >= 0 && iS < iR -> { sender = text.substring(iS, iR); receiver = text.substring(iR) }
            iS >= 0 && iR >= 0 -> { receiver = text.substring(iR, iS); sender = text.substring(iS) }
            iR >= 0 -> { receiver = text.substring(iR); sender = text.substring(0, iR) }
            iS >= 0 -> { sender = text.substring(iS); receiver = "" }
            else -> receiver = text
        }

        // آدرس گیرنده
        val rFlat = receiver.replace("گیرنده", " ")
        var province: String? = null
        for (p in PROVINCES.sortedByDescending { it.length }) if (rFlat.contains(p)) { province = p; break }

        var city: String? = null
        var street: String? = null
        // متن آدرس: از «آدرس» تا قبل از همراه/موبایل/تلفن/ارزش (آدرس ممکن است چند خط باشد)
        val oneLine = rFlat.replace("\n", " ")
        val aStart = oneLine.indexOf("آدرس").let { if (it >= 0) it + 4 else 0 }
        var addrText = oneLine.substring(aStart)
        Regex("""(همراه|موبایل|تلفن|تماس|ارزش|\()""").find(addrText)?.let { addrText = addrText.substring(0, it.range.first) }
        addrText = addrText.replace("استان", " ")
        if (province != null) addrText = addrText.replace(province, " ")
        val chunks = addrText.split(Regex("""[،,\-–:|]""")).map { it.trim() }.filter { it.isNotEmpty() }

        val hit = findCity(addrText)
        var rest: List<String>
        if (hit != null) {
            city = hit.first
            if (province == null) province = hit.second
            val ci = chunks.indexOfFirst { findCity(it)?.first == hit.first }
            rest = if (ci >= 0) chunks.drop(ci + 1) else chunks
        } else {
            val cityChunk = chunks.firstOrNull { it.startsWith("شهر") }?.removePrefix("شهرستان")?.removePrefix("شهر")?.trim()
                ?: chunks.firstOrNull()
            city = cityChunk?.replace(Regex("""\d+"""), "")?.trim()?.takeIf { it.isNotEmpty() && it.length < 25 }
            rest = chunks.drop(if (cityChunk != null) 1 else 0)
        }
        street = rest.joinToString(" ")
            .replace(Regex("""(پلاک|واحد)\s*:?\s*\d+"""), " ")
            .replace(Regex("""\d{5,}"""), " ").replace(Regex("""\s+"""), " ").trim().ifEmpty { null }

        val plate = Regex("""پلاک\s*:?\s*(\d+)""").find(receiver)?.groupValues?.get(1)
        val unit = Regex("""واحد\s*:?\s*(\d+)""").find(receiver)?.groupValues?.get(1)

        // ارزش
        var amount: Double? = null
        var unitStr: String? = null
        Regex("""ارزش[^\d]{0,15}([\d,٬.\s]{1,20})\s*(تومان|ریال|هزار تومان)?""").find(text)?.let {
            val n = digitsOf(it.groupValues[1]).toDoubleOrNull()
            if (n != null && n > 0) {
                var a = n
                val u = it.groupValues[2]
                if (u == "هزار تومان") a *= 1000
                amount = a
                unitStr = if (u == "ریال") "rial" else "toman"
            }
        }

        val (sn, sf) = nameFrom(sender.replace("فرستنده", " "))
        val (rn, rf) = nameFrom(receiver.replace("گیرنده", " "))

        val allMob = allMobiles(text)
        val allPost = Regex("""\d[\d\s\-]{8,12}\d""").findAll(text)
            .map { digitsOf(it.value) }.filter { it.length == 10 && !it.startsWith("09") }.distinct().toList()
        val noMarkers = iS < 0 && iR < 0

        fun person(name: String?, family: String?, sec: String, idx: Int) = JSONObject()
            .put("name", name ?: JSONObject.NULL)
            .put("family", family ?: JSONObject.NULL)
            .put("mobile", mobileIn(sec) ?: (if (noMarkers) allMob.getOrNull(idx) else null) ?: JSONObject.NULL)
            .put("postal_code", postalIn(sec) ?: (if (noMarkers) allPost.getOrNull(idx) else null) ?: JSONObject.NULL)

        val r = person(if (noMarkers) null else rn, if (noMarkers) null else rf, receiver, 1)
            .put("province", province ?: JSONObject.NULL)
            .put("city", city ?: JSONObject.NULL)
            .put("nearby_cities", JSONArray())
            .put("main_street", street ?: JSONObject.NULL)
            .put("plate", plate ?: JSONObject.NULL)
            .put("unit", unit ?: JSONObject.NULL)

        return JSONObject()
            .put("sender", person(sn, sf, sender, 0))
            .put("receiver", r)
            .put("declared_value", JSONObject()
                .put("amount", amount ?: JSONObject.NULL)
                .put("unit", unitStr ?: JSONObject.NULL))
            .put("box", JSONObject())
    }

}
