package com.tipaxbot

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.UUID

/**
 * کلاینت API فارسی‌هوش (OCR):
 *   POST https://farsihoosh.ir/api/ocr?model=bina-0.2-rizeh
 *   Authorization: Bearer fh_live_...
 *   multipart/form-data  -> file=<image>   (۱ تصویر، حداکثر ۳ مگابایت)
 * خروجی API فقط متن است؛ پس متن را اینجا به همان ساختار JSON برچسب تبدیل می‌کنیم.
 */
object FarsiHoosh {

    const val DEFAULT_MODEL = "bina-0.2-rizeh"
    const val DEFAULT_ENDPOINT = "https://farsihoosh.ir/api/ocr"
    const val MAX_BYTES = 3 * 1024 * 1024 - 64 * 1024   // کمی کمتر از ۳MB برای اطمینان

    fun isFarsiHoosh(apiKey: String, base: String): Boolean =
        apiKey.startsWith("fh_") || base.contains("farsihoosh", ignoreCase = true)

    // ------------------------------------------------------------ HTTP
    fun ocr(apiKey: String, model: String, base: String, jpeg: ByteArray): String {
        if (jpeg.size > MAX_BYTES) throw RuntimeException("حجم عکس بیشتر از ۳ مگابایت است")
        val m = if (model.isBlank() || model.contains("/")) DEFAULT_MODEL else model.trim()
        val url = endpoint(base, m)

        var last = ""
        for (attempt in 1..3) {
            val boundary = "----tipax" + UUID.randomUUID().toString().replace("-", "")
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 30000
            conn.readTimeout = 120000
            conn.doOutput = true
            conn.setRequestProperty("Authorization", "Bearer ${apiKey.trim()}")
            conn.setRequestProperty("Accept", "application/json")
            conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")

            val head = "--$boundary\r\n" +
                "Content-Disposition: form-data; name=\"file\"; filename=\"label.jpg\"\r\n" +
                "Content-Type: image/jpeg\r\n\r\n"
            val tail = "\r\n--$boundary--\r\n"
            conn.setFixedLengthStreamingMode(head.length + jpeg.size + tail.length)
            conn.outputStream.use {
                it.write(head.toByteArray(Charsets.UTF_8))
                it.write(jpeg)
                it.write(tail.toByteArray(Charsets.UTF_8))
            }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val resp = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""

            when {
                code == 401 || code == 403 -> throw RuntimeException("کلید API فارسی‌هوش درست نیست ($code)")
                code == 413 -> throw RuntimeException("حجم عکس زیاد است (413)")
                code == 402 -> throw RuntimeException("اعتبار حساب فارسی‌هوش تمام شده (402)")
                code == 429 || code >= 500 -> {
                    last = "API $code: ${resp.take(150)}"
                    Thread.sleep(3000L * attempt)
                    continue
                }
                code !in 200..299 -> throw RuntimeException("API $code: ${resp.take(300)}")
            }

            val text = textFromResponse(resp)
            if (text.isBlank()) { last = "متنی در عکس خوانده نشد"; continue }
            return text
        }
        throw RuntimeException(last.ifEmpty { "پاسخ خالی" })
    }

    private fun endpoint(base: String, model: String): String {
        var u = base.trim()
        if (u.isEmpty()) u = DEFAULT_ENDPOINT
        if (!u.startsWith("http")) u = "https://$u"
        u = u.substringBefore("?").trimEnd('/')
        if (!u.endsWith("/api/ocr")) {
            u = if (u.contains("/api/")) u else u.substringBefore("/api") + "/api/ocr"
        }
        return u + "?model=" + URLEncoder.encode(model, "UTF-8")
    }

    // ------------------------------------------------------------ response -> text
    private val TEXT_KEYS = listOf("text", "full_text", "fulltext", "ocr_text", "content", "transcript", "result", "output")
    private val SKIP_KEYS = setOf(
        "model", "id", "status", "success", "message", "error", "usage", "time", "duration",
        "confidence", "score", "bbox", "box", "polygon", "points", "version", "request_id", "credits"
    )

    fun textFromResponse(resp: String): String {
        val t = resp.trim()
        if (t.isEmpty()) return ""
        val any: Any = try {
            if (t.startsWith("[")) JSONArray(t) else JSONObject(t)
        } catch (e: Exception) {
            return t   // پاسخ متن ساده بود
        }
        if (any is JSONObject) {
            val err = any.opt("error")
            if (err != null && err != JSONObject.NULL && err.toString().isNotBlank() && err != false)
                throw RuntimeException("API: " + err.toString().take(200))
            if (any.optBoolean("success", true).not())
                throw RuntimeException("API: " + any.optString("message", "ناموفق").take(200))
        }
        return collect(any).trim()
    }

    private fun collect(n: Any?): String = when (n) {
        is String -> n
        is JSONArray -> {
            val parts = ArrayList<String>()
            for (i in 0 until n.length()) collect(n.opt(i)).takeIf { it.isNotBlank() }?.let(parts::add)
            parts.joinToString("\n")
        }
        is JSONObject -> {
            var found: String? = null
            for (k in TEXT_KEYS) {
                if (n.has(k)) {
                    val s = collect(n.opt(k))
                    if (s.isNotBlank()) { found = s; break }
                }
            }
            found ?: run {
                for (k in listOf("lines", "pages", "blocks", "results", "data", "words")) {
                    if (n.has(k)) {
                        val s = collect(n.opt(k))
                        if (s.isNotBlank()) return@run s
                    }
                }
                val parts = ArrayList<String>()
                for (k in n.keys()) if (k !in SKIP_KEYS)
                    collect(n.opt(k)).takeIf { it.isNotBlank() }?.let(parts::add)
                parts.joinToString("\n")
            }
        }
        else -> ""
    }

    // ------------------------------------------------------------ text -> label JSON
    private val PROVINCES = listOf(
        "آذربایجان شرقی", "آذربایجان غربی", "اردبیل", "اصفهان", "البرز", "ایلام", "بوشهر", "تهران",
        "چهارمحال و بختیاری", "خراسان جنوبی", "خراسان رضوی", "خراسان شمالی", "خوزستان", "زنجان",
        "سمنان", "سیستان و بلوچستان", "فارس", "قزوین", "قم", "کردستان", "کرمان", "کرمانشاه",
        "کهگیلویه و بویراحمد", "گلستان", "گیلان", "لرستان", "مازندران", "مرکزی", "هرمزگان", "همدان", "یزد"
    )
    private val STOP_WORDS = listOf(
        "آدرس", "استان", "شهر", "کد پستی", "کدپستی", "موبایل", "همراه", "تلفن", "پلاک", "واحد",
        "خیابان", "خ ", "ارزش", "تیپاکس", "نام"
    )

    private fun norm(s: String): String {
        val sb = StringBuilder()
        for (ch in s) sb.append(
            when (ch) {
                in '۰'..'۹' -> '0' + (ch - '۰')
                in '٠'..'٩' -> '0' + (ch - '٠')
                'ي' -> 'ی'
                'ك' -> 'ک'
                '\u200c' -> ' '
                else -> ch
            }
        )
        return sb.toString()
    }

    private fun digitsOf(s: String) = s.filter { it.isDigit() }

    private fun mobileIn(s: String): String? {
        val d = Regex("""(?:\+?98|0)?\s*9[\d\s\-]{9,14}""").findAll(s)
            .map { digitsOf(it.value) }
            .map { if (it.startsWith("98") && it.length == 12) "0" + it.substring(2) else it }
            .map { if (it.length == 10 && it.startsWith("9")) "0$it" else it }
            .firstOrNull { it.length == 11 && it.startsWith("09") }
        return d
    }

    private fun postalIn(s: String): String? =
        Regex("""\d[\d\s\-]{8,12}\d""").findAll(s)
            .map { digitsOf(it.value) }
            .firstOrNull { it.length == 10 && !it.startsWith("09") }

    private fun nameFrom(sec: String): Pair<String?, String?> {
        for (raw in sec.lines()) {
            var l = raw.replace(Regex("""(نام و نام خانوادگی|نام خانوادگی|نام)\s*:?"""), " ")
            l = l.replace(Regex("""[\d:؛،,\-_.()/\\]"""), " ").trim()
            if (l.isEmpty()) continue
            if (STOP_WORDS.any { it.trim().isNotEmpty() && l.contains(it.trim()) && it.trim() != "نام" }) continue
            val w = l.split(Regex("""\s+""")).filter { it.length > 1 }
            if (w.isEmpty()) continue
            return w.first() to (w.drop(1).joinToString(" ").ifEmpty { null })
        }
        return null to null
    }

    fun toLabelJson(rawText: String): JSONObject {
        val text = norm(rawText)
        val iS = text.indexOf("فرستنده")
        val iR = text.indexOf("گیرنده")

        var sender = ""
        var receiver = ""
        when {
            iS >= 0 && iR >= 0 && iS < iR -> { sender = text.substring(iS, iR); receiver = text.substring(iR) }
            iS >= 0 && iR >= 0 -> { receiver = text.substring(iR, iS); sender = text.substring(iS) }
            iR >= 0 -> { receiver = text.substring(iR); sender = text.substring(0, iR) }
            iS >= 0 -> { sender = text.substring(iS); receiver = "" }
            else -> receiver = text
        }

        // آدرس گیرنده
        val rFlat = receiver.replace("گیرنده", " ")
        var province: String? = null
        for (p in PROVINCES.sortedByDescending { it.length }) if (rFlat.contains(p)) { province = p; break }

        var city: String? = null
        var street: String? = null
        val addrLine = rFlat.lines().firstOrNull { l ->
            province?.let { l.contains(it) } ?: l.contains("شهر") || l.contains("خیابان") || l.contains("آدرس")
        } ?: ""
        var addr = addrLine.replace(Regex("""آدرس\s*:?"""), " ").replace(Regex("""استان"""), " ")
        if (province != null) addr = addr.replace(province, "|P|")
        val after = if (province != null && addr.contains("|P|")) addr.substringAfter("|P|") else addr
        val chunks = after.split(Regex("""[،,\-–:|\n]""")).map { it.trim() }.filter { it.isNotEmpty() }
        val cityChunk = chunks.firstOrNull { it.startsWith("شهر") }?.removePrefix("شهرستان")?.removePrefix("شهر")?.trim()
            ?: chunks.firstOrNull()
        city = cityChunk?.replace(Regex("""\d+"""), "")?.trim()?.takeIf { it.isNotEmpty() && it.length < 25 }
        val rest = chunks.drop(if (cityChunk != null) 1 else 0).joinToString(" ")
        street = rest.replace(Regex("""(پلاک|واحد)\s*:?\s*\d+"""), " ")
            .replace(Regex("""\d{5,}"""), " ").replace(Regex("""\s+"""), " ").trim().ifEmpty { null }

        val plate = Regex("""پلاک\s*:?\s*(\d+)""").find(receiver)?.groupValues?.get(1)
        val unit = Regex("""واحد\s*:?\s*(\d+)""").find(receiver)?.groupValues?.get(1)

        // ارزش
        var amount: Double? = null
        var unitStr: String? = null
        Regex("""ارزش[^\d]{0,15}([\d,٬.\s]{1,20})\s*(تومان|ریال|هزار تومان)?""").find(text)?.let {
            val n = digitsOf(it.groupValues[1]).toDoubleOrNull()
            if (n != null && n > 0) {
                var a = n
                val u = it.groupValues[2]
                if (u == "هزار تومان") a *= 1000
                amount = a
                unitStr = if (u == "ریال") "rial" else "toman"
            }
        }

        val (sn, sf) = nameFrom(sender.replace("فرستنده", " "))
        val (rn, rf) = nameFrom(receiver.replace("گیرنده", " "))

        val allMob = Regex("""(?:\+?98|0)?\s*9[\d\s\-]{9,14}""").findAll(text)
            .map { digitsOf(it.value) }
            .map { if (it.startsWith("98") && it.length == 12) "0" + it.substring(2) else it }
            .map { if (it.length == 10 && it.startsWith("9")) "0$it" else it }
            .filter { it.length == 11 && it.startsWith("09") }.distinct().toList()
        val allPost = Regex("""\d[\d\s\-]{8,12}\d""").findAll(text)
            .map { digitsOf(it.value) }.filter { it.length == 10 && !it.startsWith("09") }.distinct().toList()
        val noMarkers = iS < 0 && iR < 0

        fun person(name: String?, family: String?, sec: String, idx: Int) = JSONObject()
            .put("name", name ?: JSONObject.NULL)
            .put("family", family ?: JSONObject.NULL)
            .put("mobile", mobileIn(sec) ?: (if (noMarkers) allMob.getOrNull(idx) else null) ?: JSONObject.NULL)
            .put("postal_code", postalIn(sec) ?: (if (noMarkers) allPost.getOrNull(idx) else null) ?: JSONObject.NULL)

        val r = person(if (noMarkers) null else rn, if (noMarkers) null else rf, receiver, 1)
            .put("province", province ?: JSONObject.NULL)
            .put("city", city ?: JSONObject.NULL)
            .put("nearby_cities", JSONArray())
            .put("main_street", street ?: JSONObject.NULL)
            .put("plate", plate ?: JSONObject.NULL)
            .put("unit", unit ?: JSONObject.NULL)

        return JSONObject()
            .put("sender", person(sn, sf, sender, 0))
            .put("receiver", r)
            .put("declared_value", JSONObject()
                .put("amount", amount ?: JSONObject.NULL)
                .put("unit", unitStr ?: JSONObject.NULL))
            .put("box", JSONObject())
    }

}
