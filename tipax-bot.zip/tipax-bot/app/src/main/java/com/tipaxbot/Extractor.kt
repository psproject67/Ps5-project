package com.tipaxbot

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

object Extractor {

    const val DEFAULT_MODEL = "openrouter/free"

    private const val PROMPT = """You are reading a photo of a handwritten Persian shipping label stuck on a parcel (Tipax courier).
Return ONLY one JSON object (no prose, no code fence) with exactly this schema:
{
 "sender":   {"name": str|null, "family": str|null, "mobile": str|null, "postal_code": str|null},
 "receiver": {"name": str|null, "family": str|null, "mobile": str|null, "postal_code": str|null,
              "province": str|null, "city": str|null,
              "nearby_cities": [up to 3 bigger/nearby cities in the same province, closest first],
              "main_street": str|null, "plate": str|null, "unit": str|null},
 "declared_value": {"amount": number|null, "unit": "toman"|"rial"|null},
 "box": {"length_cm": number|null, "width_cm": number|null, "height_cm": number|null, "weight_kg": number|null}
}
Rules:
- The label may be rotated. The pre-printed Tipax sticker, barcode and printed agency address are NOT data.
- "فرستنده" = sender, "گیرنده" = receiver. Convert Persian/Arabic digits to English digits.
- Mobile = 11 digits starting with 09. Postal code = 10 digits. Landline numbers are ignored.
- province/city: Persian names; city = the most specific real town/city of the receiver.
- main_street: receiver street/neighbourhood text WITHOUT province/city; plate and unit digits only.
- declared_value only if the text mentions ارزش (declared value) with an amount; keep the unit as written
  (تومان -> toman, ریال -> rial); otherwise nulls.
- box: estimate the outer size of the parcel from the photo using visible references (hand, tape, the paper
  label about A5/A6). weight_kg: a LIGHT realistic guess from volume and typical contents. Never overestimate.
- Use null when unreadable. Never invent data."""

    // ---------------------------------------------------------------- public API
    fun read(ctx: Context, uri: Uri, apiKey: String, model: String, baseUrl: String = ""): LinkedHashMap<String, String> {
        val base = baseUrl.trim()
        if (FarsiHoosh.isFarsiHoosh(apiKey, base)) {
            val jpeg = loadJpegBytes(ctx, uri, FarsiHoosh.MAX_BYTES)
            val text = FarsiHoosh.ocr(apiKey, model, base, jpeg)
            val m = fromText(text)
            m["_raw"] = text
            return m
        }
        val b64 = loadJpegBase64(ctx, uri)
        val raw = when {
            base.isNotEmpty() -> {
                if (model.isBlank()) throw RuntimeException("اسم مدل را وارد کن")
                callOpenAI(chatUrl(base), apiKey, model.trim(), b64)
            }
            apiKey.startsWith("sk-ant") -> {
                val m = if (model.isBlank() || model.contains("/")) "claude-sonnet-5-5" else model
                callClaude(apiKey, m, b64)
            }
            else -> {
                val m = if (model.isBlank() || !model.contains("/")) DEFAULT_MODEL else model
                callOpenAI("https://openrouter.ai/api/v1/chat/completions", apiKey, m, b64)
            }
        }
        return parse(raw)
    }

    /** تحلیل متن خام OCR به فیلدهای فرم */
    fun fromText(text: String): LinkedHashMap<String, String> = parse(FarsiHoosh.toLabelJson(text))

    private fun chatUrl(base: String): String {
        var u = base.trim().trimEnd('/')
        if (u.endsWith("/chat/completions")) return u
        if (!u.startsWith("http")) u = "https://$u"
        return "$u/chat/completions"
    }

    // ---------------------------------------------------------------- image
    private fun loadJpegBase64(ctx: Context, uri: Uri, maxSide: Int = 1800): String =
        Base64.encodeToString(loadJpegBytes(ctx, uri, Int.MAX_VALUE, maxSide), Base64.NO_WRAP)

    /** JPEG با حداکثر حجم مشخص (برای محدودیت ۳MB فارسی‌هوش): کیفیت و ابعاد را کم‌کم کم می‌کند. */
    private fun loadJpegBytes(ctx: Context, uri: Uri, maxBytes: Int, startSide: Int = 2400): ByteArray {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri).use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > startSide * 2) sample *= 2

        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val decoded: Bitmap = ctx.contentResolver.openInputStream(uri).use {
            BitmapFactory.decodeStream(it, null, opts)
        } ?: throw RuntimeException("عکس باز نشد")

        val rot = ctx.contentResolver.openInputStream(uri).use { s ->
            if (s == null) 0 else when (ExifInterface(s).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                6 -> 90
                3 -> 180
                8 -> 270
                else -> 0
            }
        }

        var side = startSide
        var quality = 88
        while (true) {
            val scale = side.toFloat() / maxOf(decoded.width, decoded.height)
            val m = Matrix()
            if (scale < 1f) m.postScale(scale, scale)
            if (rot != 0) m.postRotate(rot.toFloat())
            val bmp = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, m, true)
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, quality, out)
            if (bmp !== decoded) bmp.recycle()
            val bytes = out.toByteArray()
            if (bytes.size <= maxBytes) return bytes
            if (quality > 60) quality -= 12 else side = (side * 0.8f).toInt()
            if (side < 600) throw RuntimeException("نمی‌توان حجم عکس را زیر حد مجاز آورد")
        }
    }

    // ---------------------------------------------------------------- API call
    private fun callClaude(apiKey: String, model: String, b64: String): JSONObject {
        val image = JSONObject()
            .put("type", "image")
            .put(
                "source", JSONObject()
                    .put("type", "base64")
                    .put("media_type", "image/jpeg")
                    .put("data", b64)
            )
        val text = JSONObject().put("type", "text").put("text", PROMPT)
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 2000)
            .put(
                "messages", JSONArray().put(
                    JSONObject()
                        .put("role", "user")
                        .put("content", JSONArray().put(image).put(text))
                )
            )

        val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 30000
        conn.readTimeout = 120000
        conn.doOutput = true
        conn.setRequestProperty("x-api-key", apiKey)
        conn.setRequestProperty("anthropic-version", "2023-06-01")
        conn.setRequestProperty("content-type", "application/json")
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val resp = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        if (code !in 200..299) throw RuntimeException("API $code: ${resp.take(300)}")

        val content = JSONObject(resp).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until content.length()) {
            val c = content.getJSONObject(i)
            if (c.optString("type") == "text") sb.append(c.getString("text"))
        }
        return extractJson(sb.toString())
    }

    private fun extractJson(s: String): JSONObject {
        val a = s.indexOf('{')
        val z = s.lastIndexOf('}')
        if (a < 0 || z < a) throw RuntimeException("پاسخ JSON نبود: " + s.take(120))
        return JSONObject(s.substring(a, z + 1))
    }

    private fun callOpenAI(endpoint: String, apiKey: String, model: String, b64: String): JSONObject {
        var last = ""
        for (attempt in 1..3) {
            val text = JSONObject().put("type", "text").put("text", PROMPT)
            val image = JSONObject()
                .put("type", "image_url")
                .put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$b64"))
            val body = JSONObject()
                .put("model", model)
                .put("max_tokens", 4000)
                .put("temperature", 0)
                .put(
                    "messages", JSONArray().put(
                        JSONObject()
                            .put("role", "user")
                            .put("content", JSONArray().put(text).put(image))
                    )
                )

            val conn = URL(endpoint).openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 30000
            conn.readTimeout = 180000
            conn.doOutput = true
            conn.setRequestProperty("Authorization", "Bearer $apiKey")
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("X-Title", "Tipax Bot")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val resp = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            if (code == 429 || code >= 500) {
                last = "API $code"
                Thread.sleep(3000L * attempt)
                continue
            }
            if (code !in 200..299) throw RuntimeException("API $code: ${resp.take(300)}")

            val j = JSONObject(resp)
            if (j.has("error")) {
                last = "API: " + j.get("error").toString().take(200)
                Thread.sleep(2000L)
                continue
            }
            val choices = j.optJSONArray("choices")
            if (choices == null || choices.length() == 0) { last = "پاسخ خالی"; continue }
            val msg = choices.getJSONObject(0).optJSONObject("message") ?: continue
            val content = msg.opt("content")
            var txt = when (content) {
                is String -> content
                is JSONArray -> {
                    val sb = StringBuilder()
                    for (i in 0 until content.length()) sb.append(content.getJSONObject(i).optString("text"))
                    sb.toString()
                }
                else -> ""
            }
            if (txt.indexOf('{') < 0) txt = msg.optString("reasoning", "")
            try {
                return extractJson(txt)
            } catch (e: Exception) {
                last = "مدل ${j.optString("model")} جواب JSON نداد (تلاش $attempt)"
            }
        }
        throw RuntimeException(last.ifEmpty { "پاسخ JSON نبود" })
    }

    // ---------------------------------------------------------------- post-process
    private fun en(s: String?): String {
        if (s == null) return ""
        val sb = StringBuilder()
        for (ch in s) {
            sb.append(
                when (ch) {
                    in '۰'..'۹' -> '0' + (ch - '۰')
                    in '٠'..'٩' -> '0' + (ch - '٠')
                    else -> ch
                }
            )
        }
        return sb.toString()
    }

    private fun str(o: JSONObject, k: String): String =
        if (o.isNull(k)) "" else o.optString(k, "").trim()

    private fun dbl(o: JSONObject, k: String): Double? {
        if (o.isNull(k)) return null
        val d = o.optDouble(k)
        return if (d.isNaN()) en(o.optString(k)).replace(",", "").toDoubleOrNull() else d
    }

    private fun normMobile(s: String): String {
        var d = en(s).filter { it.isDigit() }
        if (d.startsWith("98") && d.length == 12) d = "0" + d.substring(2)
        if (d.length == 10 && d.startsWith("9")) d = "0$d"
        return d
    }

    private fun postal(s: String): String {
        val d = en(s).filter { it.isDigit() }
        return if (d.length == 10) d else ""
    }

    private fun fmt(d: Double): String = if (d == Math.floor(d)) d.toInt().toString() else d.toString()

    private fun parse(raw: JSONObject): LinkedHashMap<String, String> {
        val s = raw.optJSONObject("sender") ?: JSONObject()
        val r = raw.optJSONObject("receiver") ?: JSONObject()
        val box = raw.optJSONObject("box") ?: JSONObject()
        val v = raw.optJSONObject("declared_value") ?: JSONObject()

        val len = (dbl(box, "length_cm") ?: 35.0).toInt()
        val wid = (dbl(box, "width_cm") ?: 25.0).toInt()
        val hei = (dbl(box, "height_cm") ?: 20.0).toInt()
        val volW = len * wid * hei / 5000.0                      // وزن حجمی
        var w = dbl(box, "weight_kg") ?: maxOf(0.5, volW * 0.4)
        w = minOf(w, maxOf(1.0, volW * 0.6))                     // سقف: ۶۰٪ وزن حجمی
        w = maxOf(0.5, Math.round(w * 2) / 2.0)

        val amt = dbl(v, "amount")
        val rial = if (amt != null && amt > 0) {
            (amt * (if (str(v, "unit") == "rial") 1 else 10)).toLong().toString()
        } else ""

        val nearby = ArrayList<String>()
        val arr = r.optJSONArray("nearby_cities")
        if (arr != null) for (i in 0 until arr.length()) nearby.add(arr.optString(i))

        val m = LinkedHashMap<String, String>()
        m["sender_name"] = str(s, "name")
        m["sender_family"] = str(s, "family")
        m["sender_mobile"] = normMobile(str(s, "mobile"))
        m["sender_postal"] = postal(str(s, "postal_code"))
        m["receiver_name"] = str(r, "name")
        m["receiver_family"] = str(r, "family")
        m["receiver_mobile"] = normMobile(str(r, "mobile"))
        m["receiver_postal"] = postal(str(r, "postal_code"))
        m["receiver_province"] = str(r, "province")
        m["receiver_city"] = str(r, "city")
        m["receiver_nearby"] = nearby.joinToString(",")
        m["receiver_street"] = str(r, "main_street")
        m["receiver_plate"] = en(str(r, "plate"))
        m["receiver_unit"] = en(str(r, "unit"))
        m["value_rial"] = rial
        m["length_cm"] = len.toString()
        m["width_cm"] = wid.toString()
        m["height_cm"] = hei.toString()
        m["weight_kg"] = fmt(w)
        return m
    }
}
