package com.tipaxauto

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {

    private lateinit var accTv: TextView
    private lateinit var fileInfo: TextView
    private lateinit var statusTv: TextView
    private lateinit var countTv: TextView
    private lateinit var percentTv: TextView
    private lateinit var progress: ProgressBar
    private lateinit var delayEt: EditText
    private lateinit var startEt: EditText
    private lateinit var modeGroup: RadioGroup
    private val REQ = 11

    // اگر فایل res/font/vazirmatn.ttf را اضافه کنی، خودکار برای همه‌ی متن‌ها استفاده می‌شود
    private val customFont: Typeface? by lazy {
        val id = resources.getIdentifier("vazirmatn", "font", packageName)
        if (id != 0 && Build.VERSION.SDK_INT >= 26) resources.getFont(id) else null
    }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun c(id: Int) = resources.getColor(id, theme)

    private fun num(s: String): Double? =
        s.map { if (it in '۰'..'۹') '0' + (it - '۰') else it }.joinToString("").trim().toDoubleOrNull()

    private fun fa(s: String) = s.map { if (it in '0'..'9') '۰' + (it - '0') else it }.joinToString("")

    private fun face(bold: Boolean): Typeface =
        customFont?.let { Typeface.create(it, if (bold) Typeface.BOLD else Typeface.NORMAL) }
            ?: Typeface.create(if (bold) "sans-serif-medium" else "sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)

    private fun TextView.style(size: Float, color: Int, bold: Boolean = false): TextView {
        textSize = size
        setTextColor(color)
        typeface = face(bold)
        setLineSpacing(0f, 1.15f)
        return this
    }

    private fun label(text: String, size: Float = 14f, color: Int = c(R.color.text_main), bold: Boolean = false) =
        TextView(this).apply { this.text = text }.style(size, color, bold)

    private fun button(text: String, bg: Int, color: Int): Button = Button(this).apply {
        this.text = text
        setBackgroundResource(bg)
        stateListAnimator = null
        isAllCaps = false
        minHeight = dp(52)
        minimumHeight = dp(52)
        textSize = 16f
        setTextColor(color)
        typeface = face(true)
    }

    private fun card(step: String?, title: String): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_card)
            setPadding(dp(16), dp(16), dp(16), dp(16))
            elevation = dp(2).toFloat()
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        if (step != null) {
            row.addView(TextView(this).apply {
                text = step
                gravity = Gravity.CENTER
                setBackgroundResource(R.drawable.bg_badge)
            }.style(14f, Color.WHITE, true), LinearLayout.LayoutParams(dp(30), dp(30)).apply { marginEnd = dp(10) })
        }
        row.addView(label(title, 16f, c(R.color.text_main), true))
        box.addView(row)
        return box
    }

    private fun LinearLayout.addGap(v: View, top: Int = 12, h: Int = -2) =
        addView(v, LinearLayout.LayoutParams(-1, h).apply { topMargin = dp(top) })

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        // ---------- هدر ----------
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundResource(R.drawable.bg_header)
            setPadding(dp(22), dp(26), dp(22), dp(34))
        }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_launcher_foreground)
            setBackgroundResource(R.drawable.bg_icon_circle)
        }, LinearLayout.LayoutParams(dp(68), dp(68)).apply { marginEnd = dp(14) })
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(label(getString(R.string.title), 20f, Color.WHITE, true))
        titles.addView(label(getString(R.string.subtitle), 13f, Color.parseColor("#D8F0DA")),
            LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(4) })
        header.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(header, LinearLayout.LayoutParams(-1, -2))

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(4), dp(16), dp(24))
        }
        content.addView(body, LinearLayout.LayoutParams(-1, -2))

        // ---------- ۱) دسترسی ----------
        val c1 = card("۱", getString(R.string.step1_title))
        c1.addGap(button(getString(R.string.step1_btn), R.drawable.btn_tonal, c(R.color.green_dark)).apply {
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        accTv = label("", 13f)
        c1.addGap(accTv, 10)
        body.addGap(c1, 14)

        // ---------- ۲) فایل ----------
        val c2 = card("۲", getString(R.string.step2_title))
        c2.addGap(button(getString(R.string.step2_btn), R.drawable.btn_tonal, c(R.color.green_dark)).apply {
            setOnClickListener {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                startActivityForResult(i, REQ)
            }
        })
        fileInfo = label(getString(R.string.no_file), 13f, c(R.color.text_muted)).apply {
            setBackgroundResource(R.drawable.bg_fileinfo)
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        c2.addGap(fileInfo, 10)
        body.addGap(c2, 14)

        // ---------- ۳) تنظیمات ----------
        val c3 = card("۳", getString(R.string.step3_title))
        delayEt = EditText(this).apply {
            setText("2")
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        startEt = EditText(this).apply {
            setText("1")
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        fun field(title: String, et: EditText): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(label(title, 12f, c(R.color.text_muted)))
            et.apply {
                gravity = Gravity.CENTER
                setBackgroundResource(R.drawable.bg_input)
                setPadding(dp(8), dp(10), dp(8), dp(10))
            }.style(18f, c(R.color.text_main), true)
            addView(et, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(6) })
        }
        val fields = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fields.addView(field(getString(R.string.delay_label), delayEt),
            LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) })
        fields.addView(field(getString(R.string.start_label), startEt),
            LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(6) })
        c3.addGap(fields, 14)
        body.addGap(c3, 14)

        // ---------- ۴) روش ثبت ----------
        val c4 = card("۴", getString(R.string.step4_title))
        val tint = ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(c(R.color.green_mid), Color.parseColor("#9DB0A2"))
        )
        modeGroup = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        listOf(
            R.string.mode0 to R.string.mode0_desc,
            R.string.mode1 to R.string.mode1_desc,
            R.string.mode2 to R.string.mode2_desc
        ).forEachIndexed { i, (t, d) ->
            val title = getString(t)
            val sb = SpannableStringBuilder(title + "\n" + getString(d))
            sb.setSpan(RelativeSizeSpan(0.82f), title.length + 1, sb.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.setSpan(ForegroundColorSpan(c(R.color.text_muted)), title.length + 1, sb.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            val rb = RadioButton(this).apply {
                id = 100 + i
                text = sb
                isChecked = i == 0
                buttonTintList = tint
                setBackgroundResource(R.drawable.option_bg)
                setPadding(dp(10), dp(12), dp(10), dp(12))
            }.also { it.style(15f, c(R.color.text_main), true) }
            modeGroup.addView(rb, RadioGroup.LayoutParams(-1, -2).apply { topMargin = dp(if (i == 0) 0 else 8) })
        }
        c4.addGap(modeGroup, 12)
        body.addGap(c4, 14)

        // ---------- وضعیت ----------
        val c5 = card(null, getString(R.string.progress_title))
        statusTv = label(Automation.statusText, 13f, c(R.color.green_dark), true).apply {
            setBackgroundResource(R.drawable.bg_chip)
            setPadding(dp(14), dp(8), dp(14), dp(8))
        }
        c5.addGap(statusTv, 12, -2)
        val countRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        countTv = label("", 22f, c(R.color.text_main), true)
        percentTv = label("", 15f, c(R.color.green_mid), true)
        countRow.addView(countTv, LinearLayout.LayoutParams(0, -2, 1f))
        countRow.addView(percentTv)
        c5.addGap(countRow, 14)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            progressDrawable = resources.getDrawable(R.drawable.progress_bar, theme)
        }
        c5.addGap(progress, 10, dp(10))
        body.addGap(c5, 14)

        // ---------- نوار پایین: شروع / توقف ----------
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(Color.WHITE)
            setPadding(dp(16), dp(10), dp(16), dp(12))
            elevation = dp(10).toFloat()
        }
        bar.addView(button(getString(R.string.btn_start), R.drawable.btn_primary, Color.WHITE).apply {
            setOnClickListener { start() }
        }, LinearLayout.LayoutParams(0, dp(54), 2f).apply { marginEnd = dp(8) })
        bar.addView(button(getString(R.string.btn_stop), R.drawable.btn_danger, c(R.color.danger)).apply {
            setOnClickListener {
                TipaxService.instance?.stop(getString(R.string.stopped)) ?: toast(getString(R.string.toast_no_service))
            }
        }, LinearLayout.LayoutParams(0, dp(54), 1f))

        val screen = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        screen.addView(ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(content)
        }, LinearLayout.LayoutParams(-1, 0, 1f))
        screen.addView(bar, LinearLayout.LayoutParams(-1, -2))
        setContentView(screen)
    }

    override fun onResume() {
        super.onResume()
        Automation.listener = { refresh() }
        refresh()
    }

    override fun onPause() {
        super.onPause()
        Automation.listener = null
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun refresh() {
        val on = TipaxService.instance != null
        accTv.text = getString(if (on) R.string.acc_on else R.string.acc_off)
        accTv.setTextColor(c(if (on) R.color.green else R.color.warn))

        val n = Automation.codes.size
        statusTv.text = Automation.statusText
        countTv.text = getString(R.string.count_fmt, fa(Automation.index.toString()), fa(n.toString()))
        percentTv.text = fa((if (n > 0) Automation.index * 100 / n else 0).toString()) + "٪"
        progress.max = maxOf(n, 1)
        progress.progress = Automation.index
        if (!Automation.running && n > 0) {
            startEt.setText((Automation.index + 1).coerceAtMost(n).toString())
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ && resultCode == RESULT_OK) data?.data?.let { load(it) }
    }

    private fun load(uri: Uri) {
        fileInfo.text = getString(R.string.reading_file)
        Thread {
            try {
                val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                val list = if (bytes.size > 1 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte()) {
                    XlsxReader.parse(bytes)
                } else {
                    String(bytes, Charsets.UTF_8).split(Regex("[\\s,;\"]+"))
                        .map { it.trim() }.filter { XlsxReader.CODE.matches(it) }
                }
                runOnUiThread { onLoaded(list) }
            } catch (e: Exception) {
                runOnUiThread { fileInfo.text = getString(R.string.read_error, e.message ?: "") }
            }
        }.start()
    }

    private fun onLoaded(list: List<String>) {
        if (list.isEmpty()) { fileInfo.text = getString(R.string.no_codes); return }
        Automation.codes = list
        Automation.fileKey = "${list.size}_${list.first()}_${list.last()}"
        val saved = getSharedPreferences("tipax", MODE_PRIVATE).getInt("pos_${Automation.fileKey}", 0)
        Automation.index = saved.coerceIn(0, list.size - 1)
        fileInfo.text = getString(R.string.file_ok, fa(list.size.toString()), list.first()) +
            if (saved > 0) getString(R.string.file_resume, fa((saved + 1).toString())) else ""
        fileInfo.setTextColor(c(R.color.text_main))
        Automation.setStatus(getString(R.string.ready))
    }

    private fun start() {
        if (Automation.codes.isEmpty()) { toast(getString(R.string.toast_pick_file)); return }
        val svc = TipaxService.instance
        if (svc == null) {
            toast(getString(R.string.toast_enable_acc))
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        val launch = packageManager.getLaunchIntentForPackage(TipaxService.TIPAX)
        if (launch == null) { toast(getString(R.string.toast_no_tipax)); return }
        val n = Automation.codes.size
        Automation.index = ((num(startEt.text.toString())?.toInt() ?: 1) - 1).coerceIn(0, n - 1)
        Automation.delayMs = (((num(delayEt.text.toString()) ?: 2.0).coerceAtLeast(0.5)) * 1000).toLong()
        Automation.submitMode = modeGroup.checkedRadioButtonId - 100
        startActivity(launch)
        svc.start()
    }
}
