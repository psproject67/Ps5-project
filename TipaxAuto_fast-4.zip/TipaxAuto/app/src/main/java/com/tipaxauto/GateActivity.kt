package com.tipaxauto

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import java.security.MessageDigest

/** رمز ورود (فقط یک‌بار بعد از نصب). برای عوض کردن رمز، SHA-256 رمز جدید را اینجا بگذار. */
object Gate {
    // رمز پیش‌فرض: Tipax@123   ← حتماً عوضش کن (README را ببین)
    const val PASSWORD_SHA256 = "9f0566577dd265c181222a70282574bbb28ea2dc54daad55219a60a8f8cf1eef"
    const val PREFS = "tipax"
    const val KEY = "unlocked"

    fun isUnlocked(a: Activity) = a.getSharedPreferences(PREFS, Activity.MODE_PRIVATE).getBoolean(KEY, false)
    fun unlock(a: Activity) = a.getSharedPreferences(PREFS, Activity.MODE_PRIVATE).edit().putBoolean(KEY, true).apply()

    fun check(input: String): Boolean {
        val s = input.map { if (it in '۰'..'۹') '0' + (it - '۰') else it }.joinToString("").trim()
        val h = MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        return h == PASSWORD_SHA256
    }
}

class GateActivity : Activity() {

    private val GREEN = Color.parseColor("#2F7046")
    private val GREEN_DARK = Color.parseColor("#1F5A37")
    private val MUTED = Color.parseColor("#6B6B6B")
    private val RED = Color.parseColor("#C62828")

    private val font: Typeface by lazy {
        var f: Typeface? = null
        if (Build.VERSION.SDK_INT >= 26) {
            for (n in listOf("btitr", "vazirmatn")) {
                val id = resources.getIdentifier(n, "font", packageName)
                if (id != 0) { f = resources.getFont(id); break }
            }
        }
        f ?: Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        typeface = if (bold) Typeface.create(font, Typeface.BOLD) else font
        gravity = Gravity.CENTER
        setLineSpacing(0f, 1.2f)
    }

    private fun openMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Gate.isUnlocked(this)) { openMain(); return }

        window.statusBarColor = GREEN
        window.navigationBarColor = Color.parseColor("#F4F7F5")

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(Color.parseColor("#F1F6F2"))
        }

        // ---------- بالا: سبز با گوشه‌ی گرد ----------
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = GradientDrawable().apply {
                setColor(GREEN)
                val r = dp(44).toFloat()
                cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
            }
            setPadding(dp(24), dp(28), dp(24), dp(96))
        }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.tipax_logo)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "Tipax"
        }, LinearLayout.LayoutParams(dp(230), -2))
        header.addView(tv("Code Scanner", 30f, Color.WHITE).apply {
            textDirection = View.TEXT_DIRECTION_LTR
        }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(2) })
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ecobox)
            scaleType = ImageView.ScaleType.FIT_CENTER
            rotation = -6f
        }, LinearLayout.LayoutParams(dp(230), dp(190)).apply { topMargin = dp(18) })
        page.addView(header, LinearLayout.LayoutParams(-1, -2))

        // ---------- کارت سفید ----------
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(30).toFloat()
                setStroke(dp(1), Color.parseColor("#DCEBE2"))
            }
            elevation = dp(8).toFloat()
            setPadding(dp(24), dp(26), dp(24), dp(22))
        }
        card.addView(tv("به سامانه هوشمند ثبت مرسوله خوش آمدید", 19f, GREEN_DARK, true))
        card.addView(tv("سرعت، دقت و اطمینان در جمع‌آوری مرسوله‌ها؛\nهمراه همیشگی کوریر حرفه‌ای.", 14f, MUTED),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        val pass = EditText(this).apply {
            hint = "رمز ورود"
            setHintTextColor(Color.parseColor("#8A8A8A"))
            setTextColor(Color.parseColor("#17281C"))
            typeface = font
            textSize = 20f
            gravity = Gravity.CENTER
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            imeOptions = EditorInfo.IME_ACTION_DONE
            maxLines = 1
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F7F8F7"))
                cornerRadius = dp(22).toFloat()
                setStroke(dp(1), Color.parseColor("#D5E3DA"))
            }
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        card.addView(pass, LinearLayout.LayoutParams(-1, dp(64)).apply { topMargin = dp(26) })

        val err = tv("رمز اشتباه است", 14f, RED).apply { visibility = View.INVISIBLE }
        card.addView(err, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        val btn = Button(this).apply {
            text = "ورود به سامانه"
            isAllCaps = false
            stateListAnimator = null
            typeface = Typeface.create(font, Typeface.BOLD)
            textSize = 18f
            setTextColor(Color.WHITE)
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.parseColor("#4A9468"), GREEN)
            ).apply { cornerRadius = dp(28).toFloat() }
        }
        card.addView(btn, LinearLayout.LayoutParams(-1, dp(58)).apply { topMargin = dp(10) })
        card.addView(tv("این مرحله فقط یک‌بار، بعد از نصب برنامه انجام می‌شود.", 13f, MUTED),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) })

        page.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
            marginStart = dp(20); marginEnd = dp(20); topMargin = -dp(70)
        })
        page.addView(tv("نسخه اختصاصی سازمانی  •  Sobhan Sedighi  •  v2", 13f, MUTED),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(22); bottomMargin = dp(24) })

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(page)
            setBackgroundColor(Color.parseColor("#F1F6F2"))
        }
        setContentView(scroll)

        // بالای صفحه زیر نوار وضعیت نرود
        scroll.setOnApplyWindowInsetsListener { _, ins ->
            header.setPadding(dp(24), dp(28) + ins.systemWindowInsetTop, dp(24), dp(96))
            ins
        }

        fun submit() {
            if (Gate.check(pass.text.toString())) {
                Gate.unlock(this)
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                    .hideSoftInputFromWindow(pass.windowToken, 0)
                openMain()
            } else {
                err.visibility = View.VISIBLE
                pass.setText("")
                android.animation.ObjectAnimator.ofFloat(pass, "translationX", 0f, -dp(10).toFloat(), dp(10).toFloat(), -dp(6).toFloat(), dp(6).toFloat(), 0f)
                    .apply { duration = 350; start() }
            }
        }
        btn.setOnClickListener { submit() }
        pass.setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_DONE) { submit(); true } else false }
    }
}
