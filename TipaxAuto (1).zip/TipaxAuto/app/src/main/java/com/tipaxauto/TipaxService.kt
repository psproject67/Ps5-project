package com.tipaxauto

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class TipaxService : AccessibilityService() {

    companion object {
        const val TIPAX = "com.tipax.tipax"
        var instance: TipaxService? = null
    }

    private val h = Handler(Looper.getMainLooper())
    private var toggleTries = 0
    private var lastToggle = 0L

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        h.removeCallbacksAndMessages(null)
        Automation.running = false
        return super.onUnbind(intent)
    }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun start() {
        h.removeCallbacksAndMessages(null)
        toggleTries = 0
        lastToggle = 0L
        Automation.running = true
        Automation.setStatus("شروع...")
        h.postDelayed({ tick() }, 2500)
    }

    fun stop(msg: String) {
        h.removeCallbacksAndMessages(null)
        Automation.running = false
        Automation.setStatus(msg)
    }

    private fun wait(msg: String, ms: Long = 1000) {
        Automation.setStatus(msg)
        h.postDelayed({ tick() }, ms)
    }

    private fun tick() {
        if (!Automation.running) return
        if (Automation.index >= Automation.codes.size) { stop("همه بارکدها تموم شد ✓"); return }

        val root = rootInActiveWindow
        if (root == null || root.packageName?.toString() != TIPAX) {
            wait("برنامه تیپاکس را باز کن...")
            return
        }

        // پیام «این مرسوله قبلا جمع آوری شده است» ← زدن «باشه»
        if (findText(root, "قبلا جمع") != null) {
            val ok = findText(root, "باشه")
            if (ok != null) {
                tap(ok)
                wait("مرسوله تکراری بود، «باشه» زده شد", 1200)
                return
            }
        }

        val edit = findEdit(root)
        if (edit == null) {
            val now = System.currentTimeMillis()
            val toggle = findText(root, "تعویض حالت")
            val menu = findText(root, "جمع آوری مرسوله")
            if (toggle != null) {
                if (toggleTries < 3 && now - lastToggle > 6000) {
                    toggleTries++
                    lastToggle = now
                    tap(toggle)
                    wait("زدن «تعویض حالت»...", 1800)
                } else if (toggleTries >= 3 && now - lastToggle > 6000) {
                    stop("فیلد بارکد پیدا نشد. دستی «تعویض حالت» را بزن و دوباره شروع کن.")
                } else {
                    wait("منتظر باز شدن فیلد بارکد...", 800)
                }
            } else if (menu != null) {
                tap(menu)
                wait("رفتن به «جمع آوری مرسوله»...", 2000)
            } else {
                wait("صفحه‌ی «جمع آوری مرسوله» را باز کن...", 1500)
            }
            return
        }

        toggleTries = 0
        val code = Automation.codes[Automation.index]
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, code)
        edit.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        edit.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        Automation.setStatus("در حال ثبت: $code")
        h.postDelayed({ submit() }, 400)
    }

    private fun submit() {
        if (!Automation.running) return
        val root = rootInActiveWindow
        var done = false
        if (root != null) {
            val mode = Automation.submitMode
            if (mode != 2) {
                val s = findSearch(root)
                if (s != null) { tap(s); done = true }
            }
            if (!done && mode != 1 && Build.VERSION.SDK_INT >= 30) {
                val edit = findEdit(root)
                if (edit != null) {
                    done = edit.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
                }
            }
        }
        if (!done) {
            stop("ثبت انجام نشد. «روش ثبت» را در برنامه عوض کن و دوباره شروع کن.")
            return
        }
        Automation.index++
        Automation.save(this)
        Automation.setStatus("ثبت شد ✓")
        h.postDelayed({ tick() }, Automation.delayMs)
    }

    // ---------- ابزارها ----------

    private fun tap(n: AccessibilityNodeInfo) {
        val r = Rect()
        n.getBoundsInScreen(r)
        if (r.isEmpty) { n.performAction(AccessibilityNodeInfo.ACTION_CLICK); return }
        val path = Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
            .build()
        if (!dispatchGesture(g, null, null)) n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun find(n: AccessibilityNodeInfo?, p: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (n == null) return null
        if (p(n)) return n
        for (i in 0 until n.childCount) {
            val r = find(n.getChild(i), p)
            if (r != null) return r
        }
        return null
    }

    private fun norm(s: CharSequence?): String =
        (s?.toString() ?: "").replace('ك', 'ک').replace('ي', 'ی').replace("\u200c", "")
            .filter { !it.isWhitespace() }

    private fun findEdit(root: AccessibilityNodeInfo) = find(root) {
        it.isVisibleToUser && it.className?.toString()?.contains("EditText") == true
    }

    private fun findText(root: AccessibilityNodeInfo, target: String): AccessibilityNodeInfo? {
        val t = norm(target)
        return find(root) {
            it.isVisibleToUser && (norm(it.text).contains(t) || norm(it.contentDescription).contains(t))
        }
    }

    private fun findSearch(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        fun letters(s: CharSequence?) = (s?.toString() ?: "").uppercase().filter { it in 'A'..'Z' }
        return find(root) {
            it.isVisibleToUser && (letters(it.text).contains("SEARCH") || letters(it.contentDescription).contains("SEARCH"))
        }
    }
}
