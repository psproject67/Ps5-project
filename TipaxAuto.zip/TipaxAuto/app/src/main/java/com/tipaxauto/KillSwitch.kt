package com.tipaxauto

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.net.HttpURLConnection
import java.net.URL

/**
 * کلید قطع از راه دور با Supabase: جدول tipax_app_status، ردیف id=1، ستون active.
 * active=false ← برنامه قفل می‌شود. هر خطا (نبودن اینترنت، جدول، ...) ← آخرین وضعیت شناخته‌شده می‌ماند.
 * کلید پایین فقط «publishable» (عمومی و فقط‌خواندنی) است؛ هرگز کلید secret/service_role اینجا نگذار.
 */
object KillSwitch {
    private const val SB_URL = "https://outhyhmxtjiqpswtnrkb.supabase.co"
    private const val SB_KEY = "sb_publishable_BjekGXngklIbglIPSG3h2g_hLDctNd4"
    private const val ENDPOINT = "$SB_URL/rest/v1/tipax_app_status?id=eq.1&select=active"

    @Volatile var disabled = false
    private var lastCheck = 0L
    private val main = Handler(Looper.getMainLooper())

    fun loadCached(ctx: Context) {
        disabled = ctx.getSharedPreferences("ks", Context.MODE_PRIVATE).getBoolean("off", false)
    }

    /** وضعیت را از اینترنت می‌گیرد (حداکثر دقیقه‌ای یک بار، مگر force). done روی ترد اصلی صدا زده می‌شود. */
    fun check(ctx: Context, force: Boolean = false, done: (() -> Unit)? = null) {
        val now = System.currentTimeMillis()
        if (!force && now - lastCheck < 60_000L) { done?.invoke(); return }
        lastCheck = now
        val app = ctx.applicationContext
        Thread {
            try {
                val c = URL(ENDPOINT).openConnection() as HttpURLConnection
                c.connectTimeout = 6000
                c.readTimeout = 6000
                c.useCaches = false
                c.setRequestProperty("apikey", SB_KEY)
                c.setRequestProperty("Accept", "application/json")
                if (c.responseCode == 200) {
                    val t = c.inputStream.bufferedReader().readText()
                    val m = Regex("\"active\"\\s*:\\s*(true|false)").find(t)
                    if (m != null) {
                        val off = m.groupValues[1] == "false"
                        disabled = off
                        app.getSharedPreferences("ks", Context.MODE_PRIVATE).edit().putBoolean("off", off).apply()
                    }
                }
                c.disconnect()
            } catch (_: Exception) {
            }
            main.post { done?.invoke() }
        }.start()
    }
}
