package com.tipaxauto

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream

/** خواندن ستون «شماره بارکد» از xlsx بدون هیچ کتابخانه‌ی خارجی. */
object XlsxReader {
    val CODE = Regex("^[A-Za-z]{2}\\d{6,}[A-Za-z]{2}$")

    private class Cell(val col: String, val row: Int, val v: String)

    private fun norm(s: String) = s.replace('ك', 'ک').replace('ي', 'ی').replace("\u200c", "")

    fun parse(bytes: ByteArray): List<String> {
        var shared: List<String> = emptyList()
        var sheet: ByteArray? = null
        var sheetName = ""
        ZipInputStream(ByteArrayInputStream(bytes)).use { zis ->
            while (true) {
                val e = zis.nextEntry ?: break
                val n = e.name
                if (n == "xl/sharedStrings.xml") {
                    shared = parseShared(zis.readBytes())
                } else if (n.startsWith("xl/worksheets/sheet") && n.endsWith(".xml")) {
                    if (sheet == null || n < sheetName) {
                        sheet = zis.readBytes()
                        sheetName = n
                    }
                }
            }
        }
        val s = sheet ?: throw IllegalStateException("شیتی در فایل پیدا نشد")
        val cells = parseSheet(s, shared)

        val header = cells.firstOrNull { it.row <= 5 && norm(it.v).contains("بارکد") }
        if (header != null) {
            val list = cells.filter { it.col == header.col && it.row > header.row }.map { it.v }
            if (list.isNotEmpty()) return list
        }
        return cells.map { it.v }.filter { CODE.matches(it) }
    }

    private fun parseShared(data: ByteArray): List<String> {
        val p = Xml.newPullParser()
        p.setInput(ByteArrayInputStream(data), null)
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name) {
                    "si" -> sb.setLength(0)
                    "t" -> sb.append(p.nextText())
                }
            } else if (ev == XmlPullParser.END_TAG && p.name == "si") {
                out.add(sb.toString())
            }
            ev = p.next()
        }
        return out
    }

    private fun parseSheet(data: ByteArray, shared: List<String>): List<Cell> {
        val p = Xml.newPullParser()
        p.setInput(ByteArrayInputStream(data), null)
        val out = ArrayList<Cell>()
        var ref = ""
        var type = ""
        var v: String? = null
        val inl = StringBuilder()
        var inC = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name) {
                    "c" -> {
                        inC = true
                        ref = p.getAttributeValue(null, "r") ?: ""
                        type = p.getAttributeValue(null, "t") ?: ""
                        v = null
                        inl.setLength(0)
                    }
                    "v" -> if (inC) v = p.nextText()
                    "t" -> if (inC) inl.append(p.nextText())
                }
            } else if (ev == XmlPullParser.END_TAG && p.name == "c") {
                inC = false
                val value: String? = when (type) {
                    "s" -> v?.toIntOrNull()?.let { shared.getOrNull(it) }
                    "inlineStr" -> inl.toString()
                    else -> v
                }
                if (!value.isNullOrBlank() && ref.isNotEmpty()) {
                    val col = ref.takeWhile { it.isLetter() }
                    val row = ref.dropWhile { it.isLetter() }.toIntOrNull() ?: 0
                    out.add(Cell(col, row, value.trim()))
                }
            }
            ev = p.next()
        }
        return out
    }
}
