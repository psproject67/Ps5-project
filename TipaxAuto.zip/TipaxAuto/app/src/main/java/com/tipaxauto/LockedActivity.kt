package com.tipaxauto

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** صفحه‌ی «برنامه توسط مدیر غیرفعال شده است». هر ۱۵ ثانیه خودش دوباره بررسی می‌کند. */
class LockedActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private val poll = object : Runnable {
        override fun run() { check(false); ui.postDelayed(this, 15_000) }
    }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        typeface = Typeface.create("sans-serif-medium", if (bold) Typeface.BOLD else Typeface.NORMAL)
        gravity = Gravity.CENTER
        setLineSpacing(0f, 1.25f)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#7A1518")
        window.navigationBarColor = Color.parseColor("#7A1518")

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(28), dp(28), dp(28), dp(28))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#7A1518"), Color.parseColor("#B3262B"))
            )
        }
        root.addView(tv("🔒", 56f, Color.WHITE))
        root.addView(tv("برنامه غیرفعال است", 24f, Color.WHITE, true),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) })
        root.addView(tv("استفاده از این برنامه فعلاً توسط مدیر متوقف شده است.\nبرای فعال شدن دوباره با مدیر تماس بگیرید.", 15f, Color.parseColor("#FFE3E0")),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        status = tv(" ", 13f, Color.parseColor("#FFD0CB"))
        root.addView(status, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(22) })

        val btn = Button(this).apply {
            text = "بررسی دوباره"
            isAllCaps = false
            stateListAnimator = null
            textSize = 16f
            setTextColor(Color.parseColor("#7A1518"))
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(20).toFloat() }
            setOnClickListener { check(true) }
        }
        root.addView(btn, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(10) })
        setContentView(root)
    }

    override fun onResume() { super.onResume(); ui.post(poll) }
    override fun onPause() { super.onPause(); ui.removeCallbacks(poll) }

    private fun check(manual: Boolean) {
        if (manual) status.text = "در حال بررسی…"
        RemoteSwitch.refresh(this) { locked ->
            if (!locked) {
                startActivity(Intent(this, GateActivity::class.java))
                finish()
            } else if (manual) {
                status.text = "هنوز غیرفعال است."
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { finishAffinity() }
}
