package com.tipaxauto

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient

/** پنل مدیر (tipax-switch.html) داخل خود برنامه. باز کردنش: نگه داشتن انگشت روی نوشته‌ی «Sobhan Sedighi». رمز مدیر را سرور چک می‌کند. */
class AdminActivity : Activity() {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#00573A")
        web = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#EAF3EE"))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true          // فقط برای خواندن همین فایل داخل assets
            settings.allowContentAccess = false
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            loadUrl("file:///android_asset/tipax-switch.html")
        }
        setContentView(web)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else finish() }

    override fun onDestroy() { web.destroy(); super.onDestroy() }
}
