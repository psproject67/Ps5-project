package com.tipaxauto

import android.content.Context

/** وضعیت مشترک بین صفحه اصلی و سرویس (همه روی main thread). */
object Automation {
    var codes: List<String> = emptyList()
    var fileKey: String = ""
    var index = 0
    var delayMs = 2000L
    var submitMode = 0          // 0 خودکار، 1 فقط دکمه SEARCH، 2 فقط Enter
    var running = false
    var statusText = "آماده"
    var listener: (() -> Unit)? = null

    fun setStatus(s: String) {
        statusText = s
        listener?.invoke()
    }

    fun save(ctx: Context) {
        if (fileKey.isEmpty()) return
        ctx.getSharedPreferences("tipax", Context.MODE_PRIVATE)
            .edit().putInt("pos_$fileKey", index).apply()
    }
}
