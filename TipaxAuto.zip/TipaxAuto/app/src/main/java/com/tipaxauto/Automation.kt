package com.tipaxauto

import android.content.Context
import java.io.File
import java.util.concurrent.Executors

/** وضعیت مشترک بین صفحه اصلی و سرویس (همه روی main thread). */
object Automation {
    var codes: List<String> = emptyList()
    var fileKey: String = ""
    var index = 0
    var delayMs = 2000L
    var perMinute = 35          // سرعت هدف: بارکد در دقیقه
    var runStart = 0L
    var runDone = 0
    var submitMode = 0          // 0 خودکار، 1 فقط دکمه SEARCH، 2 فقط Enter
    var username = ""
    var password = ""
    var running = false
    var statusText = "آماده"
    var listener: (() -> Unit)? = null

    /** سرعت واقعی همین اجرا، برای نمایش کنار وضعیت. */
    fun rateSuffix(): String {
        if (!running || runDone < 3) return ""
        val ms = android.os.SystemClock.uptimeMillis() - runStart
        if (ms <= 0) return ""
        val r = (runDone * 60000L / ms).toString().map { '۰' + (it - '0') }.joinToString("")
        return "  |  سرعت: $r در دقیقه"
    }

    fun setStatus(s: String) {
        statusText = s
        listener?.invoke()
    }

    fun save(ctx: Context) {
        if (fileKey.isEmpty()) return
        ctx.getSharedPreferences("tipax", Context.MODE_PRIVATE)
            .edit().putInt("pos_$fileKey", index).apply()
    }

    /** «این مرسوله قبلا جمع آوری شده است» (ارور قرمز) */
    val dupList = CodeList("failed")
    /** هر ارور دیگری که با پیام «باشه» آمد (مثلاً «امکان ثبت وجود ندارد») */
    val otherList = CodeList("other")
    /** بارکدهایی که ثبتشان تایید شده (موفق یا ارور)؛ هیچ‌کدام دوباره زده نمی‌شوند. */
    val sentList = SentLog()
    /** بارکدهایی که با موفقیت ثبت شدند (صفحه سبز شد)، به ترتیب ثبت. */
    val okList = OkLog()

    /** وقتی تعداد لیست سبز یا قرمز به این عدد رسید، همان لیست پاک می‌شود (sentList دست نمی‌خورد، پس بارکدی دوباره زده نمی‌شود). */
    const val MAX_LIST = 50

    fun addOk(ctx: Context, code: String) {
        okList.add(ctx, code)
        if (okList.items.size >= MAX_LIST) okList.clear(ctx)
        listener?.invoke()
    }

    fun addFailed(ctx: Context, code: String, dup: Boolean) {
        (if (dup) dupList else otherList).add(ctx, code)
        if (dup && dupList.items.size >= MAX_LIST) dupList.clear(ctx)
        listener?.invoke()
    }

    fun clearFailed(ctx: Context) {
        dupList.clear(ctx)
        otherList.clear(ctx)
        sentList.clear(ctx)
        okList.clear(ctx)
        listener?.invoke()
    }

    /** بعد از انتخاب فایل، لیست‌های قبلیِ همان فایل برمی‌گردند. */
    fun loadFailed(ctx: Context) {
        dupList.load(ctx)
        otherList.load(ctx)
        sentList.load(ctx)
        okList.load(ctx)
    }

    fun failedVersion() = dupList.version + otherList.version
}

/**
 * نوشتن روی دیسک همیشه روی یک ترد پس‌زمینه انجام می‌شود (به ترتیب)، تا ترد اصلی و سرویس کند نشوند.
 */
internal object AppendIo {
    private val ex = Executors.newSingleThreadExecutor { r -> Thread(r, "tipax-io").apply { isDaemon = true } }

    fun append(f: File, line: String) {
        ex.execute { try { f.appendText(line + "\n") } catch (_: Exception) {} }
    }

    fun delete(f: File) {
        ex.execute { try { f.delete() } catch (_: Exception) {} }
    }

    /** صبر تا همه نوشتن‌های در صف تمام شود (قبل از خواندن فایل). */
    fun flush() {
        try { ex.submit(Runnable { }).get() } catch (_: Exception) {}
    }
}

/**
 * لیست بارکدها (بدون تکرار، با حفظ ترتیب)؛ ذخیره‌سازی فقط با اضافه‌کردن به انتهای فایل،
 * پس با هزاران مورد هم سبک است (قبلاً با هر مورد کل لیست دوباره ذخیره می‌شد).
 */
class CodeList(private val prefix: String) {
    val items = ArrayList<String>()
    private val set = HashSet<String>()
    var version = 0
        private set

    private fun file(ctx: Context) = File(ctx.filesDir, "${prefix}_${Automation.fileKey}.log")
    private fun legacyKey() = "${prefix}_${Automation.fileKey}"

    fun add(ctx: Context, code: String) {
        if (!set.add(code)) return
        items.add(code)
        version++
        if (Automation.fileKey.isEmpty()) return
        AppendIo.append(file(ctx), code)
    }

    fun clear(ctx: Context) {
        if (items.isNotEmpty()) { items.clear(); set.clear(); version++ }
        if (Automation.fileKey.isEmpty()) return
        AppendIo.delete(file(ctx))
        ctx.getSharedPreferences("tipax", Context.MODE_PRIVATE).edit().remove(legacyKey()).apply()
    }

    fun contains(code: String) = set.contains(code)

    fun clearMemory() {
        items.clear(); set.clear(); version++
    }

    fun load(ctx: Context) {
        items.clear(); set.clear(); version++
        if (Automation.fileKey.isEmpty()) return
        AppendIo.flush()
        try {
            val f = file(ctx)
            if (f.exists()) {
                f.forEachLine { val t = it.trim(); if (t.isNotEmpty() && set.add(t)) items.add(t) }
            } else {
                // انتقال از روش قدیمی (SharedPreferences) به فایل
                val sp = ctx.getSharedPreferences("tipax", Context.MODE_PRIVATE)
                val raw = sp.getString(legacyKey(), "") ?: ""
                raw.split("\n").map { it.trim() }.filter { it.isNotEmpty() }.forEach { if (set.add(it)) items.add(it) }
                if (items.isNotEmpty()) f.writeText(items.joinToString("\n") + "\n")
                if (raw.isNotEmpty()) sp.edit().remove(legacyKey()).apply()
            }
        } catch (_: Exception) {}
    }
}

/**
 * لیست بارکدهای تاییدشده؛ هر مورد فقط به انتهای یک فایل اضافه می‌شود (بدون بازنویسی کل لیست)،
 * پس حتی با صدها هزار بارکد هم سبک و سریع می‌ماند.
 */
class SentLog {
    private val set = HashSet<String>()

    private fun file(ctx: Context) = File(ctx.filesDir, "sent_${Automation.fileKey}.log")

    fun contains(code: String) = set.contains(code)

    fun add(ctx: Context, code: String) {
        if (Automation.fileKey.isEmpty() || !set.add(code)) return
        AppendIo.append(file(ctx), code)
    }

    fun clear(ctx: Context) {
        set.clear()
        if (Automation.fileKey.isEmpty()) return
        AppendIo.delete(file(ctx))
    }

    fun clearMemory() { set.clear() }

    fun load(ctx: Context) {
        set.clear()
        if (Automation.fileKey.isEmpty()) return
        AppendIo.flush()
        try {
            val f = file(ctx)
            if (f.exists()) f.forEachLine { val t = it.trim(); if (t.isNotEmpty()) set.add(t) }
        } catch (_: Exception) {}
    }
}

/** لیست بارکدهای موفق (بدون تکرار، با حفظ ترتیب)؛ ذخیره‌سازی فقط با اضافه‌کردن به انتهای فایل، پس با تعداد خیلی زیاد هم سبک است. */
class OkLog {
    val items = ArrayList<String>()
    private val set = HashSet<String>()
    var version = 0
        private set

    private fun file(ctx: Context) = File(ctx.filesDir, "ok_${Automation.fileKey}.log")

    fun add(ctx: Context, code: String) {
        if (!set.add(code)) return
        items.add(code)
        version++
        if (Automation.fileKey.isEmpty()) return
        AppendIo.append(file(ctx), code)
    }

    fun clear(ctx: Context) {
        if (items.isNotEmpty()) { items.clear(); set.clear(); version++ }
        if (Automation.fileKey.isEmpty()) return
        AppendIo.delete(file(ctx))
    }

    fun clearMemory() {
        items.clear(); set.clear(); version++
    }

    fun load(ctx: Context) {
        items.clear(); set.clear(); version++
        if (Automation.fileKey.isEmpty()) return
        AppendIo.flush()
        try {
            val f = file(ctx)
            if (f.exists()) f.forEachLine { val t = it.trim(); if (t.isNotEmpty() && set.add(t)) items.add(t) }
        } catch (_: Exception) {}
    }
}
