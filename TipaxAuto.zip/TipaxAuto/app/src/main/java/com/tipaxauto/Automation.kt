package com.tipaxauto

import android.content.Context

/** وضعیت مشترک بین صفحه اصلی و سرویس (همه روی main thread). */
object Automation {
    var codes: List<String> = emptyList()
    var fileKey: String = ""
    var index = 0
    var delayMs = 2000L
    var submitMode = 0          // 0 خودکار، 1 فقط دکمه SEARCH، 2 فقط Enter
    var username = ""
    var password = ""
    var running = false
    var statusText = "آماده"
    var listener: (() -> Unit)? = null

    fun setStatus(s: String) {
        statusText = s
        listener?.invoke()
    }

    fun save(ctx: Context) {
        if (fileKey.isEmpty()) return
        ctx.getSharedPreferences("tipax", Context.MODE_PRIVATE)
            .edit().putInt("pos_$fileKey", index).apply()
    }

    /** «این مرسوله قبلا جمع آوری شده است» (ارور قرمز) */
    val dupList = CodeList("failed")
    /** هر ارور دیگری که با پیام «باشه» آمد (مثلاً «امکان ثبت وجود ندارد») */
    val otherList = CodeList("other")
    /** بارکدهایی که ثبتشان تایید شده (موفق یا ارور)؛ هیچ‌کدام دوباره زده نمی‌شوند. */
    val sentList = CodeList("sent")

    fun addFailed(ctx: Context, code: String, dup: Boolean) {
        (if (dup) dupList else otherList).add(ctx, code)
        listener?.invoke()
    }

    fun clearFailed(ctx: Context) {
        dupList.clear(ctx)
        otherList.clear(ctx)
        sentList.clear(ctx)
        listener?.invoke()
    }

    /** بعد از انتخاب فایل، لیست‌های قبلیِ همان فایل برمی‌گردند. */
    fun loadFailed(ctx: Context) {
        dupList.load(ctx)
        otherList.load(ctx)
        sentList.load(ctx)
    }

    fun failedVersion() = dupList.version + otherList.version
}

/** لیست بارکدها (بدون تکرار، با حفظ ترتیب) که روی همین گوشی ذخیره می‌شود. حتی با ۱۰۰۰ مورد سبک است. */
class CodeList(private val prefix: String) {
    val items = ArrayList<String>()
    private val set = HashSet<String>()
    var version = 0
        private set

    fun add(ctx: Context, code: String) {
        if (!set.add(code)) return
        items.add(code)
        version++
        save(ctx)
    }

    fun clear(ctx: Context) {
        if (items.isEmpty()) return
        items.clear(); set.clear(); version++
        save(ctx)
    }

    fun contains(code: String) = set.contains(code)

    fun clearMemory() {
        items.clear(); set.clear(); version++
    }

    fun load(ctx: Context) {
        items.clear(); set.clear(); version++
        if (Automation.fileKey.isEmpty()) return
        val raw = ctx.getSharedPreferences("tipax", Context.MODE_PRIVATE)
            .getString("${prefix}_${Automation.fileKey}", "") ?: ""
        raw.split("\n").map { it.trim() }.filter { it.isNotEmpty() }.forEach { if (set.add(it)) items.add(it) }
    }

    private fun save(ctx: Context) {
        if (Automation.fileKey.isEmpty()) return
        ctx.getSharedPreferences("tipax", Context.MODE_PRIVATE)
            .edit().putString("${prefix}_${Automation.fileKey}", items.joinToString("\n")).apply()
    }
}
