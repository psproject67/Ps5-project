package com.tipaxauto

import android.content.Context

/** وضعیت مشترک بین صفحه اصلی و سرویس (همه روی main thread). */
object Automation {
    var codes: List<String> = emptyList()
    var fileKey: String = ""
    var index = 0
    var delayMs = 2000L
    var submitMode = 0          // 0 خودکار، 1 فقط دکمه SEARCH، 2 فقط Enter
    var username = ""
    var password = ""
    var running = false
    var statusText = "آماده"
    var listener: (() -> Unit)? = null

    /** بارکدهایی که تیپاکس برایشان ارور داد (مثلاً «امکان ثبت این مرسوله وجود ندارد»). */
    val failed = ArrayList<String>()

    fun setStatus(s: String) {
        statusText = s
        listener?.invoke()
    }

    fun save(ctx: Context) {
        if (fileKey.isEmpty()) return
        ctx.getSharedPreferences("tipax", Context.MODE_PRIVATE)
            .edit().putInt("pos_$fileKey", index).apply()
    }

    fun addFailed(ctx: Context, code: String) {
        if (!failed.contains(code)) {
            failed.add(code)
            saveFailed(ctx)
        }
        listener?.invoke()
    }

    fun clearFailed(ctx: Context) {
        failed.clear()
        saveFailed(ctx)
        listener?.invoke()
    }

    /** بعد از انتخاب فایل، ارورهای قبلیِ همان فایل برمی‌گردند. */
    fun loadFailed(ctx: Context) {
        failed.clear()
        if (fileKey.isEmpty()) return
        val raw = ctx.getSharedPreferences("tipax", Context.MODE_PRIVATE)
            .getString("failed_$fileKey", "") ?: ""
        failed.addAll(raw.split("\n").map { it.trim() }.filter { it.isNotEmpty() })
    }

    private fun saveFailed(ctx: Context) {
        if (fileKey.isEmpty()) return
        ctx.getSharedPreferences("tipax", Context.MODE_PRIVATE)
            .edit().putString("failed_$fileKey", failed.joinToString("\n")).apply()
    }
}
