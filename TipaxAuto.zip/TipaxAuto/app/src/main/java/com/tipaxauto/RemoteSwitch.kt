package com.tipaxauto

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

/**
 * کلید روشن/خاموش از راه دور (همان جدول Supabase که صفحه‌ی tipax-switch.html عوضش می‌کند).
 * اگر مدیر «خاموش» کند، برنامه قفل می‌شود و صفحه‌ی «غیرفعال شده» نشان می‌دهد.
 * اگر اینترنت قطع باشد، آخرین وضعیتِ شناخته‌شده می‌ماند (قفل نشده بود → کار می‌کند، قفل بود → قفل می‌ماند).
 */
object RemoteSwitch {
    // فقط کلید «publishable» (عمومی) اینجاست؛ هرگز کلید secret / service_role را نگذار.
    const val SB_URL = "https://outhyhmxtjiqpswtnrkb.supabase.co"
    const val SB_KEY = "sb_publishable_BjekGXngklIbglIPSG3h2g_hLDctNd4"

    const val CHECK_EVERY_MS = 60_000L
    private const val KEY_LOCKED = "remote_locked"
    private val main = Handler(Looper.getMainLooper())

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(Gate.PREFS, Context.MODE_PRIVATE)

    fun isLocked(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_LOCKED, false)

    /** وضعیت را از اینترنت می‌گیرد؛ نتیجه (قفل است؟) روی main thread به done داده می‌شود. */
    fun refresh(ctx: Context, done: ((locked: Boolean) -> Unit)? = null) {
        val app = ctx.applicationContext
        thread(name = "remote-switch") {
            try {
                val c = URL("$SB_URL/rest/v1/tipax_app_status?id=eq.1&select=active")
                    .openConnection() as HttpURLConnection
                c.connectTimeout = 8000
                c.readTimeout = 8000
                c.setRequestProperty("apikey", SB_KEY)
                c.setRequestProperty("Accept", "application/json")
                c.useCaches = false
                if (c.responseCode == 200) {
                    val rows = JSONArray(c.inputStream.bufferedReader().use { it.readText() })
                    if (rows.length() > 0) {
                        val active = rows.getJSONObject(0).optBoolean("active", true)
                        prefs(app).edit().putBoolean(KEY_LOCKED, !active).apply()
                    }
                }
                c.disconnect()
            } catch (_: Exception) {
                // اینترنت یا سرور در دسترس نیست؛ وضعیت قبلی می‌ماند
            }
            main.post { done?.invoke(isLocked(app)) }
        }
    }
}
