package com.tipaxauto

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class TipaxService : AccessibilityService() {

    companion object {
        const val TIPAX = "com.tipax.tipax"
        var instance: TipaxService? = null
    }

    private val h = Handler(Looper.getMainLooper())
    private var toggleTries = 0
    private var lastToggle = 0L
    private var loginTries = 0
    /** آخرین بارکدی که ثبتش زده شده و هنوز نتیجه‌اش (ارور/تکراری) مشخص نیست. */
    private var lastSent: String? = null
    /** بارکدی که ثبتش زده شده ولی هنوز تایید نشده؛ تا تایید نشود به بارکد بعدی نمی‌رویم (هیچ بارکدی رد نمی‌شود). */
    private var inFlight: String? = null
    private var tries = 0
    private var baseSig = 0
    private var sawChange = false
    /** آیا نتیجه‌ی همین بارکد (صفحه سبز/ارور با خود بارکد) روی صفحه دیده شده؟ */
    private var resultSeen = false
    private var cycleStart = 0L
    /** چند بار بعد از آخرین بارکد صبر کرده‌ایم تا مطمئن شویم پیام ارور دیر نیامده. */
    private var endChecks = 0
    private var editMissingSince = 0L

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean {
        showKeyboard()
        instance = null
        h.removeCallbacksAndMessages(null)
        Automation.running = false
        return super.onUnbind(intent)
    }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun start() {
        h.removeCallbacksAndMessages(null)
        toggleTries = 0
        lastToggle = 0L
        loginTries = 0
        lastSent = null
        inFlight = null
        tries = 0
        sawChange = false
        resultSeen = false
        Automation.runStart = SystemClock.uptimeMillis()
        Automation.runDone = 0
        endChecks = 0
        editMissingSince = 0L
        Automation.running = true
        hideKeyboard()
        Automation.setStatus("شروع شد...")
        h.postDelayed({ tick() }, 2500)
    }

    fun stop(msg: String) {
        h.removeCallbacksAndMessages(null)
        Automation.running = false
        showKeyboard()
        Automation.setStatus(msg)
    }

    private fun wait(msg: String, ms: Long = 1000) {
        Automation.setStatus(msg)
        h.postDelayed({ tick() }, ms)
    }

    private fun tick() {
        if (!Automation.running) return
        hideKeyboard()
        skipSent()
        val finished = Automation.index >= Automation.codes.size

        val root = rootInActiveWindow
        if (root == null || root.packageName?.toString() != TIPAX) {
            if (finished) { stop(doneMessage()); return }
            wait("منتظر باز شدن تیپاکس...")
            return
        }

        // صفحه ورود تیپاکس ← وارد کردن نام کاربری و رمز
        if (!finished && handleLogin(root)) return
        loginTries = 0

        // پیام «این مرسوله قبلا جمع آوری شده است» ← زدن «باشه»
        // هر پیام تمام‌صفحه‌ای که دکمه «باشه» دارد (تکراری، «امکان ثبت ... وجود ندارد» و ...) ← زدن «باشه»
        val ok = findOk(root)
        if (ok != null) {
            val dup = findText(root, "قبلا جمع") != null
            // هر ارور قرمز (تکراری یا «امکان ثبت ندارد») ← بارکد در لیست خطاها ثبت می‌شود
            recordError(root, dup)
            endChecks = 0
            clickNode(ok)
            Automation.setStatus(if (dup) "مرسوله تکراری بود؛ رد شد" else "امکان ثبت این مرسوله نبود؛ رد شد")
            h.postDelayed({ closeDialog(0) }, 150)
            return
        }

        // همه‌ی بارکدها زده شده؛ کمی صبر می‌کنیم تا ارور آخرین بارکد (اگر دیر آمد) هم دیده شود
        if (finished) {
            if (endChecks < 4) {
                endChecks++
                wait("بررسی آخرین بارکد...", 700)
            } else {
                stop(doneMessage())
            }
            return
        }

        val edit = findEdit(root)
        if (edit == null) {
            val now = System.currentTimeMillis()
            // فیلد ممکن است فقط لحظه‌ای (وسط انیمیشن/بارگذاری) نمایان نباشد؛ تا ۳ ثانیه فقط صبر می‌کنیم
            if (editMissingSince == 0L) editMissingSince = now
            if (now - editMissingSince < 1500) {
                wait("منتظر نمایش فیلد بارکد...", 300)
                return
            }
            val toggle = findText(root, "تعویض حالت")
            val menu = findText(root, "جمع آوری مرسوله")
            if (toggle != null) {
                if (toggleTries < 3 && now - lastToggle > 6000) {
                    toggleTries++
                    lastToggle = now
                    tap(toggle)
                    wait("در حال تعویض حالت...", 1800)
                } else if (toggleTries >= 3 && now - lastToggle > 6000) {
                    stop("فیلد بارکد پیدا نشد. دستی «تعویض حالت» را بزن و دوباره شروع کن.")
                } else {
                    wait("منتظر باز شدن فیلد بارکد...", 800)
                }
            } else if (menu != null) {
                tap(menu)
                wait("رفتن به «جمع آوری مرسوله»...", 2000)
            } else {
                wait("در حال باز کردن «جمع آوری مرسوله»...", 1500)
            }
            return
        }

        toggleTries = 0
        editMissingSince = 0L
        val code = Automation.codes[Automation.index]
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, code)
        fixTries = 0
        cycleStart = SystemClock.uptimeMillis()
        edit.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        Automation.setStatus("در حال ثبت: $code")
        h.postDelayed({ submit() }, 250)
    }


    /**
     * تا وقتی پیام ارور بسته نشده منتظر می‌ماند (و اگر کلیک اثر نکرد دوباره می‌زند)؛
     * بعد از بسته شدن هم صبر می‌کند تا فیلد بارکد دوباره نمایان شود، و فقط آن‌وقت ادامه می‌دهد
     * (وگرنه ممکن بود وسط انیمیشن، «تعویض حالت» اشتباهی زده شود و برنامه روی یک بارکد گیر کند).
     */
    private fun closeDialog(tries: Int) {
        if (!Automation.running) return
        val root = rootInActiveWindow
        val ok = root?.let { findOk(it) }
        if (ok != null) {
            if (tries < 10) {
                if (tries % 3 == 2) clickNode(ok)
                h.postDelayed({ closeDialog(tries + 1) }, 150)
            } else {
                h.postDelayed({ tick() }, 100)
            }
            return
        }
        val finished = Automation.index >= Automation.codes.size
        val fieldBack = root != null && root.packageName?.toString() == TIPAX && findEdit(root) != null
        if (fieldBack && !finished) {
            // پیام بسته شد؛ صبر می‌کنیم صفحه کاملاً به حالت عادی برگردد
            val t = SystemClock.uptimeMillis()
            h.postDelayed({ waitIdle(null, t, 0, t) }, 200)
        } else if (finished || tries >= 40) {
            h.postDelayed({ tick() }, 60)
        } else {
            h.postDelayed({ closeDialog(tries + 1) }, 100)
        }
    }

    private var fixTries = 0

    /** اگر صفحه ورود باز بود، کارهای لازم را انجام می‌دهد و true برمی‌گرداند. */
    private fun handleLogin(root: AccessibilityNodeInfo): Boolean {
        val edits = ArrayList<AccessibilityNodeInfo>()
        fun collect(n: AccessibilityNodeInfo?) {
            if (n == null) return
            if (n.isVisibleToUser && n.className?.toString()?.contains("EditText") == true) edits.add(n)
            for (i in 0 until n.childCount) collect(n.getChild(i))
        }
        collect(root)
        val pwd = edits.firstOrNull { it.isPassword }
        val prompt = findText(root, "نام کاربری و رمز عبور")
        if (edits.size < 2 || (pwd == null && prompt == null)) return false

        val passField = pwd ?: edits[1]
        val userField = edits.first { it != passField }

        if (Automation.username.isEmpty() || Automation.password.isEmpty()) {
            stop("صفحه ورود تیپاکس باز شد. نام کاربری و رمز را در برنامه وارد کن و دوباره شروع کن.")
            return true
        }
        if (loginTries >= 3) {
            stop("ورود ناموفق بود. نام کاربری و رمز را بررسی کن و دوباره شروع کن.")
            return true
        }
        loginTries++
        Automation.setStatus("در حال ورود به تیپاکس...")

        userField.refresh()
        if ((userField.text?.toString() ?: "") != Automation.username) setCode(userField, Automation.username)
        setCode(passField, Automation.password)

        h.postDelayed({
            if (!Automation.running) return@postDelayed
            val r = rootInActiveWindow ?: return@postDelayed
            val btn = find(r) { it.isVisibleToUser && norm(it.text) == norm("ورود") }
            if (btn != null) tap(btn)
        }, 700)
        h.postDelayed({ tick() }, 4000)
        return true
    }

    private fun setCode(edit: AccessibilityNodeInfo, code: String) {
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, code)
        edit.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun submit() {
        if (!Automation.running) return
        val root = rootInActiveWindow
        var done = false

        // اگر هنوز پیام ارور (مربوط به بارکد قبلی) روی صفحه است، این بارکد را نزن؛
        // tick اول پیام را ثبت و می‌بندد و بعد همین بارکد دوباره وارد می‌شود (هیچ بارکدی گم نمی‌شود)
        if (root != null && root.packageName?.toString() == TIPAX && findOk(root) != null) {
            h.postDelayed({ tick() }, 100)
            return
        }

        // اگر کیبورد حرف اضافه (مثل y) اول بارکد گذاشت، متن را پاک و دوباره درست وارد کن
        val code = Automation.codes.getOrNull(Automation.index)
        val field = root?.let { findEdit(it) }
        if (code != null && field != null) {
            field.refresh()
            val cur = field.text?.toString() ?: ""
            if (cur != code && fixTries < 4) {
                fixTries++
                setCode(field, "")
                h.postDelayed({
                    if (Automation.running) {
                        rootInActiveWindow?.let { r -> findEdit(r)?.let { setCode(it, code) } }
                        h.postDelayed({ submit() }, 350)
                    }
                }, 250)
                return
            }
        }
        // هرگز متن اشتباه ثبت نمی‌شود: اگر بعد از چند تلاش هنوز متن فیلد با بارکد یکی نیست، متوقف می‌شود
        if (code == null || field == null) { h.postDelayed({ tick() }, 150); return }
        run {
            field.refresh()
            if ((field.text?.toString() ?: "") != code) {
                stop("متن فیلد با بارکد $code یکی نشد؛ برای جلوگیری از ثبت اشتباه متوقف شد. دوباره شروع کن.")
                return
            }
        }
        val sig0 = if (root != null) signature(root) else 0
        fixTries = 0
        if (root != null) {
            val mode = Automation.submitMode
            if (mode != 2) {
                val s = findSearch(root)
                if (s != null) { tap(s); done = true }
            }
            if (!done && mode != 1 && Build.VERSION.SDK_INT >= 30) {
                val edit = findEdit(root)
                if (edit != null) {
                    done = edit.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
                }
            }
        }
        if (!done) {
            stop("ثبت انجام نشد. «روش ثبت» را در برنامه عوض کن و دوباره شروع کن.")
            return
        }
        lastSent = code
        inFlight = code
        baseSig = sig0
        sawChange = false
        resultSeen = false
        Automation.setStatus("ثبت زده شد؛ منتظر نتیجه (سبز یا قرمز) و برگشت صفحه به حالت عادی...")
        val t = SystemClock.uptimeMillis()
        h.postDelayed({ waitIdle(code, t, 0, t) }, 200)
    }

    /** بارکد تایید شد ← ذخیره، و فقط حالا شاخص یکی جلو می‌رود. */
    private fun advance(code: String, success: Boolean) {
        Automation.sentList.add(this, code)
        if (success) Automation.addOk(this, code)
        Automation.runDone++
        if (Automation.codes.getOrNull(Automation.index) == code) {
            Automation.index++
            Automation.save(this)
        }
        inFlight = null
        lastSent = null
        tries = 0
        sawChange = false
        resultSeen = false
    }

    /** تایید نشد: اگر صفحه اصلاً واکنشی نشان نداده (کلیک نگرفته) دوباره می‌زند، وگرنه متوقف می‌شود. */
    private fun unconfirmed(code: String) {
        if (!sawChange && tries < 2) {
            tries++
            Automation.setStatus("ثبت $code تایید نشد؛ تلاش دوباره ($tries)")
            h.postDelayed({ tick() }, 400)
            return
        }
        Automation.save(this)
        stop("بارکد $code تایید نشد (تیپاکس جواب نداد یا ثبت نشد). از همین بارکد ادامه بده؛ هیچ بارکدی رد نشده.")
    }

    /**
     * بعد از ثبت هر بارکد صبر می‌کند تا:
     *  ۱) پیام ارور بیاید (← tick آن را مدیریت می‌کند)، یا
     *  ۲) صفحه کاملاً به حالت عادی برگردد: فیلد بارکد نمایان و خالی شده، هیچ لودینگی نیست
     *     و ظاهر صفحه حداقل نیم‌ثانیه ثابت مانده (یعنی انیمیشن سبز/لود تمام شده).
     * فقط بعد از آن بارکد بعدی وارد می‌شود. بارکد فقط وقتی «ثبت‌شده» حساب می‌شود که به این حالت برسیم.
     */
    private fun waitIdle(sent: String?, start: Long, lastSig: Int, stableSince: Long) {
        if (!Automation.running) return
        val now = SystemClock.uptimeMillis()
        val root = rootInActiveWindow
        var sig = 0
        var busy = false
        var field: AccessibilityNodeInfo? = null
        if (root != null && root.packageName?.toString() == TIPAX) {
            if (findOk(root) != null) { h.postDelayed({ tick() }, 100); return }   // قرمز ← tick مدیریت می‌کند
            // وسط کار صفحه ورود آمد (نشست تمام شد) ← tick وارد می‌شود و همان بارکد دوباره زده می‌شود
            if (find(root) { it.isVisibleToUser && it.isPassword } != null) {
                h.postDelayed({ tick() }, 100); return
            }
            sig = signature(root)
            busy = hasProgress(root)
            field = findEdit(root)
            // سبز: خودِ بارکد در جایی غیر از فیلد ورودی روی صفحه ظاهر شده
            if (sent != null && !resultSeen && resultVisible(root, sent)) resultSeen = true
        }
        if (sent != null && sig != 0 && sig != baseSig) sawChange = true
        val stableNow = if (sig != 0 && sig == lastSig) stableSince else now
        val stableFor = now - stableNow
        val elapsed = now - start

        if (sent == null) {
            // بعد از بسته شدن پیام ارور: صبر کن فیلد برگردد و صفحه آرام شود (یا حداکثر چند ثانیه)
            if (!busy && ((field != null && elapsed >= 500 && stableFor >= 350) || elapsed >= 5000)) {
                h.postDelayed({ tick() }, paceDelay()); return
            }
        } else if (!busy && elapsed >= 500) {
            var cleared = false
            if (field != null) {
                field.refresh()
                cleared = (field.text?.toString() ?: "") != sent
            }
            val calm = stableFor >= 350
            val wait = maxOf(Automation.delayMs, 1500L)
            val confirmed =
                // سبز: خودِ بارکد روی صفحه‌ی نتیجه دیده شد (حتی اگر فیلد پنهان است) و صفحه آرام شد
                (resultSeen && (calm || elapsed >= 4000)) ||
                // فیلد خالی شد و صفحه به اندازه‌ی «حداکثر انتظار» آرام ماند (یا بعد از ۶ ثانیه)
                (cleared && (stableFor >= wait || elapsed >= 6000)) ||
                // صفحه‌ی اسکن عوض شد (فیلد رفته) و آرام شد ← صفحه‌ی نتیجه بود؛ tick فیلد را برمی‌گرداند
                (field == null && sawChange && (stableFor >= 1000 || elapsed >= 5000))
            if (confirmed) {
                advance(sent, true)
                h.postDelayed({ tick() }, paceDelay())
                return
            }
            // هیچ تغییری نکرد و فیلد هم خالی نشد: احتمالاً کلیک «جستجو» نگرفته
            if (field != null && !cleared && !sawChange && stableFor >= maxOf(Automation.delayMs, 2500L)) {
                unconfirmed(sent); return
            }
        }

        // سقف انتظار تا برنامه برای همیشه گیر نکند
        if (elapsed >= 30000L) {
            if (sent == null) h.postDelayed({ tick() }, 100) else unconfirmed(sent)
            return
        }

        val sec = (elapsed / 1000).toInt()
        val base = if (busy) "در حال بارگذاری تیپاکس" else "منتظر نتیجه (سبز یا قرمز)"
        val msg = "$base... ${sec}s" + (if (field == null) " | فیلد نیست" else "")
        if (Automation.statusText != msg) Automation.setStatus(msg)
        h.postDelayed({ waitIdle(sent, start, sig, stableNow) }, 120)
    }

    /** فاصله‌ی لازم تا سرعت تنظیم‌شده (بارکد در دقیقه) رعایت شود. */
    private fun paceDelay(): Long {
        val interval = 60000L / Automation.perMinute.coerceIn(1, 120)
        return maxOf(60L, interval - (SystemClock.uptimeMillis() - cycleStart))
    }

    /** آیا بارکدِ این ثبت، در گره‌ای غیر از فیلد ورودی دیده می‌شود؟ (نشانه‌ی صفحه‌ی نتیجه) */
    private fun resultVisible(root: AccessibilityNodeInfo, sent: String): Boolean {
        val k = key(sent)
        if (k.isEmpty()) return false
        return find(root) {
            it.isVisibleToUser && it.className?.toString()?.contains("EditText") != true &&
                (key(it.text?.toString() ?: "").contains(k) || key(it.contentDescription?.toString() ?: "").contains(k))
        } != null
    }

    /** اثر انگشت ظاهر صفحه؛ تا وقتی عوض می‌شود یعنی هنوز انیمیشن/بارگذاری در جریان است. */
    private fun signature(root: AccessibilityNodeInfo): Int {
        var hash = 17
        val r = Rect()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || !n.isVisibleToUser) return
            hash = 31 * hash + (n.className?.hashCode() ?: 0)
            hash = 31 * hash + (n.text?.toString()?.hashCode() ?: 0)
            hash = 31 * hash + (n.contentDescription?.toString()?.hashCode() ?: 0)
            hash = 31 * hash + (if (n.isEnabled) 1 else 0)
            n.getBoundsInScreen(r)
            hash = 31 * hash + r.hashCode()
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return if (hash == 0) 1 else hash
    }

    /** آیا چرخ/نوار لودینگ روی صفحه هست؟ */
    private fun hasProgress(root: AccessibilityNodeInfo): Boolean = find(root) {
        val c = it.className?.toString() ?: ""
        it.isVisibleToUser && (c.contains("ProgressBar") || c.contains("ProgressIndicator"))
    } != null

    /** بارکدهایی که قبلاً با موفقیت ثبت شده‌اند (حتی در اجرای قبلی) دوباره زده نمی‌شوند. */
    private fun skipSent() {
        var moved = false
        while (Automation.index < Automation.codes.size &&
            Automation.sentList.contains(Automation.codes[Automation.index])) {
            Automation.index++
            moved = true
        }
        if (moved) Automation.save(this)
    }


    // ---------- ثبت دقیق ارور ----------

    private var mapFor: List<String>? = null
    private val codeMap = HashMap<String, String>()

    private fun key(s: String): String =
        s.map { if (it in '۰'..'۹') '0' + (it - '۰') else it }
            .filter { it in 'a'..'z' || it in 'A'..'Z' || it in '0'..'9' }
            .joinToString("").lowercase()

    private fun ensureMap() {
        if (mapFor === Automation.codes) return
        codeMap.clear()
        Automation.codes.forEach { codeMap[key(it)] = it }
        mapFor = Automation.codes
    }

    /** بارکدی که خود صفحه‌ی ارور نشان می‌دهد (اگر در لیست فایل بود همان را برمی‌گرداند). */
    private fun screenCode(root: AccessibilityNodeInfo): String? {
        ensureMap()
        val texts = ArrayList<String>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || !n.isVisibleToUser) return   // زیرمجموعه‌ی نمایان‌نبودن هم نمایان نیست؛ رد می‌شویم
            n.text?.toString()?.let { texts.add(it) }
            n.contentDescription?.toString()?.let { texts.add(it) }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        val token = Regex("[A-Za-z]{2}[0-9۰-۹]{6,}[A-Za-z]{2}")
        var fallback: String? = null
        for (t in texts) {
            codeMap[key(t)]?.let { return it }
            for (m in token.findAll(t)) {
                codeMap[key(m.value)]?.let { return it }
                if (fallback == null) fallback = m.value
            }
        }
        return fallback
    }

    /** بارکد ارور را از روی صفحه (و اگر نشد از آخرین بارکد ثبت‌شده) پیدا و ذخیره می‌کند. */
    private fun recordError(root: AccessibilityNodeInfo, dup: Boolean) {
        val flying = inFlight
        // وقتی بارکدی در حال ثبت است، پیام ارور مال همان است؛ وگرنه از روی صفحه خوانده می‌شود
        val bad = flying ?: screenCode(root)
        if (bad != null) Automation.addFailed(this, bad, dup)
        if (flying != null) advance(flying, false)
    }

    private fun fa(n: Int) = n.toString().map { '۰' + (it - '0') }.joinToString("")

    private fun doneMessage(): String {
        val ok = fa(Automation.okList.items.size)
        val n = Automation.dupList.items.size
        return if (n == 0) "همه بارکدها زده شد؛ $ok بارکد موفق"
        else "همه بارکدها زده شد؛ $ok موفق، ${fa(n)} بارکد قبلا جمع آوری شده بود"
    }

    // ---------- کیبورد ----------

    /** تا وقتی اتومیشن روشنه کیبورد نرم‌افزاری بالا نیاد. */
    private fun hideKeyboard() {
        try {
            val c = softKeyboardController ?: return
            if (c.showMode != AccessibilityService.SHOW_MODE_HIDDEN) {
                c.setShowMode(AccessibilityService.SHOW_MODE_HIDDEN)
            }
        } catch (_: Exception) {}
    }

    /** با توقف/پایان کار، کیبورد به حالت عادی برمی‌گرده. */
    private fun showKeyboard() {
        try {
            softKeyboardController?.setShowMode(AccessibilityService.SHOW_MODE_AUTO)
        } catch (_: Exception) {}
    }

    // ---------- ابزارها ----------

    private fun tap(n: AccessibilityNodeInfo) {
        val r = Rect()
        n.getBoundsInScreen(r)
        if (r.isEmpty) { n.performAction(AccessibilityNodeInfo.ACTION_CLICK); return }
        val path = Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
            .build()
        if (!dispatchGesture(g, null, null)) n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    /** دکمه «باشه» (دقیقاً همین متن). */
    private fun findOk(root: AccessibilityNodeInfo) = find(root) {
        it.isVisibleToUser && norm(it.text) == norm("باشه")
    }

    /** اول کلیک مستقیم روی خود دکمه یا والد قابل‌کلیکش؛ اگر نشد، لمس روی مختصات. */
    private fun clickNode(n: AccessibilityNodeInfo) {
        var cur: AccessibilityNodeInfo? = n
        var depth = 0
        while (cur != null && depth < 5) {
            if (cur.isClickable && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return
            cur = cur.parent
            depth++
        }
        tap(n)
    }

    private fun find(n: AccessibilityNodeInfo?, p: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (n == null) return null
        if (p(n)) return n
        for (i in 0 until n.childCount) {
            val r = find(n.getChild(i), p)
            if (r != null) return r
        }
        return null
    }

    private fun norm(s: CharSequence?): String =
        (s?.toString() ?: "").replace('ك', 'ک').replace('ي', 'ی').replace("\u200c", "")
            .filter { !it.isWhitespace() }

    private fun findEdit(root: AccessibilityNodeInfo) = find(root) {
        it.isVisibleToUser && it.className?.toString()?.contains("EditText") == true
    }

    private fun findText(root: AccessibilityNodeInfo, target: String): AccessibilityNodeInfo? {
        val t = norm(target)
        return find(root) {
            it.isVisibleToUser && (norm(it.text).contains(t) || norm(it.contentDescription).contains(t))
        }
    }

    private fun findSearch(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        fun letters(s: CharSequence?) = (s?.toString() ?: "").uppercase().filter { it in 'A'..'Z' }
        return find(root) {
            it.isVisibleToUser && (letters(it.text).contains("SEARCH") || letters(it.contentDescription).contains("SEARCH"))
        }
    }
}
