package com.tipaxauto

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class TipaxService : AccessibilityService() {

    companion object {
        const val TIPAX = "com.tipax.tipax"
        var instance: TipaxService? = null
    }

    private val h = Handler(Looper.getMainLooper())
    private var toggleTries = 0
    private var lastToggle = 0L
    private var loginTries = 0
    /** آخرین بارکدی که ثبتش زده شده و هنوز نتیجه‌اش (ارور/تکراری) مشخص نیست. */
    private var lastSent: String? = null
    /** چند بار بعد از آخرین بارکد صبر کرده‌ایم تا مطمئن شویم پیام ارور دیر نیامده. */
    private var endChecks = 0
    private var editMissingSince = 0L
    /** هر چند بارکد یک بار صفحه‌ی جمع‌آوری بسته و دوباره باز شود تا لیست اسکن‌شده‌ها بلند نشود و برنامه کند نشود. */
    private val REFRESH_EVERY = 0   // 0 = خاموش (برگشت نمی‌زنیم تا تیپاکس بسته نشود)
    private var lastRefreshAt = -1
    // نگهبان گیر کردن
    /** بارکدی که تایپ شده ولی هنوز SEARCH برایش زده نشده (اگر پیام ارور زودتر بیاید، همین را حساب می‌کنیم). */
    private var pendingCode: String? = null
    private var progressIndex = -1
    private var progressAt = 0L
    private var recoveries = 0
    private var lastLaunch = 0L

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean {
        showKeyboard()
        instance = null
        h.removeCallbacksAndMessages(null)
        Automation.running = false
        return super.onUnbind(intent)
    }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private var lastRemoteCheck = 0L

    fun start() {
        if (RemoteSwitch.isLocked(this)) { stop("برنامه توسط مدیر غیرفعال شده است"); return }
        lastRemoteCheck = System.currentTimeMillis()
        h.removeCallbacksAndMessages(null)
        toggleTries = 0
        lastToggle = 0L
        loginTries = 0
        lastSent = null
        endChecks = 0
        editMissingSince = 0L
        lastRefreshAt = Automation.index
        progressIndex = -1
        recoveries = 0
        pendingCode = null
        Automation.running = true
        hideKeyboard()
        Automation.setStatus("شروع شد...")
        h.postDelayed({ tick() }, 2500)
    }

    fun stop(msg: String) {
        h.removeCallbacksAndMessages(null)
        Automation.running = false
        showKeyboard()
        Automation.setStatus(msg)
    }

    private fun wait(msg: String, ms: Long = 1000) {
        Automation.setStatus(msg)
        h.postDelayed({ tick() }, ms)
    }

    private fun tick() {
        if (!Automation.running) return
        val nowRemote = System.currentTimeMillis()
        if (nowRemote - lastRemoteCheck > RemoteSwitch.CHECK_EVERY_MS) {
            lastRemoteCheck = nowRemote
            RemoteSwitch.refresh(this) { locked -> if (locked) stop("برنامه توسط مدیر غیرفعال شد") }
        }
        if (RemoteSwitch.isLocked(this)) { stop("برنامه توسط مدیر غیرفعال شده است"); return }
        hideKeyboard()
        val finished = Automation.index >= Automation.codes.size

        // نگهبان: اگر روی یک بارکد بیش از ۲۰ ثانیه پیشرفتی نبود، خودش را نجات می‌دهد
        val nowMs = System.currentTimeMillis()
        if (progressIndex != Automation.index) {
            progressIndex = Automation.index; progressAt = nowMs; recoveries = 0
        } else if (!finished && nowMs - progressAt > 20000) {
            recover()
            return
        }

        val root = rootInActiveWindow
        if (root == null || root.packageName?.toString() != TIPAX) {
            if (finished) { stop(doneMessage()); return }
            // اگر «برگشت» تیپاکس را کامل بست، دوباره بازش کن
            launchTipax()
            wait("منتظر باز شدن تیپاکس...")
            return
        }

        // صفحه ورود تیپاکس ← وارد کردن نام کاربری و رمز
        if (!finished && handleLogin(root)) return
        loginTries = 0

        // پیام «این مرسوله قبلا جمع آوری شده است» ← زدن «باشه»
        // هر پیام تمام‌صفحه‌ای که دکمه «باشه» دارد (تکراری، «امکان ثبت ... وجود ندارد» و ...) ← زدن «باشه»
        val ok = findOk(root)
        if (ok != null) {
            val dup = findText(root, "قبلا جمع") != null
            // پیام ارور زودتر از زدن SEARCH آمده؛ یعنی تیپاکس همین بارکد را خودش ثبت کرده ← حسابش کن و برو بعدی
            val pc = pendingCode
            if (pc != null) {
                lastSent = pc
                if (Automation.codes.getOrNull(Automation.index) == pc) {
                    Automation.index++
                    Automation.save(this)
                }
                pendingCode = null
            }
            endChecks = 0
            clickNode(ok)
            Automation.setStatus(if (dup) "مرسوله تکراری بود؛ رد شد" else "امکان ثبت این مرسوله نبود؛ رد شد")
            h.postDelayed({ closeDialog(0) }, 150)
            return
        }

        // همه‌ی بارکدها زده شده؛ کمی صبر می‌کنیم تا ارور آخرین بارکد (اگر دیر آمد) هم دیده شود
        if (finished) {
            if (endChecks < 4) {
                endChecks++
                wait("بررسی آخرین بارکد...", 700)
            } else {
                stop(doneMessage())
            }
            return
        }

        val edit = findEdit(root)
        if (edit == null) {
            val now = System.currentTimeMillis()
            // فیلد ممکن است فقط لحظه‌ای (وسط انیمیشن/بارگذاری) نمایان نباشد؛ تا ۳ ثانیه فقط صبر می‌کنیم
            if (editMissingSince == 0L) editMissingSince = now
            if (now - editMissingSince < 3000) {
                wait("منتظر نمایش فیلد بارکد...", 300)
                return
            }
            val toggle = findText(root, "تعویض حالت")
            val menu = findText(root, "جمع آوری مرسوله")
            if (toggle != null) {
                if (toggleTries < 3 && now - lastToggle > 6000) {
                    toggleTries++
                    lastToggle = now
                    tap(toggle)
                    wait("در حال تعویض حالت...", 1800)
                } else if (toggleTries >= 3 && now - lastToggle > 6000) {
                    stop("فیلد بارکد پیدا نشد. دستی «تعویض حالت» را بزن و دوباره شروع کن.")
                } else {
                    wait("منتظر باز شدن فیلد بارکد...", 800)
                }
            } else if (menu != null) {
                tap(menu)
                wait("رفتن به «جمع آوری مرسوله»...", 2000)
            } else {
                wait("در حال باز کردن «جمع آوری مرسوله»...", 1500)
            }
            return
        }

        toggleTries = 0
        editMissingSince = 0L

        // هر REFRESH_EVERY بارکد: یک قدم «برگشت»؛ بقیه‌اش (رفتن به جمع‌آوری و تعویض حالت) را منطق پایین خودش انجام می‌دهد
        if (REFRESH_EVERY > 0 && Automation.index > 0 && Automation.index % REFRESH_EVERY == 0 && lastRefreshAt != Automation.index) {
            lastRefreshAt = Automation.index
            performGlobalAction(GLOBAL_ACTION_BACK)
            lastToggle = 0L
            editMissingSince = System.currentTimeMillis()
            wait("تازه‌سازی صفحه برای سرعت بیشتر...", 1500)
            return
        }

        val code = Automation.codes[Automation.index]
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, code)
        fixTries = 0
        pendingCode = code
        edit.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        Automation.setStatus("در حال ثبت: $code")
        h.postDelayed({ submit() }, 400)
    }


    private fun launchTipax() {
        val now = SystemClock.uptimeMillis()
        if (now - lastLaunch < 8000) return
        lastLaunch = now
        try {
            packageManager.getLaunchIntentForPackage(TIPAX)?.let {
                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(it)
            }
        } catch (_: Exception) {}
    }

    /** دو بار با «برگشت» و ورود دوباره امتحان می‌کند؛ اگر باز هم نشد، بارکد گیرکرده را در لیست خطاها می‌گذارد و رد می‌شود. */
    private fun recover() {
        progressAt = System.currentTimeMillis()
        recoveries++
        editMissingSince = 0L
        lastToggle = 0L
        toggleTries = 0
        if (recoveries <= 2) {
            // بدون «برگشت»: فقط «تعویض حالت» را می‌زنیم تا فیلد بارکد دوباره بیاید
            rootInActiveWindow?.let { r -> findText(r, "تعویض حالت")?.let { tap(it) } }
            wait("گیر کرده بود؛ تلاش دوباره (${recoveries})...", 1800)
            return
        }
        val code = Automation.codes.getOrNull(Automation.index)
        if (code != null) {
            Automation.index++
            Automation.save(this)
        }
        recoveries = 0
        wait("روی یک بارکد گیر کرد؛ رد شد", 1500)
    }

    /**
     * تا وقتی پیام ارور بسته نشده منتظر می‌ماند (و اگر کلیک اثر نکرد دوباره می‌زند)؛
     * بعد از بسته شدن هم صبر می‌کند تا فیلد بارکد دوباره نمایان شود، و فقط آن‌وقت ادامه می‌دهد
     * (وگرنه ممکن بود وسط انیمیشن، «تعویض حالت» اشتباهی زده شود و برنامه روی یک بارکد گیر کند).
     */
    private fun closeDialog(tries: Int) {
        if (!Automation.running) return
        val root = rootInActiveWindow
        val ok = root?.let { findOk(it) }
        if (ok != null) {
            if (tries < 10) {
                if (tries % 3 == 2) clickNode(ok)
                h.postDelayed({ closeDialog(tries + 1) }, 150)
            } else {
                h.postDelayed({ tick() }, 100)
            }
            return
        }
        val finished = Automation.index >= Automation.codes.size
        val fieldBack = root != null && root.packageName?.toString() == TIPAX && findEdit(root) != null
        if (finished || fieldBack || tries >= 40) {
            h.postDelayed({ tick() }, 60)
        } else {
            h.postDelayed({ closeDialog(tries + 1) }, 100)
        }
    }

    private var fixTries = 0

    /** اگر صفحه ورود باز بود، کارهای لازم را انجام می‌دهد و true برمی‌گرداند. */
    private fun handleLogin(root: AccessibilityNodeInfo): Boolean {
        val edits = ArrayList<AccessibilityNodeInfo>()
        var seen = 0
        fun collect(n: AccessibilityNodeInfo?) {
            if (n == null || seen++ > NODE_BUDGET) return
            if (n.isVisibleToUser && n.className?.toString()?.contains("EditText") == true) edits.add(n)
            for (i in 0 until n.childCount) collect(n.getChild(i))
        }
        collect(root)
        val pwd = edits.firstOrNull { it.isPassword }
        val prompt = findText(root, "نام کاربری و رمز عبور")
        if (edits.size < 2 || (pwd == null && prompt == null)) return false

        val passField = pwd ?: edits[1]
        val userField = edits.first { it != passField }

        if (Automation.username.isEmpty() || Automation.password.isEmpty()) {
            stop("صفحه ورود تیپاکس باز شد. نام کاربری و رمز را در برنامه وارد کن و دوباره شروع کن.")
            return true
        }
        if (loginTries >= 3) {
            stop("ورود ناموفق بود. نام کاربری و رمز را بررسی کن و دوباره شروع کن.")
            return true
        }
        loginTries++
        Automation.setStatus("در حال ورود به تیپاکس...")

        userField.refresh()
        if ((userField.text?.toString() ?: "") != Automation.username) setCode(userField, Automation.username)
        setCode(passField, Automation.password)

        h.postDelayed({
            if (!Automation.running) return@postDelayed
            val r = rootInActiveWindow ?: return@postDelayed
            val btn = find(r) { it.isVisibleToUser && norm(it.text) == norm("ورود") }
            if (btn != null) tap(btn)
        }, 700)
        h.postDelayed({ tick() }, 4000)
        return true
    }

    private fun setCode(edit: AccessibilityNodeInfo, code: String) {
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, code)
        edit.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun submit() {
        if (!Automation.running) return
        val root = rootInActiveWindow
        var done = false

        // اگر هنوز پیام ارور (مربوط به بارکد قبلی) روی صفحه است، این بارکد را نزن؛
        // tick اول پیام را ثبت و می‌بندد و بعد همین بارکد دوباره وارد می‌شود (هیچ بارکدی گم نمی‌شود)
        if (root != null && root.packageName?.toString() == TIPAX && findOk(root) != null) {
            h.postDelayed({ tick() }, 100)
            return
        }

        // اگر کیبورد حرف اضافه (مثل y) اول بارکد گذاشت، متن را پاک و دوباره درست وارد کن
        val code = Automation.codes.getOrNull(Automation.index)
        val field = root?.let { findEdit(it) }
        if (code != null && field != null) {
            field.refresh()
            val cur = field.text?.toString() ?: ""
            if (cur != code && fixTries < 4) {
                fixTries++
                setCode(field, "")
                h.postDelayed({
                    if (Automation.running) {
                        rootInActiveWindow?.let { r -> findEdit(r)?.let { setCode(it, code) } }
                        h.postDelayed({ submit() }, 350)
                    }
                }, 250)
                return
            }
        }
        fixTries = 0
        if (root != null) {
            val mode = Automation.submitMode
            if (mode != 2) {
                val s = findSearch(root)
                if (s != null) { tap(s); done = true }
            }
            if (!done && mode != 1 && Build.VERSION.SDK_INT >= 30) {
                val edit = findEdit(root)
                if (edit != null) {
                    done = edit.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
                }
            }
        }
        if (!done) {
            stop("ثبت انجام نشد. «روش ثبت» را در برنامه عوض کن و دوباره شروع کن.")
            return
        }
        lastSent = code
        pendingCode = null
        Automation.index++
        Automation.save(this)
        Automation.setStatus("ثبت شد")
        // به‌محض تایید (خالی شدن فیلد یا پیام تکراری) بارکد بعدی؛ وگرنه حداکثر تا «تأخیر» صبر کن
        val sent = code
        val deadline = SystemClock.uptimeMillis() + Automation.delayMs
        h.postDelayed({ waitConfirm(sent, deadline) }, 250)
    }

    private fun waitConfirm(sent: String?, deadline: Long) {
        if (!Automation.running) return
        var confirmed = false
        val root = rootInActiveWindow
        if (root != null && root.packageName?.toString() == TIPAX) {
            if (findOk(root) != null) {
                confirmed = true
            } else {
                val f = findEdit(root)
                if (f == null) {
                    confirmed = true   // صفحه عوض شده (تایید سبز)؛ لازم نیست کل تأخیر را صبر کنیم
                } else if (sent != null) {
                    f.refresh()
                    if ((f.text?.toString() ?: "") != sent) confirmed = true
                }
            }
        }
        if (confirmed || SystemClock.uptimeMillis() >= deadline) {
            h.postDelayed({ tick() }, 100)
        } else {
            h.postDelayed({ waitConfirm(sent, deadline) }, 120)
        }
    }


    // ---------- ثبت دقیق ارور ----------

    private var mapFor: List<String>? = null
    private val codeMap = HashMap<String, String>()

    private fun key(s: String): String =
        s.map { if (it in '۰'..'۹') '0' + (it - '۰') else it }
            .filter { it in 'a'..'z' || it in 'A'..'Z' || it in '0'..'9' }
            .joinToString("").lowercase()

    private fun ensureMap() {
        if (mapFor === Automation.codes) return
        codeMap.clear()
        Automation.codes.forEach { codeMap[key(it)] = it }
        mapFor = Automation.codes
    }

    /** بارکدی که خود صفحه‌ی ارور نشان می‌دهد (اگر در لیست فایل بود همان را برمی‌گرداند). */
    private fun screenCode(root: AccessibilityNodeInfo): String? {
        ensureMap()
        val texts = ArrayList<String>()
        var seen = 0
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || !n.isVisibleToUser || seen++ > 300) return   // زیرمجموعه‌ی نمایان‌نبودن هم نمایان نیست؛ رد می‌شویم
            n.text?.toString()?.let { texts.add(it) }
            n.contentDescription?.toString()?.let { texts.add(it) }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        val token = Regex("[A-Za-z]{2}[0-9۰-۹]{6,}[A-Za-z]{2}")
        var fallback: String? = null
        for (t in texts) {
            codeMap[key(t)]?.let { return it }
            for (m in token.findAll(t)) {
                codeMap[key(m.value)]?.let { return it }
                if (fallback == null) fallback = m.value
            }
        }
        return fallback
    }

    private fun doneMessage() = "همه بارکدها زده شد"

    // ---------- کیبورد ----------

    /** تا وقتی اتومیشن روشنه کیبورد نرم‌افزاری بالا نیاد. */
    private fun hideKeyboard() {
        try {
            val c = softKeyboardController ?: return
            if (c.showMode != AccessibilityService.SHOW_MODE_HIDDEN) {
                c.setShowMode(AccessibilityService.SHOW_MODE_HIDDEN)
            }
        } catch (_: Exception) {}
    }

    /** با توقف/پایان کار، کیبورد به حالت عادی برمی‌گرده. */
    private fun showKeyboard() {
        try {
            softKeyboardController?.setShowMode(AccessibilityService.SHOW_MODE_AUTO)
        } catch (_: Exception) {}
    }

    // ---------- ابزارها ----------

    private fun tap(n: AccessibilityNodeInfo) {
        val r = Rect()
        n.getBoundsInScreen(r)
        if (r.isEmpty) { n.performAction(AccessibilityNodeInfo.ACTION_CLICK); return }
        val path = Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
            .build()
        if (!dispatchGesture(g, null, null)) n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    /** دکمه «باشه» (دقیقاً همین متن). */
    private fun findOk(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        try {
            root.findAccessibilityNodeInfosByText("باشه")
                ?.firstOrNull { it.isVisibleToUser && norm(it.text) == norm("باشه") }
                ?.let { return it }
        } catch (_: Exception) {}
        return find(root) { it.isVisibleToUser && norm(it.text) == norm("باشه") }
    }

    /** اول کلیک مستقیم روی خود دکمه یا والد قابل‌کلیکش؛ اگر نشد، لمس روی مختصات. */
    private fun clickNode(n: AccessibilityNodeInfo) {
        var cur: AccessibilityNodeInfo? = n
        var depth = 0
        while (cur != null && depth < 5) {
            if (cur.isClickable && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return
            cur = cur.parent
            depth++
        }
        tap(n)
    }

    /** سقف تعداد نودهای بررسی‌شده در هر جست‌وجو؛ با بلند شدن لیست اسکن‌شده‌ها کند نشود. */
    private val NODE_BUDGET = 250

    private fun isListContainer(n: AccessibilityNodeInfo): Boolean {
        val c = n.className?.toString() ?: return false
        return c.contains("RecyclerView") || c.contains("ListView") || c.contains("ScrollView") ||
            c.contains("AbsListView") || c.contains("GridView")
    }

    private fun find(n: AccessibilityNodeInfo?, p: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (n == null) return null
        val budget = intArrayOf(NODE_BUDGET)
        fun go(x: AccessibilityNodeInfo): AccessibilityNodeInfo? {
            if (budget[0]-- <= 0) return null
            if (p(x)) return x
            for (i in 0 until x.childCount) {
                if (budget[0] <= 0) return null
                val ch = x.getChild(i) ?: continue
                val r = go(ch)
                if (r != null) return r
            }
            return null
        }
        return go(n)
    }

    private fun norm(s: CharSequence?): String =
        (s?.toString() ?: "").replace('ك', 'ک').replace('ي', 'ی').replace("\u200c", "")
            .filter { !it.isWhitespace() }

    private fun findEdit(root: AccessibilityNodeInfo) = find(root) {
        it.isVisibleToUser && it.className?.toString()?.contains("EditText") == true
    }

    private fun findText(root: AccessibilityNodeInfo, target: String): AccessibilityNodeInfo? {
        val t = norm(target)
        try {
            root.findAccessibilityNodeInfosByText(target)?.firstOrNull { it.isVisibleToUser }?.let { return it }
        } catch (_: Exception) {}
        return find(root) {
            it.isVisibleToUser && (norm(it.text).contains(t) || norm(it.contentDescription).contains(t))
        }
    }

    private fun findSearch(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        fun letters(s: CharSequence?) = (s?.toString() ?: "").uppercase().filter { it in 'A'..'Z' }
        return find(root) {
            it.isVisibleToUser && (letters(it.text).contains("SEARCH") || letters(it.contentDescription).contains("SEARCH"))
        }
    }
}
