package com.tipaxauto

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.*

class MainActivity : Activity() {

    private lateinit var fileInfo: TextView
    private lateinit var statusTv: TextView
    private lateinit var progress: ProgressBar
    private lateinit var delayEt: EditText
    private lateinit var startEt: EditText
    private lateinit var modeGroup: RadioGroup
    private val REQ = 11

    private fun num(s: String): Double? =
        s.map { if (it in '۰'..'۹') '0' + (it - '۰') else it }.joinToString("").trim().toDoubleOrNull()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        fun dp(x: Int) = (x * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(16))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        fun add(v: View) {
            root.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        }

        add(TextView(this).apply { text = "ورود خودکار بارکد در تیپاکس"; textSize = 20f })

        add(Button(this).apply {
            text = "۱) فعال‌سازی دسترسی (Accessibility)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        add(Button(this).apply {
            text = "۲) انتخاب فایل اکسل"
            setOnClickListener {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                startActivityForResult(i, REQ)
            }
        })
        fileInfo = TextView(this).apply { text = "فایلی انتخاب نشده" }
        add(fileInfo)

        delayEt = EditText(this).apply {
            hint = "تأخیر بین بارکدها (ثانیه)"
            setText("2")
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        add(delayEt)
        startEt = EditText(this).apply {
            hint = "شروع از بارکد شماره"
            setText("1")
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        add(startEt)

        modeGroup = RadioGroup(this).apply {
            orientation = RadioGroup.VERTICAL
            listOf(
                "روش ثبت: خودکار (دکمه SEARCH یا Enter)",
                "فقط دکمه SEARCH",
                "فقط Enter کیبورد (اندروید ۱۱ به بالا)"
            ).forEachIndexed { i, t ->
                addView(RadioButton(context).apply { id = 100 + i; text = t; isChecked = i == 0 })
            }
        }
        add(modeGroup)

        add(Button(this).apply {
            text = "۳) شروع"
            setOnClickListener { start() }
        })
        add(Button(this).apply {
            text = "توقف"
            setOnClickListener { TipaxService.instance?.stop("متوقف شد") ?: toast("سرویس فعال نیست") }
        })

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        add(progress)
        statusTv = TextView(this).apply { text = Automation.statusText; textSize = 16f }
        add(statusTv)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        Automation.listener = { refresh() }
        refresh()
    }

    override fun onPause() {
        super.onPause()
        Automation.listener = null
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun refresh() {
        val n = Automation.codes.size
        statusTv.text = "${Automation.statusText}\n${Automation.index} از $n"
        progress.max = maxOf(n, 1)
        progress.progress = Automation.index
        if (!Automation.running && n > 0) {
            startEt.setText((Automation.index + 1).coerceAtMost(n).toString())
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ && resultCode == RESULT_OK) data?.data?.let { load(it) }
    }

    private fun load(uri: Uri) {
        fileInfo.text = "در حال خواندن فایل..."
        Thread {
            try {
                val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                val list = if (bytes.size > 1 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte()) {
                    XlsxReader.parse(bytes)
                } else {
                    String(bytes, Charsets.UTF_8).split(Regex("[\\s,;\"]+"))
                        .map { it.trim() }.filter { XlsxReader.CODE.matches(it) }
                }
                runOnUiThread { onLoaded(list) }
            } catch (e: Exception) {
                runOnUiThread { fileInfo.text = "خطا در خواندن فایل: ${e.message}\n(فایل باید xlsx یا csv باشد، نه xls قدیمی)" }
            }
        }.start()
    }

    private fun onLoaded(list: List<String>) {
        if (list.isEmpty()) { fileInfo.text = "هیچ بارکدی پیدا نشد"; return }
        Automation.codes = list
        Automation.fileKey = "${list.size}_${list.first()}_${list.last()}"
        val saved = getSharedPreferences("tipax", MODE_PRIVATE).getInt("pos_${Automation.fileKey}", 0)
        Automation.index = saved.coerceIn(0, list.size - 1)
        fileInfo.text = "${list.size} بارکد خوانده شد. اولین: ${list.first()}" +
            if (saved > 0) "\nادامه از شماره ${saved + 1} (آخرین موقعیت ذخیره‌شده)" else ""
        Automation.setStatus("آماده")
    }

    private fun start() {
        if (Automation.codes.isEmpty()) { toast("اول فایل اکسل را انتخاب کن"); return }
        val svc = TipaxService.instance
        if (svc == null) {
            toast("دسترسی Accessibility برای «بارکد تیپاکس» را روشن کن")
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        val launch = packageManager.getLaunchIntentForPackage(TipaxService.TIPAX)
        if (launch == null) { toast("برنامه تیپاکس نصب نیست"); return }
        val n = Automation.codes.size
        Automation.index = ((num(startEt.text.toString())?.toInt() ?: 1) - 1).coerceIn(0, n - 1)
        Automation.delayMs = (((num(delayEt.text.toString()) ?: 2.0).coerceAtLeast(0.5)) * 1000).toLong()
        Automation.submitMode = modeGroup.checkedRadioButtonId - 100
        startActivity(launch)
        svc.start()
    }
}
