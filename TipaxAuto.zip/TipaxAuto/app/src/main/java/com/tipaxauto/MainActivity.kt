package com.tipaxauto

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {

    private lateinit var accTv: TextView
    private lateinit var fileInfo: TextView
    private lateinit var fileIcon: ImageView
    private lateinit var clearBtn: ImageView
    private lateinit var statusTv: TextView
    private lateinit var countTv: TextView
    private lateinit var percentTv: TextView
    private lateinit var progress: ProgressBar
    private lateinit var errBox: LinearLayout
    private lateinit var errCountTv: TextView
    private lateinit var errList: ListView
    private lateinit var errAdapter: ArrayAdapter<String>
    private lateinit var errOtherTv: TextView
    private lateinit var errEmptyTv: TextView
    private var shownErrVersion = -1
    private var shownOkVersion = -1
    private lateinit var okCountTv: TextView
    private lateinit var okEmptyTv: TextView
    private lateinit var okList: ListView
    private lateinit var okAdapter: android.widget.BaseAdapter
    private lateinit var okCopyBtn: Button
    private var refreshPending = false
    private val ui = android.os.Handler(android.os.Looper.getMainLooper())
    private lateinit var errCopyBtn: Button
    private lateinit var delayEt: EditText
    private lateinit var startEt: EditText
    private lateinit var rateEt: EditText
    private lateinit var userEt: EditText
    private lateinit var passEt: EditText
    private lateinit var modeGroup: RadioGroup
    private val REQ = 11

    // فونت بی‌تیتر: فایل را با نام btitr.ttf در res/font/ بگذار. اگر نبود، vazirmatn و بعد فونت سیستم
    private val customFont: Typeface? by lazy {
        if (Build.VERSION.SDK_INT < 26) return@lazy null
        listOf("btitr", "vazirmatn").firstNotNullOfOrNull { n ->
            val id = resources.getIdentifier(n, "font", packageName)
            if (id != 0) resources.getFont(id) else null
        }
    }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun c(id: Int) = resources.getColor(id, theme)

    private fun num(s: String): Double? =
        s.map { if (it in '۰'..'۹') '0' + (it - '۰') else it }.joinToString("").trim().toDoubleOrNull()

    private fun fa(s: String) = s.map { if (it in '0'..'9') '۰' + (it - '0') else it }.joinToString("")

    // همه‌ی متن‌ها همیشه بولد هستند
    private fun face(): Typeface =
        customFont
            ?: Typeface.create("sans-serif-medium", Typeface.BOLD)

    private fun TextView.style(size: Float, color: Int, bold: Boolean = false): TextView {
        textSize = size
        setTextColor(color)
        typeface = face()
        setLineSpacing(0f, 1.15f)
        return this
    }

    private fun label(text: String, size: Float = 14f, color: Int = c(R.color.text_main), bold: Boolean = false) =
        TextView(this).apply { this.text = text }.style(size, color, bold)

    private fun icon(res: Int, color: Int, size: Int = 22): Drawable =
        resources.getDrawable(res, theme).mutate().apply {
            setTint(color)
            setBounds(0, 0, dp(size), dp(size))
        }

    private fun button(text: String, bg: Int, color: Int, iconRes: Int? = null): Button = Button(this).apply {
        this.text = text
        setBackgroundResource(bg)
        stateListAnimator = null
        isAllCaps = false
        minHeight = dp(52)
        minimumHeight = dp(52)
        textSize = 16f
        setTextColor(color)
        typeface = face()
        if (iconRes != null) {
            setCompoundDrawablesRelative(icon(iconRes, color), null, null, null)
            compoundDrawablePadding = dp(8)
        }
    }

    private fun card(step: String?, title: String, iconRes: Int, tile: Int): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_card)
            setPadding(dp(16), dp(16), dp(16), dp(16))
            elevation = dp(2).toFloat()
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val tileView = ImageView(this).apply {
            setImageResource(iconRes)
            setColorFilter(Color.WHITE)
            setBackgroundResource(tile)
            val pd = dp(8) // همه‌ی آیکون‌ها هم‌اندازه
            setPadding(pd, pd, pd, pd)
        }
        row.addView(tileView, LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginEnd = dp(12) })
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (step != null) col.addView(label(step, 11f, c(R.color.text_muted)))
        col.addView(label(title, 16f, c(R.color.text_main), true))
        row.addView(col)
        box.addView(row)
        return box
    }

    private fun LinearLayout.addGap(v: View, top: Int = 12, h: Int = -2) =
        addView(v, LinearLayout.LayoutParams(-1, h).apply { topMargin = dp(top) })

    private var built = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (isUnlocked()) buildMain() else showGate()
    }

    /** کلید ورود به زمان نصب گره خورده؛ هر نصب تازه (حتی روی همین گوشی) دوباره رمز می‌خواهد. */
    private fun gateKey(): String = try {
        "ok_" + packageManager.getPackageInfo(packageName, 0).firstInstallTime
    } catch (e: Exception) { "ok_x" }

    private fun isUnlocked() = getSharedPreferences("gate", MODE_PRIVATE).getBoolean(gateKey(), false)

    /** صفحهٔ رمز: فقط بار اول بعد از نصب؛ بعد از رمز درست دیگر پرسیده نمی‌شود. */
    private fun showGate() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        // ---------- بالای صفحه: لوگو + کارتون شناور ----------
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundResource(R.drawable.bg_header)
            setPadding(dp(24), dp(40), dp(24), dp(56))
        }
        top.addView(ImageView(this).apply {
            setImageResource(R.drawable.tipax_logo)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
        }, LinearLayout.LayoutParams(dp(160), -2))
        val fantasy = FrameLayout(this)
        fantasy.addView(ImageView(this).apply { setBackgroundResource(R.drawable.bg_glow) },
            FrameLayout.LayoutParams(dp(150), dp(150), Gravity.CENTER))
        val boxImg = ImageView(this).apply {
            setImageResource(R.drawable.ecobox)
            scaleType = ImageView.ScaleType.FIT_CENTER
            rotation = -6f
        }
        fantasy.addView(boxImg, FrameLayout.LayoutParams(dp(128), dp(114), Gravity.CENTER))
        android.animation.ObjectAnimator.ofFloat(fantasy, "translationY", dp(-4).toFloat(), dp(6).toFloat()).apply {
            duration = 1700
            repeatCount = android.animation.ValueAnimator.INFINITE
            repeatMode = android.animation.ValueAnimator.REVERSE
            interpolator = android.view.animation.AccelerateDecelerateInterpolator()
            start()
        }
        top.addView(fantasy, LinearLayout.LayoutParams(dp(150), dp(150)).apply { topMargin = dp(8) })
        root.addView(top, LinearLayout.LayoutParams(-1, -2))

        // ---------- کارت رمز (کمی روی هدر می‌افتد) ----------
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundResource(R.drawable.bg_card)
            setPadding(dp(22), dp(26), dp(22), dp(22))
            elevation = dp(6).toFloat()
        }
        card.addView(label("به سامانه هوشمند ثبت مرسوله خوش آمدید", 18f, c(R.color.green_dark), true).apply {
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2))
        card.addView(label("سرعت، دقت و اطمینان در جمع‌آوری مرسوله‌ها؛\nهمراه همیشگی کوریر حرفه‌ای.", 13f, c(R.color.text_muted), true).apply {
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        val et = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            gravity = Gravity.CENTER
            hint = "رمز ورود"
            textSize = 22f
            typeface = face()
            letterSpacing = 0.3f
            textDirection = View.TEXT_DIRECTION_LTR
            setTextColor(c(R.color.text_main))
            setHintTextColor(c(R.color.text_muted))
            setBackgroundResource(R.drawable.bg_input)
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        card.addView(et, LinearLayout.LayoutParams(-1, dp(58)).apply { topMargin = dp(20) })

        val err = label("", 13f, c(R.color.error_red), true).apply { gravity = Gravity.CENTER }
        card.addView(err, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        val enter = button("ورود به سامانه", R.drawable.btn_primary, Color.WHITE).apply {
            setOnClickListener {
                if (et.text.toString().trim() == "0217") {
                    getSharedPreferences("gate", MODE_PRIVATE).edit().putBoolean(gateKey(), true).apply()
                    buildMain()
                    onResume()
                } else {
                    err.text = "رمز اشتباه است؛ دوباره تلاش کنید"
                    et.setText("")
                }
            }
        }
        card.addView(enter, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(10) })

        card.addView(label("این مرحله فقط یک‌بار، بعد از نصب برنامه انجام می‌شود.", 12f, c(R.color.text_muted), true).apply {
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

        root.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
            marginStart = dp(20); marginEnd = dp(20); topMargin = dp(-36)
        })

        root.addView(label("نسخه اختصاصی سازمانی  •  Sobhan Sedighi  •  v2", 11f, c(R.color.text_muted), true).apply {
            gravity = Gravity.CENTER
            textDirection = View.TEXT_DIRECTION_LTR
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(22); bottomMargin = dp(20) })

        setContentView(ScrollView(this).apply {
            setBackgroundResource(R.drawable.bg_screen)
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(root)
        })
    }

    private fun buildMain() {
        built = true

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        // ---------- هدر ----------
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundResource(R.drawable.bg_header)
            setPadding(dp(18), dp(16), dp(18), dp(22))
        }
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        titles.addView(ImageView(this).apply {
            setImageResource(R.drawable.tipax_logo)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "Tipax Courier Service"
        }, LinearLayout.LayoutParams(dp(148), -2))
        titles.addView(label("Sobhan Sedighi", 12f, Color.WHITE, true).apply {
            textDirection = View.TEXT_DIRECTION_LTR
            gravity = Gravity.CENTER
            setBackgroundResource(R.drawable.bg_pill)
            setPadding(dp(12), dp(3), dp(12), dp(3))
        }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(8) })
        header.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        // کارتون تیپاکس (حالت فانتزی): شناور و با هاله‌ی نور
        val fantasy = FrameLayout(this)
        fantasy.addView(ImageView(this).apply { setBackgroundResource(R.drawable.bg_glow) },
            FrameLayout.LayoutParams(dp(136), dp(136), Gravity.CENTER))
        val box = ImageView(this).apply {
            setImageResource(R.drawable.ecobox)
            scaleType = ImageView.ScaleType.FIT_CENTER
            rotation = -6f
        }
        fantasy.addView(box, FrameLayout.LayoutParams(dp(118), dp(106), Gravity.CENTER))
        // شناور بودن بالا و پایین
        android.animation.ObjectAnimator.ofFloat(fantasy, "translationY", dp(-4).toFloat(), dp(5).toFloat()).apply {
            duration = 1700
            repeatCount = android.animation.ValueAnimator.INFINITE
            repeatMode = android.animation.ValueAnimator.REVERSE
            interpolator = android.view.animation.AccelerateDecelerateInterpolator()
            start()
        }
        android.animation.ObjectAnimator.ofFloat(box, "rotation", -9f, -3f).apply {
            duration = 2300
            repeatCount = android.animation.ValueAnimator.INFINITE
            repeatMode = android.animation.ValueAnimator.REVERSE
            start()
        }
        header.addView(fantasy, LinearLayout.LayoutParams(dp(136), dp(136)).apply {
            gravity = Gravity.CENTER_VERTICAL
            marginStart = dp(-8)
            marginEnd = dp(-8)
            topMargin = dp(-6)
            bottomMargin = dp(-10)
        })
        content.addView(header, LinearLayout.LayoutParams(-1, -2))

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(4), dp(16), dp(24))
        }
        content.addView(body, LinearLayout.LayoutParams(-1, -2))

        // ---------- ۱) دسترسی ----------
        val c1 = card("مرحله ۱", getString(R.string.step1_title), R.drawable.ic_accessibility, R.drawable.tile_green)
        c1.addGap(button(getString(R.string.step1_btn), R.drawable.btn_tonal, c(R.color.green_dark), R.drawable.ic_accessibility).apply {
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        accTv = label("", 13f)
        c1.addGap(accTv, 10)
        body.addGap(c1, 14)

        // ---------- ۲) فایل ----------
        val c2 = card("مرحله ۲", getString(R.string.step2_title), R.drawable.ic_file, R.drawable.tile_blue)
        c2.addGap(button(getString(R.string.step2_btn), R.drawable.btn_tonal, c(R.color.green_dark), R.drawable.ic_folder).apply {
            setOnClickListener {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                startActivityForResult(i, REQ)
            }
        })
        fileIcon = ImageView(this).apply {
            setImageResource(R.drawable.ic_file)
            setColorFilter(c(R.color.text_muted))
        }
        fileInfo = label(getString(R.string.no_file), 13f, c(R.color.text_muted))
        clearBtn = ImageView(this).apply {
            setImageResource(R.drawable.ic_close)
            setColorFilter(c(R.color.danger))
            setBackgroundResource(R.drawable.bg_circle_danger)
            setPadding(dp(7), dp(7), dp(7), dp(7))
            visibility = View.GONE
            contentDescription = "حذف فایل"
            setOnClickListener { clearFile() }
        }
        val fileRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundResource(R.drawable.bg_fileinfo)
            setPadding(dp(12), dp(10), dp(10), dp(10))
        }
        fileRow.addView(fileIcon, LinearLayout.LayoutParams(dp(24), dp(24)).apply { marginEnd = dp(10) })
        fileRow.addView(fileInfo, LinearLayout.LayoutParams(0, -2, 1f))
        fileRow.addView(clearBtn, LinearLayout.LayoutParams(dp(32), dp(32)).apply { marginStart = dp(8) })
        c2.addGap(fileRow, 10)
        body.addGap(c2, 14)

        // ---------- ۳) تنظیمات ----------
        val c3 = card("مرحله ۳", getString(R.string.step3_title), R.drawable.ic_tune, R.drawable.tile_amber)
        delayEt = EditText(this).apply {
            setText("2")
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        startEt = EditText(this).apply {
            setText("1")
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        rateEt = EditText(this).apply {
            setText(getSharedPreferences("tipax", MODE_PRIVATE).getInt("rate", 35).toString())
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        fun field(title: String, et: EditText): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(label(title, 12f, c(R.color.text_muted)).apply {
                setSingleLine(true)
                ellipsize = android.text.TextUtils.TruncateAt.END
            })
            et.apply {
                gravity = Gravity.CENTER
                setBackgroundResource(R.drawable.bg_input)
                setPadding(dp(8), dp(10), dp(8), dp(10))
            }.style(18f, c(R.color.text_main), true)
            addView(et, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(6) })
        }
        val fields = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fields.addView(field(getString(R.string.start_label), startEt),
            LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) })
        fields.addView(field(getString(R.string.delay_label), delayEt),
            LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(6) })
        c3.addGap(fields, 14)
        val fields2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fields2.addView(field(getString(R.string.rate_label), rateEt),
            LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) })
        fields2.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f).apply { marginStart = dp(6) })
        c3.addGap(fields2, 12)

        // نام کاربری و رمز تیپاکس (فقط وقتی صفحه ورود نشان داده شود استفاده می‌شود)
        val sp = getSharedPreferences("tipax", MODE_PRIVATE)
        userEt = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            textDirection = View.TEXT_DIRECTION_LTR
            setText(sp.getString("user", ""))
        }
        passEt = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            textDirection = View.TEXT_DIRECTION_LTR
            setText(sp.getString("pass", ""))
        }
        // نام کاربری و رمز عبور در یک خط؛ روی رمز یک چشم برای نمایش/مخفی کردن
        passEt.transformationMethod = android.text.method.PasswordTransformationMethod.getInstance()
        val passBox = FrameLayout(this)
        passBox.addView(field(getString(R.string.pass_label), passEt),
            FrameLayout.LayoutParams(-1, -2))
        passEt.setPaddingRelative(dp(8), dp(10), dp(40), dp(10))
        val eye = ImageView(this).apply {
            setImageResource(R.drawable.ic_eye_off)
            setColorFilter(c(R.color.green_mid))
            setPadding(dp(11), dp(11), dp(11), dp(11))
            contentDescription = "نمایش رمز"
            setOnClickListener {
                val hidden = passEt.transformationMethod is android.text.method.PasswordTransformationMethod
                passEt.transformationMethod =
                    if (hidden) android.text.method.HideReturnsTransformationMethod.getInstance()
                    else android.text.method.PasswordTransformationMethod.getInstance()
                setImageResource(if (hidden) R.drawable.ic_eye else R.drawable.ic_eye_off)
                setColorFilter(c(R.color.green_mid))
                passEt.setSelection(passEt.text.length)
            }
        }
        passBox.addView(eye, FrameLayout.LayoutParams(dp(44), dp(52), Gravity.BOTTOM or Gravity.LEFT))
        val loginRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        loginRow.addView(field(getString(R.string.user_label), userEt),
            LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) })
        loginRow.addView(passBox, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(6) })
        c3.addGap(loginRow, 14)
        c3.addGap(label(getString(R.string.login_hint), 11f, c(R.color.text_muted)), 8)
        body.addGap(c3, 14)

        // ---------- ۴) روش ثبت ----------
        val c4 = card("مرحله ۴", getString(R.string.step4_title), R.drawable.ic_scan_enter, R.drawable.tile_purple)
        val tint = ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(c(R.color.green_mid), Color.parseColor("#9DB0A2"))
        )
        modeGroup = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        listOf(
            R.string.mode0 to R.string.mode0_desc,
            R.string.mode1 to R.string.mode1_desc,
            R.string.mode2 to R.string.mode2_desc
        ).forEachIndexed { i, (t, d) ->
            val title = getString(t)
            val sb = SpannableStringBuilder(title + "\n" + getString(d))
            sb.setSpan(RelativeSizeSpan(0.82f), title.length + 1, sb.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.setSpan(ForegroundColorSpan(c(R.color.text_muted)), title.length + 1, sb.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            val rb = RadioButton(this).apply {
                id = 100 + i
                text = sb
                isChecked = i == 0
                buttonTintList = tint
                setBackgroundResource(R.drawable.option_bg)
                setPadding(dp(10), dp(12), dp(10), dp(12))
            }.also { it.style(15f, c(R.color.text_main), true) }
            modeGroup.addView(rb, RadioGroup.LayoutParams(-1, -2).apply { topMargin = dp(if (i == 0) 0 else 8) })
        }
        c4.addGap(modeGroup, 12)
        body.addGap(c4, 14)

        // ---------- وضعیت ----------
        val c5 = card(null, getString(R.string.progress_title), R.drawable.ic_chart, R.drawable.tile_teal)
        statusTv = label(Automation.statusText, 13f, c(R.color.green_dark), true).apply {
            setBackgroundResource(R.drawable.bg_chip)
            setPadding(dp(14), dp(8), dp(14), dp(8))
        }
        c5.addGap(statusTv, 12, -2)
        val countRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        countTv = label("", 22f, c(R.color.text_main), true)
        percentTv = label("", 15f, c(R.color.green_mid), true)
        countRow.addView(countTv, LinearLayout.LayoutParams(0, -2, 1f))
        countRow.addView(percentTv)
        c5.addGap(countRow, 14)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            progressDrawable = resources.getDrawable(R.drawable.progress_bar, theme)
        }
        c5.addGap(progress, 10, dp(10))

        // بارکدهایی که با موفقیت ثبت شدند (سبز شد): تعداد + لیست بارکدها (آخرین‌ها بالا)
        val okBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_ok_box)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        val okHead = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        okHead.addView(label(getString(R.string.ok_title), 15f, c(R.color.green), true),
            LinearLayout.LayoutParams(0, -2, 1f))
        okCountTv = label("", 22f, c(R.color.green), true)
        okHead.addView(okCountTv)
        okBox.addView(okHead)
        okEmptyTv = label(getString(R.string.ok_empty), 14f, c(R.color.text_muted)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
        }
        okBox.addGap(okEmptyTv, 10)
        okAdapter = object : android.widget.BaseAdapter() {
            override fun getCount() = Automation.okList.items.size
            override fun getItem(position: Int): Any =
                Automation.okList.items[Automation.okList.items.size - 1 - position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                val tv = (convertView as? TextView) ?: TextView(this@MainActivity).apply {
                    textDirection = View.TEXT_DIRECTION_LTR
                    gravity = Gravity.CENTER
                    layoutParams = AbsListView.LayoutParams(-1, dp(30))
                }.style(15f, c(R.color.text_main), true) as TextView
                tv.text = getItem(position).toString()
                return tv
            }
        }
        okList = ListView(this).apply {
            adapter = okAdapter
            divider = null
            isVerticalScrollBarEnabled = true
            overScrollMode = View.OVER_SCROLL_NEVER
            setOnTouchListener { v, _ -> v.parent.requestDisallowInterceptTouchEvent(true); false }
            visibility = View.GONE
        }
        okBox.addGap(okList, 10, dp(30))
        okCopyBtn = button(getString(R.string.ok_copy), R.drawable.btn_ok_tonal, c(R.color.green)).apply {
            minHeight = dp(44)
            minimumHeight = dp(44)
            textSize = 14f
            setOnClickListener {
                val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("ok", Automation.okList.items.joinToString("\n")))
                toast(getString(R.string.ok_copied))
            }
        }
        okBox.addGap(okCopyBtn, 10, dp(44))
        c5.addGap(okBox, 16)

        // بارکدهایی که تیپاکس ارور قرمز داد: تعداد + لیست بارکدها زیرش
        errBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_error_box)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        val errHead = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        errHead.addView(label(getString(R.string.errors_title), 15f, c(R.color.error_red), true),
            LinearLayout.LayoutParams(0, -2, 1f))
        errCountTv = label("", 22f, c(R.color.error_red), true)
        errHead.addView(errCountTv)
        errBox.addView(errHead)
        errEmptyTv = label(getString(R.string.errors_empty), 14f, c(R.color.text_muted)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
        }
        errBox.addGap(errEmptyTv, 10)
        // لیست مجازی‌شده (ListView): فقط ردیف‌های دیده‌شده ساخته می‌شود، پس با ۱۰۰۰ بارکد هم سبک است
        errAdapter = object : ArrayAdapter<String>(this, 0, ArrayList<String>()) {
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                val tv = (convertView as? TextView) ?: TextView(context).apply {
                    textDirection = View.TEXT_DIRECTION_LTR
                    gravity = Gravity.CENTER
                    layoutParams = AbsListView.LayoutParams(-1, dp(30))
                }.style(15f, c(R.color.text_main), true) as TextView
                tv.text = getItem(position)
                return tv
            }
        }
        errList = ListView(this).apply {
            adapter = errAdapter
            divider = null
            isVerticalScrollBarEnabled = true
            overScrollMode = View.OVER_SCROLL_NEVER
            setOnTouchListener { v, _ -> v.parent.requestDisallowInterceptTouchEvent(true); false }
            visibility = View.GONE
        }
        errBox.addGap(errList, 10, dp(30))
        errOtherTv = label("", 13f, c(R.color.error_red)).apply {
            textDirection = View.TEXT_DIRECTION_LTR
            visibility = View.GONE
        }
        errBox.addGap(errOtherTv, 8)
        errCopyBtn = button(getString(R.string.errors_copy), R.drawable.btn_error_tonal, c(R.color.error_red)).apply {
            minHeight = dp(44)
            minimumHeight = dp(44)
            textSize = 14f
            setOnClickListener {
                val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("failed", Automation.dupList.items.joinToString("\n")))
                toast(getString(R.string.errors_copied))
            }
        }
        errBox.addGap(errCopyBtn, 10, dp(44))
        c5.addGap(errBox, 16)
        body.addGap(c5, 14)

        // ---------- نوار پایین: شروع / توقف ----------
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(Color.WHITE)
            setPadding(dp(16), dp(10), dp(16), dp(12))
            elevation = dp(10).toFloat()
        }
        bar.addView(button(getString(R.string.btn_start), R.drawable.btn_primary, Color.WHITE, R.drawable.ic_play).apply {
            setOnClickListener { start() }
        }, LinearLayout.LayoutParams(0, dp(54), 2f).apply { marginEnd = dp(8) })
        bar.addView(button(getString(R.string.btn_stop), R.drawable.btn_danger, c(R.color.danger), R.drawable.ic_stop).apply {
            setOnClickListener {
                TipaxService.instance?.stop(getString(R.string.stopped)) ?: toast(getString(R.string.toast_no_service))
            }
        }, LinearLayout.LayoutParams(0, dp(54), 1f))

        val screen = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        screen.addView(ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(content)
        }, LinearLayout.LayoutParams(-1, 0, 1f))
        screen.addView(bar, LinearLayout.LayoutParams(-1, -2))
        setContentView(screen)
    }

    override fun onResume() {
        super.onResume()
        if (!built) return
        Automation.listener = { scheduleRefresh() }
        refresh()
    }

    /** به‌روزرسانی صفحه حداکثر هر ۲۵۰ میلی‌ثانیه یک بار؛ تا کار اصلی (سرویس) روی همین ترد کند نشود. */
    private fun scheduleRefresh() {
        if (refreshPending) return
        refreshPending = true
        ui.postDelayed({ refreshPending = false; refresh() }, 250)
    }

    override fun onPause() {
        super.onPause()
        if (!built) return
        Automation.listener = null
        saveLogin()
    }

    /** نام کاربری/رمز فقط روی همین گوشی (حافظه خصوصی برنامه) ذخیره می‌شود. */
    private fun saveLogin() {
        Automation.username = userEt.text.toString().trim()
        Automation.password = passEt.text.toString()
        getSharedPreferences("tipax", MODE_PRIVATE).edit()
            .putString("user", Automation.username)
            .putString("pass", Automation.password)
            .apply()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun refresh() {
        val on = TipaxService.instance != null
        val accColor = c(if (on) R.color.green else R.color.warn)
        accTv.text = getString(if (on) R.string.acc_on else R.string.acc_off)
        accTv.setTextColor(accColor)
        accTv.setCompoundDrawablesRelative(
            icon(if (on) R.drawable.ic_check_circle else R.drawable.ic_warning, accColor, 20), null, null, null)
        accTv.compoundDrawablePadding = dp(8)

        val n = Automation.codes.size
        statusTv.text = Automation.statusText + Automation.rateSuffix()
        statusTv.setCompoundDrawablesRelative(GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(c(if (Automation.running) R.color.green_mid else R.color.text_muted))
            setSize(dp(10), dp(10)); setBounds(0, 0, dp(10), dp(10))
        }, null, null, null)
        statusTv.compoundDrawablePadding = dp(8)
        countTv.text = getString(R.string.count_fmt, fa(Automation.index.toString()), fa(n.toString()))
        percentTv.text = fa((if (n > 0) Automation.index * 100 / n else 0).toString()) + "٪"
        progress.max = maxOf(n, 1)
        progress.progress = Automation.index
        // لیست ارورها فقط وقتی واقعاً عوض شده دوباره ساخته می‌شود (نه با هر به‌روزرسانی وضعیت)
        val ver = Automation.failedVersion()
        if (ver != shownErrVersion) {
            shownErrVersion = ver
            val f = Automation.dupList.items
            errCountTv.text = fa(f.size.toString())
            errAdapter.setNotifyOnChange(false)
            errAdapter.clear()
            errAdapter.addAll(f)
            errAdapter.notifyDataSetChanged()
            val empty = f.isEmpty()
            errEmptyTv.visibility = if (empty) View.VISIBLE else View.GONE
            errList.visibility = if (empty) View.GONE else View.VISIBLE
            errList.layoutParams = errList.layoutParams.apply { height = minOf(f.size, 8) * dp(30) }
            errCopyBtn.visibility = if (empty) View.GONE else View.VISIBLE
            val o = Automation.otherList.items
            errOtherTv.visibility = if (o.isEmpty()) View.GONE else View.VISIBLE
            errOtherTv.text = getString(R.string.errors_other) + "\n" + o.joinToString("  ")
        }
        val okVer = Automation.okList.version
        if (okVer != shownOkVersion) {
            shownOkVersion = okVer
            val sz = Automation.okList.items.size
            okCountTv.text = fa(sz.toString())
            okAdapter.notifyDataSetChanged()
            val empty = sz == 0
            okEmptyTv.visibility = if (empty) View.VISIBLE else View.GONE
            okList.visibility = if (empty) View.GONE else View.VISIBLE
            val h = minOf(sz, 8) * dp(30)
            if (okList.layoutParams.height != h) okList.layoutParams = okList.layoutParams.apply { height = h }
            okCopyBtn.visibility = if (empty) View.GONE else View.VISIBLE
        }
        if (!Automation.running && n > 0) {
            startEt.setText((Automation.index + 1).coerceAtMost(n).toString())
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ && resultCode == RESULT_OK) data?.data?.let { load(it) }
    }

    private fun load(uri: Uri) {
        fileInfo.text = getString(R.string.reading_file)
        fileInfo.setTextColor(c(R.color.text_muted))
        Thread {
            try {
                val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                val list = if (bytes.size > 1 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte()) {
                    XlsxReader.parse(bytes)
                } else {
                    String(bytes, Charsets.UTF_8).split(Regex("[\\s,;\"]+"))
                        .map { it.trim() }.filter { XlsxReader.CODE.matches(it) }
                }
                runOnUiThread { onLoaded(list) }
            } catch (e: Exception) {
                runOnUiThread {
                    fileInfo.text = getString(R.string.read_error, e.message ?: "")
                    fileInfo.setTextColor(c(R.color.danger))
                    fileIcon.setImageResource(R.drawable.ic_warning)
                    fileIcon.setColorFilter(c(R.color.danger))
                }
            }
        }.start()
    }

    private fun onLoaded(raw: List<String>) {
        val list = XlsxReader.dedupe(raw)
        val dups = raw.size - list.size
        if (list.isEmpty()) {
            fileInfo.text = getString(R.string.no_codes)
            fileInfo.setTextColor(c(R.color.warn))
            fileIcon.setImageResource(R.drawable.ic_warning)
            fileIcon.setColorFilter(c(R.color.warn))
            return
        }
        Automation.codes = list
        Automation.fileKey = "${list.size}_${list.first()}_${list.last()}"
        val saved = getSharedPreferences("tipax", MODE_PRIVATE).getInt("pos_${Automation.fileKey}", 0)
        Automation.index = saved.coerceIn(0, list.size - 1)
        Automation.loadFailed(this)
        fileInfo.text = getString(R.string.file_ok, fa(list.size.toString()), list.first()) +
            (if (dups > 0) getString(R.string.file_dups, fa(dups.toString())) else "") +
            if (saved > 0) getString(R.string.file_resume, fa((saved + 1).toString())) else ""
        fileInfo.setTextColor(c(R.color.text_main))
        fileIcon.setImageResource(R.drawable.ic_check_circle)
        fileIcon.setColorFilter(c(R.color.green_mid))
        clearBtn.visibility = View.VISIBLE
        Automation.setStatus(getString(R.string.ready))
    }

    private fun clearFile() {
        if (Automation.running) TipaxService.instance?.stop(getString(R.string.stopped))
        Automation.codes = emptyList()
        Automation.fileKey = ""
        Automation.index = 0
        Automation.dupList.clearMemory()
        Automation.otherList.clearMemory()
        Automation.sentList.clearMemory()
        Automation.okList.clearMemory()
        fileInfo.text = getString(R.string.no_file)
        fileInfo.setTextColor(c(R.color.text_muted))
        fileIcon.setImageResource(R.drawable.ic_file)
        fileIcon.setColorFilter(c(R.color.text_muted))
        clearBtn.visibility = View.GONE
        startEt.setText("1")
        Automation.setStatus(getString(R.string.ready))
    }

    private fun start() {
        if (Automation.codes.isEmpty()) { toast(getString(R.string.toast_pick_file)); return }
        val svc = TipaxService.instance
        if (svc == null) {
            toast(getString(R.string.toast_enable_acc))
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        val launch = packageManager.getLaunchIntentForPackage(TipaxService.TIPAX)
        if (launch == null) { toast(getString(R.string.toast_no_tipax)); return }
        val n = Automation.codes.size
        Automation.index = ((num(startEt.text.toString())?.toInt() ?: 1) - 1).coerceIn(0, n - 1)
        Automation.delayMs = (((num(delayEt.text.toString()) ?: 2.0).coerceAtLeast(0.5)) * 1000).toLong()
        Automation.submitMode = modeGroup.checkedRadioButtonId - 100
        Automation.perMinute = (num(rateEt.text.toString())?.toInt() ?: 35).coerceIn(5, 120)
        getSharedPreferences("tipax", MODE_PRIVATE).edit().putInt("rate", Automation.perMinute).apply()
        if (Automation.index == 0) Automation.clearFailed(this) // شروع تازه ← لیست ارورها از صفر
        saveLogin()
        startActivity(launch)
        svc.start()
    }
}
