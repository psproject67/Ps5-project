package com.tipaxauto

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

private val INK = Color.parseColor("#10212B")
private val BG = Color.parseColor("#F1F4F3")
private val CARD = Color.WHITE
private val LINE = Color.parseColor("#DCE4E1")
private val MUTED = Color.parseColor("#5D6E78")
private val SOFT = Color.parseColor("#A9BBC4")
private val TEAL = Color.parseColor("#0F766E")
private val TEAL_SOFT = Color.parseColor("#D8EFEA")
private val ORANGE = Color.parseColor("#FF8A1F")
private val RED = Color.parseColor("#B42318")
private val RED_SOFT = Color.parseColor("#FDE8E6")
private val RED_LINE = Color.parseColor("#F1B9B3")
private val OFFWHITE = Color.parseColor("#F4F7F5")
private val TRACK = Color.parseColor("#2B3F4B")

class MainActivity : Activity() {

    private lateinit var fileInfo: TextView
    private lateinit var statusTv: TextView
    private lateinit var countTv: TextView
    private lateinit var bar: ThinBar
    private lateinit var dot: View
    private lateinit var delayEt: EditText
    private lateinit var startEt: EditText
    private lateinit var accChip: TextView
    private val modeTabs = mutableListOf<TextView>()
    private var mode = 0
    private val REQ = 11

    // ---------- کمکی‌ها ----------

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun dpf(x: Int) = x * resources.displayMetrics.density

    private fun num(s: String): Double? =
        s.map { if (it in '۰'..'۹') '0' + (it - '۰') else it }.joinToString("").trim().toDoubleOrNull()

    private fun fa(n: Int): String =
        n.toString().map { if (it in '0'..'9') '۰' + (it - '0') else it }.joinToString("")

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun shape(fill: Int, r: Float, stroke: Int = 0, sw: Int = 0) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = r
        if (stroke != 0) setStroke(sw, stroke)
    }

    private fun lp(w: Int, h: Int, top: Int = 0) =
        LinearLayout.LayoutParams(w, h).apply { topMargin = dp(top) }

    private fun tv(s: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = sp
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun caption(s: String) = tv(s, 13f, MUTED).apply { setLineSpacing(0f, 1.3f) }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = shape(CARD, dpf(16), LINE, dp(1))
        setPadding(dp(16), dp(14), dp(16), dp(16))
    }

    private fun btn(label: String, fill: Int, textColor: Int, stroke: Int = 0, onClick: () -> Unit) =
        TextView(this).apply {
            text = label
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(textColor)
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = RippleDrawable(
                ColorStateList.valueOf(0x22000000),
                shape(fill, dpf(12), stroke, dp(1)),
                shape(Color.BLACK, dpf(12))
            )
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
        }

    private fun stepRow(n: String, title: String, trailing: View?): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(
                tv(n, 13f, TEAL, true).apply {
                    gravity = Gravity.CENTER
                    background = shape(TEAL_SOFT, dpf(13))
                },
                LinearLayout.LayoutParams(dp(26), dp(26))
            )
            addView(
                tv(title, 16f, INK, true),
                LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(10) }
            )
            if (trailing != null) addView(trailing)
        }

    private fun field(e: EditText): EditText = e.apply {
        background = shape(BG, dpf(10), LINE, dp(1))
        setPadding(dp(12), dp(10), dp(12), dp(10))
        textSize = 17f
        setTextColor(INK)
        gravity = Gravity.CENTER
        setSingleLine()
    }

    private fun labeled(label: String, v: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(tv(label, 13f, MUTED))
        addView(v, lp(-1, -2, 6))
    }

    private fun chip(on: Boolean) {
        accChip.text = if (on) "فعال" else "غیرفعال"
        accChip.setTextColor(if (on) TEAL else RED)
        accChip.background = shape(if (on) TEAL_SOFT else RED_SOFT, dpf(10))
    }

    private fun setFile(s: String, color: Int) {
        fileInfo.text = s
        fileInfo.setTextColor(color)
    }

    // ---------- ساخت صفحه ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = INK
        window.navigationBarColor = CARD

        accChip = tv("", 12f, TEAL, true).apply { setPadding(dp(10), dp(4), dp(10), dp(4)) }
        chip(false)

        fileInfo = tv("فایلی انتخاب نشده", 14f, MUTED).apply {
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = shape(BG, dpf(10))
            setLineSpacing(0f, 1.25f)
        }

        delayEt = field(EditText(this).apply {
            setText("2")
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        })
        startEt = field(EditText(this).apply {
            setText("1")
            inputType = InputType.TYPE_CLASS_NUMBER
        })

        val c1 = card().apply {
            addView(stepRow("۱", "دسترسی Accessibility", accChip))
            addView(
                caption("برنامه برای کنترل تیپاکس به این دسترسی نیاز دارد. بعد از نصب هر نسخه‌ی جدید باید دوباره روشنش کنی."),
                lp(-1, -2, 10)
            )
            addView(
                btn("باز کردن تنظیمات", TEAL_SOFT, TEAL) {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                },
                lp(-1, -2, 12)
            )
        }

        val c2 = card().apply {
            addView(stepRow("۲", "فایل بارکدها", null))
            addView(caption("فایل xlsx یا csv که ستونی با هدر «شماره بارکد» داشته باشد."), lp(-1, -2, 10))
            addView(fileInfo, lp(-1, -2, 10))
            addView(
                btn("انتخاب فایل اکسل", TEAL_SOFT, TEAL) {
                    val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                    }
                    startActivityForResult(i, REQ)
                },
                lp(-1, -2, 12)
            )
        }

        val fields = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(labeled("تأخیر بین بارکدها (ثانیه)", delayEt), LinearLayout.LayoutParams(0, -2, 1f))
            addView(
                labeled("شروع از بارکد شماره", startEt),
                LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12) }
            )
        }

        val c3 = card().apply {
            addView(stepRow("۳", "تنظیمات اجرا", null))
            addView(fields, lp(-1, -2, 14))
            addView(labeled("روش ثبت بارکد", segmented()), lp(-1, -2, 14))
            addView(caption("اگر بعد از شروع پیام «ثبت انجام نشد» دیدی، روش دیگری را امتحان کن."), lp(-1, -2, 10))
        }

        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            addView(c1)
            addView(c2, lp(-1, -2, 12))
            addView(c3, lp(-1, -2, 12))
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            addView(buildHeader())
            addView(ScrollView(this@MainActivity).apply { addView(list) }, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(buildBottomBar())
        }
        setContentView(root)
    }

    private fun buildHeader(): View {
        val h = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val r = dpf(28)
            background = GradientDrawable().apply {
                setColor(INK)
                cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
            }
            setPadding(dp(20), dp(8), dp(20), dp(22))
        }

        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(tv("بارکد تیپاکس", 20f, Color.WHITE, true))
            addView(tv("ورود خودکار بارکد از فایل اکسل", 13f, SOFT))
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(MarkView(this@MainActivity), LinearLayout.LayoutParams(dp(44), dp(44)))
            addView(titles, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12) })
        }
        h.addView(top)

        h.addView(tv("ثبت‌شده", 13f, SOFT), lp(-1, -2, 22))
        countTv = tv("—", 34f, Color.WHITE, true)
        h.addView(countTv, lp(-1, -2, 2))

        bar = ThinBar(this)
        h.addView(bar, lp(-1, dp(6), 10))

        dot = View(this).apply { background = shape(SOFT, dpf(4)) }
        statusTv = tv(Automation.statusText, 14f, SOFT).apply { setLineSpacing(0f, 1.2f) }
        val st = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(dot, LinearLayout.LayoutParams(dp(8), dp(8)))
            addView(statusTv, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
        }
        h.addView(st, lp(-1, -2, 12))
        return h
    }

    private fun buildBottomBar(): View {
        val divider = View(this).apply { setBackgroundColor(LINE) }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            addView(btn("شروع", TEAL, Color.WHITE) { start() }, LinearLayout.LayoutParams(0, -2, 2f))
            addView(
                btn("توقف", CARD, RED, RED_LINE) {
                    TipaxService.instance?.stop("متوقف شد") ?: toast("سرویس فعال نیست")
                },
                LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(10) }
            )
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(CARD)
            addView(divider, LinearLayout.LayoutParams(-1, dp(1)))
            addView(row)
        }
    }

    private fun segmented(): LinearLayout {
        val seg = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = shape(BG, dpf(12), LINE, dp(1))
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }
        listOf("خودکار", "فقط SEARCH", "فقط Enter").forEachIndexed { i, t ->
            val tab = tv(t, 13f, MUTED).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(10), 0, dp(10))
                setOnClickListener { selectMode(i) }
            }
            modeTabs.add(tab)
            seg.addView(tab, LinearLayout.LayoutParams(0, -2, 1f))
        }
        selectMode(0)
        return seg
    }

    private fun selectMode(i: Int) {
        mode = i
        modeTabs.forEachIndexed { j, t ->
            val on = j == i
            t.background = if (on) shape(INK, dpf(9)) else null
            t.setTextColor(if (on) Color.WHITE else MUTED)
            t.typeface = if (on) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
    }

    // ---------- چرخه‌ی زندگی ----------

    override fun onResume() {
        super.onResume()
        Automation.listener = { refresh() }
        refresh()
    }

    override fun onPause() {
        super.onPause()
        Automation.listener = null
    }

    private fun refresh() {
        val n = Automation.codes.size
        val done = Automation.index
        if (n == 0) {
            countTv.text = "—"
        } else {
            val head = fa(done)
            val sb = SpannableStringBuilder(head).append(" از ${fa(n)}")
            sb.setSpan(RelativeSizeSpan(0.42f), head.length, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.setSpan(ForegroundColorSpan(SOFT), head.length, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            countTv.text = sb
        }
        bar.fraction = if (n == 0) 0f else done.toFloat() / n
        statusTv.text = Automation.statusText
        (dot.background as GradientDrawable).setColor(if (Automation.running) ORANGE else SOFT)
        chip(TipaxService.instance != null)
        if (!Automation.running && n > 0) {
            startEt.setText((done + 1).coerceAtMost(n).toString())
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ && resultCode == RESULT_OK) data?.data?.let { load(it) }
    }

    private fun load(uri: Uri) {
        setFile("در حال خواندن فایل...", MUTED)
        Thread {
            try {
                val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                val list = if (bytes.size > 1 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte()) {
                    XlsxReader.parse(bytes)
                } else {
                    String(bytes, Charsets.UTF_8).split(Regex("[\\s,;\"]+"))
                        .map { it.trim() }.filter { XlsxReader.CODE.matches(it) }
                }
                runOnUiThread { onLoaded(list) }
            } catch (e: Exception) {
                runOnUiThread {
                    setFile("خطا در خواندن فایل: ${e.message}\n(فایل باید xlsx یا csv باشد، نه xls قدیمی)", RED)
                }
            }
        }.start()
    }

    private fun onLoaded(list: List<String>) {
        if (list.isEmpty()) { setFile("هیچ بارکدی پیدا نشد", RED); return }
        Automation.codes = list
        Automation.fileKey = "${list.size}_${list.first()}_${list.last()}"
        val saved = getSharedPreferences("tipax", MODE_PRIVATE).getInt("pos_${Automation.fileKey}", 0)
        Automation.index = saved.coerceIn(0, list.size - 1)
        setFile(
            "${fa(list.size)} بارکد خوانده شد. اولین: ${list.first()}" +
                if (saved > 0) "\nادامه از شماره ${fa(saved + 1)} (آخرین موقعیت ذخیره‌شده)" else "",
            TEAL
        )
        Automation.setStatus("آماده")
    }

    private fun start() {
        if (Automation.codes.isEmpty()) { toast("اول فایل اکسل را انتخاب کن"); return }
        val svc = TipaxService.instance
        if (svc == null) {
            toast("دسترسی Accessibility برای «بارکد تیپاکس» را روشن کن")
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        val launch = packageManager.getLaunchIntentForPackage(TipaxService.TIPAX)
        if (launch == null) { toast("برنامه تیپاکس نصب نیست"); return }
        val n = Automation.codes.size
        Automation.index = ((num(startEt.text.toString())?.toInt() ?: 1) - 1).coerceIn(0, n - 1)
        Automation.delayMs = (((num(delayEt.text.toString()) ?: 2.0).coerceAtLeast(0.5)) * 1000).toLong()
        Automation.submitMode = mode
        startActivity(launch)
        svc.start()
    }
}

/** نوار پیشرفت باریک؛ در حالت راست‌به‌چپ از راست پر می‌شود. */
class ThinBar(ctx: Context) : View(ctx) {
    var fraction = 0f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = TRACK }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = ORANGE }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h / 2
        c.drawRoundRect(0f, 0f, w, h, r, r, track)
        if (fraction > 0f) {
            val fw = maxOf(w * fraction, h)
            if (layoutDirection == LAYOUT_DIRECTION_RTL) {
                c.drawRoundRect(w - fw, 0f, w, h, r, r, fill)
            } else {
                c.drawRoundRect(0f, 0f, fw, h, r, r, fill)
            }
        }
    }
}

/** همان نشانه‌ی آیکون برنامه (قاب اسکنر + بارکد + خط نارنجی). */
class MarkView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        c.save()
        c.scale(width / 60f, width / 60f)
        c.translate(-24f, -24f)

        p.style = Paint.Style.STROKE
        p.strokeWidth = 3f
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.color = OFFWHITE
        val b = Path()
        b.moveTo(30f, 42f); b.lineTo(30f, 33f); b.lineTo(39f, 33f)
        b.moveTo(69f, 33f); b.lineTo(78f, 33f); b.lineTo(78f, 42f)
        b.moveTo(30f, 66f); b.lineTo(30f, 75f); b.lineTo(39f, 75f)
        b.moveTo(69f, 75f); b.lineTo(78f, 75f); b.lineTo(78f, 66f)
        c.drawPath(b, p)

        p.style = Paint.Style.FILL
        val bars = floatArrayOf(37.5f, 2.5f, 42f, 4f, 48f, 2f, 52f, 3.5f, 57.5f, 2f, 61.5f, 4f, 67.5f, 2.5f)
        var i = 0
        while (i < bars.size) {
            c.drawRect(bars[i], 40f, bars[i] + bars[i + 1], 68f, p)
            i += 2
        }

        p.style = Paint.Style.STROKE
        p.color = ORANGE
        c.drawLine(27.5f, 54f, 80.5f, 54f, p)
        c.restore()
    }
}
