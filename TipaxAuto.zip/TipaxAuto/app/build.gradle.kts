plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.tipaxauto"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.tipaxauto"
        minSdk = 24
        targetSdk = 34
        versionCode = 9
        versionName = "1.8"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
