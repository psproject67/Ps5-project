-- ============================================================
--  راه‌اندازی کلید روشن/خاموش (Supabase → SQL Editor → Run)
--  ۱) رمز مدیر: sobhancodm1 (برای عوض کردنش، همین عبارت را در خط insert عوض کن).
--  ۲) یک‌بار اجرا کن. دوباره اجرا کردنش بی‌خطر است.
-- ============================================================

-- جدول وضعیت (id=1: فعال یا غیرفعال)
create table if not exists public.tipax_app_status (
  id int primary key,
  active boolean not null default true,
  updated_at timestamptz not null default now()
);
insert into public.tipax_app_status (id, active) values (1, true)
  on conflict (id) do nothing;

alter table public.tipax_app_status enable row level security;
drop policy if exists "read status" on public.tipax_app_status;
create policy "read status" on public.tipax_app_status
  for select to anon, authenticated using (true);      -- همه فقط می‌توانند «بخوانند»

-- رمز مدیر (فقط هش ذخیره می‌شود؛ جدول هیچ policy ندارد پس از بیرون قابل خواندن نیست)
create table if not exists public.tipax_admin (
  id int primary key default 1,
  pw_hash text not null
);
alter table public.tipax_admin enable row level security;
insert into public.tipax_admin (id, pw_hash)
  values (1, encode(sha256(convert_to('sobhancodm1', 'UTF8')), 'hex'))
  on conflict (id) do update set pw_hash = excluded.pw_hash;

-- تابع تغییر وضعیت: فقط با رمز درست
create or replace function public.set_tipax_status(pw text, val boolean)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not exists (
    select 1 from public.tipax_admin
    where id = 1
      and pw_hash = encode(sha256(convert_to(coalesce(pw, ''), 'UTF8')), 'hex')
  ) then
    raise exception 'wrong password';
  end if;
  update public.tipax_app_status set active = val, updated_at = now() where id = 1;
end;
$$;

revoke all on function public.set_tipax_status(text, boolean) from public;
grant execute on function public.set_tipax_status(text, boolean) to anon, authenticated;
