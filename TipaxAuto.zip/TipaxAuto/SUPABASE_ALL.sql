-- ===== ۱) کلید روشن/خاموش تیپاکس (رمز مدیر: sobhancodm1) =====
-- ============================================================
--  راه‌اندازی کلید روشن/خاموش (Supabase → SQL Editor → Run)
--  ۱) رمز مدیر: sobhancodm1 (برای عوض کردنش، همین عبارت را در خط insert عوض کن).
--  ۲) یک‌بار اجرا کن. دوباره اجرا کردنش بی‌خطر است.
-- ============================================================

-- جدول وضعیت (id=1: فعال یا غیرفعال)
create table if not exists public.tipax_app_status (
  id int primary key,
  active boolean not null default true,
  updated_at timestamptz not null default now()
);
insert into public.tipax_app_status (id, active) values (1, true)
  on conflict (id) do nothing;

alter table public.tipax_app_status enable row level security;
drop policy if exists "read status" on public.tipax_app_status;
create policy "read status" on public.tipax_app_status
  for select to anon, authenticated using (true);      -- همه فقط می‌توانند «بخوانند»

-- رمز مدیر (فقط هش ذخیره می‌شود؛ جدول هیچ policy ندارد پس از بیرون قابل خواندن نیست)
create table if not exists public.tipax_admin (
  id int primary key default 1,
  pw_hash text not null
);
alter table public.tipax_admin enable row level security;
insert into public.tipax_admin (id, pw_hash)
  values (1, encode(sha256(convert_to('sobhancodm1', 'UTF8')), 'hex'))
  on conflict (id) do update set pw_hash = excluded.pw_hash;

-- تابع تغییر وضعیت: فقط با رمز درست
create or replace function public.set_tipax_status(pw text, val boolean)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not exists (
    select 1 from public.tipax_admin
    where id = 1
      and pw_hash = encode(sha256(convert_to(coalesce(pw, ''), 'UTF8')), 'hex')
  ) then
    raise exception 'wrong password';
  end if;
  update public.tipax_app_status set active = val, updated_at = now() where id = 1;
end;
$$;

revoke all on function public.set_tipax_status(text, boolean) from public;
grant execute on function public.set_tipax_status(text, boolean) to anon, authenticated;

-- ===== ۲) برنامه‌ی PS5 =====
-- ===== جدول‌ها =====
create table if not exists public.shop_prices (shop text not null, game text not null, price bigint not null check (price > 0 and price <= 1000000000), primary key (shop, game));
create table if not exists public.shop_info (shop text primary key, info jsonb not null default '{}'::jsonb);

alter table public.shop_prices enable row level security;
alter table public.shop_info enable row level security;
revoke all on public.shop_prices from anon, authenticated;
revoke all on public.shop_info from anon, authenticated;

-- ===== قیمت‌ها =====
create or replace function public.shop_list() returns jsonb language sql security definer set search_path = public as $$
  select coalesce(jsonb_agg(distinct shop), '[]'::jsonb) from public.shop_prices;
$$;

create or replace function public.shop_prices_get(p_shop text) returns jsonb language sql security definer set search_path = public as $$
  select coalesce(jsonb_object_agg(game, price), '{}'::jsonb) from public.shop_prices
  where lower(regexp_replace(shop, '\s', '', 'g')) = lower(regexp_replace(coalesce(p_shop, ''), '\s', '', 'g'));
$$;

create or replace function public.shop_prices_set(p_code text, p_shop text, p_prices jsonb) returns void language plpgsql security definer set search_path = public as $$
begin
  perform public.admin_list(p_code);
  if coalesce(trim(p_shop), '') = '' then raise exception 'shop required'; end if;
  delete from public.shop_prices where lower(regexp_replace(shop, '\s', '', 'g')) = lower(regexp_replace(p_shop, '\s', '', 'g'));
  insert into public.shop_prices (shop, game, price)
  select p_shop, key, value::bigint from jsonb_each_text(coalesce(p_prices, '{}'::jsonb))
  where value ~ '^\d+$' and value::numeric > 0 and value::numeric <= 1000000000;
end;
$$;

-- ===== اطلاعات و آدرس شاپ =====
create or replace function public.shop_info_all() returns jsonb language sql security definer set search_path = public as $$
  select coalesce(jsonb_object_agg(shop, info), '{}'::jsonb) from public.shop_info;
$$;

create or replace function public.shop_info_set(p_code text, p_shop text, p_info jsonb) returns void language plpgsql security definer set search_path = public as $$
begin
  perform public.admin_list(p_code);
  if coalesce(trim(p_shop), '') = '' then raise exception 'shop required'; end if;
  delete from public.shop_info where lower(regexp_replace(shop, '\s', '', 'g')) = lower(regexp_replace(p_shop, '\s', '', 'g'));
  insert into public.shop_info (shop, info) values (p_shop, jsonb_build_object(
    'addr',  left(coalesce(p_info->>'addr',  ''), 300),
    'tel',   left(coalesce(p_info->>'tel',   ''), 40),
    'hours', left(coalesce(p_info->>'hours', ''), 60),
    'note',  left(coalesce(p_info->>'note',  ''), 200)));
end;
$$;

-- ===== دسترسی‌ها =====
grant execute on function public.shop_list() to anon, authenticated;
grant execute on function public.shop_prices_get(text) to anon, authenticated;
grant execute on function public.shop_prices_set(text, text, jsonb) to anon, authenticated;
grant execute on function public.shop_info_all() to anon, authenticated;
grant execute on function public.shop_info_set(text, text, jsonb) to anon, authenticated;

-- ===== بازی‌های اختصاصی هر شاپ (افزودن بازی + غیرفعال کردن بازی) =====
create table if not exists public.shop_games (shop text primary key, cfg jsonb not null default '{}'::jsonb);
alter table public.shop_games enable row level security;
revoke all on public.shop_games from anon, authenticated;

create or replace function public.shop_games_all() returns jsonb language sql security definer set search_path = public as $$
  select coalesce(jsonb_object_agg(shop, cfg), '{}'::jsonb) from public.shop_games;
$$;

create or replace function public.shop_games_set(p_code text, p_shop text, p_cfg jsonb) returns void language plpgsql security definer set search_path = public as $$
declare v_extra jsonb; v_hidden jsonb;
begin
  perform public.admin_list(p_code);
  if coalesce(trim(p_shop), '') = '' then raise exception 'shop required'; end if;
  select coalesce(jsonb_agg(e), '[]'::jsonb) into v_extra from (
    select e from jsonb_array_elements(case when jsonb_typeof(p_cfg->'extra') = 'array' then p_cfg->'extra' else '[]'::jsonb end) e
    where jsonb_typeof(e) = 'array' and jsonb_array_length(e) >= 3
      and jsonb_typeof(e->0) = 'string' and length(e->>0) between 1 and 60
      and (e->>1) ~ '^\d+(\.\d+)?$' and (e->>1)::numeric > 0 and (e->>1)::numeric <= 2000
      and (e->>2) in ('act','rpg','shoot','horror','sport','fight','fam')
    limit 300) s;
  select coalesce(jsonb_agg(h), '[]'::jsonb) into v_hidden from (
    select h from jsonb_array_elements(case when jsonb_typeof(p_cfg->'hidden') = 'array' then p_cfg->'hidden' else '[]'::jsonb end) h
    where jsonb_typeof(h) = 'string' and length(h #>> '{}') between 1 and 60
    limit 1000) s;
  delete from public.shop_games where lower(regexp_replace(shop, '\s', '', 'g')) = lower(regexp_replace(p_shop, '\s', '', 'g'));
  insert into public.shop_games (shop, cfg) values (p_shop, jsonb_build_object('extra', v_extra, 'hidden', v_hidden));
end;
$$;

grant execute on function public.shop_games_all() to anon, authenticated;
grant execute on function public.shop_games_set(text, text, jsonb) to anon, authenticated;

-- ===== لینک‌های دانلود بخش کامپیوتر (برای همه دیده می‌شود) =====
create table if not exists public.pc_links (game text primary key, links jsonb not null default '[]'::jsonb);
alter table public.pc_links enable row level security;
revoke all on public.pc_links from anon, authenticated;

create or replace function public.pc_links_all() returns jsonb language sql security definer set search_path = public as $$
  select coalesce(jsonb_object_agg(game, links), '{}'::jsonb) from public.pc_links;
$$;

create or replace function public.pc_links_set(p_code text, p_links jsonb) returns void language plpgsql security definer set search_path = public as $$
declare k text; v jsonb;
begin
  perform public.admin_list(p_code);
  if jsonb_typeof(p_links) <> 'object' then raise exception 'bad links'; end if;
  for k, v in select key, value from jsonb_each(p_links) loop
    if length(k) < 1 or length(k) > 80 then continue; end if;
    if jsonb_typeof(v) <> 'array' or jsonb_array_length(v) = 0 then
      delete from public.pc_links where game = k;
    else
      insert into public.pc_links (game, links)
      select k, coalesce(jsonb_agg(e), '[]'::jsonb) from (
        select e from jsonb_array_elements(v) e
        where jsonb_typeof(e) = 'string' and (e #>> '{}') ~ '^https://[^\s"''<>]+$' and length(e #>> '{}') < 600
        limit 100) s
      on conflict (game) do update set links = excluded.links;
    end if;
  end loop;
end;
$$;

grant execute on function public.pc_links_all() to anon, authenticated;
grant execute on function public.pc_links_set(text, jsonb) to anon, authenticated;

-- ===== عکس پروفایل کاربرها (برای نمایش در بخش ادمین) =====
create table if not exists public.player_avatars (pid text primary key, name_key text not null default '', av text not null check (length(av) <= 60000), updated_at timestamptz not null default now());
alter table public.player_avatars enable row level security;
revoke all on public.player_avatars from anon, authenticated;

create or replace function public.set_avatar(p_id text, p_name text, p_av text) returns void language plpgsql security definer set search_path = public as $$
begin
  if p_id is null or length(p_id) < 1 or length(p_id) > 80 then raise exception 'bad id'; end if;
  if p_av is null or p_av = '' then
    delete from public.player_avatars where pid = p_id;
    return;
  end if;
  if length(p_av) > 60000 or p_av !~ '^data:image/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$' then raise exception 'bad avatar'; end if;
  insert into public.player_avatars (pid, name_key, av, updated_at)
  values (p_id, lower(btrim(coalesce(p_name, ''))), p_av, now())
  on conflict (pid) do update set name_key = excluded.name_key, av = excluded.av, updated_at = now();
end;
$$;

create or replace function public.avatars_all(p_code text) returns jsonb language plpgsql security definer set search_path = public as $$
begin
  begin
    perform public.admin_list(p_code);
  exception when others then
    perform public.root_list(p_code);
  end;
  return coalesce((select jsonb_agg(jsonb_build_object('pid', pid, 'name', name_key, 'av', av)) from public.player_avatars), '[]'::jsonb);
end;
$$;

grant execute on function public.set_avatar(text, text, text) to anon, authenticated;
grant execute on function public.avatars_all(text) to anon, authenticated;

notify pgrst, 'reload schema';
