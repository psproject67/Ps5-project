package com.tipaxbot

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var keyEt: EditText
    private lateinit var modelEt: EditText
    private lateinit var pkgView: TextView
    private lateinit var svcView: TextView
    private lateinit var status: TextView
    private lateinit var form: LinearLayout

    private val jobs = ArrayList<LinkedHashMap<String, String>>()
    private var cur = 0
    private val inputs = LinkedHashMap<String, EditText>()
    private var deliverySp: Spinner? = null
    private var typeSp: Spinner? = null

    private val FIELDS = listOf(
        "sender_name" to "فرستنده: نام",
        "sender_family" to "فرستنده: نام خانوادگی",
        "sender_mobile" to "فرستنده: موبایل",
        "sender_postal" to "فرستنده: کد پستی",
        "receiver_name" to "گیرنده: نام",
        "receiver_family" to "گیرنده: نام خانوادگی",
        "receiver_mobile" to "گیرنده: موبایل",
        "receiver_postal" to "گیرنده: کد پستی",
        "receiver_province" to "گیرنده: استان",
        "receiver_city" to "گیرنده: شهر",
        "receiver_nearby" to "شهرهای نزدیک (با , جدا کن)",
        "receiver_street" to "گیرنده: خیابان اصلی",
        "receiver_plate" to "گیرنده: پلاک",
        "receiver_unit" to "گیرنده: واحد",
        "value_rial" to "ارزش مرسوله (ریال) - خالی یعنی ندارد",
        "length_cm" to "طول (cm)",
        "width_cm" to "عرض (cm)",
        "height_cm" to "ارتفاع (cm)",
        "weight_kg" to "وزن (kg)"
    )

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String) = TextView(this).apply {
        text = t
        setPadding(0, dp(10), 0, 0)
    }

    private fun btn(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        val scroll = ScrollView(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(28))
        }
        scroll.addView(col)

        col.addView(TextView(this).apply { text = "Tipax Bot"; textSize = 22f })

        col.addView(label("کلید API کلود"))
        keyEt = EditText(this).apply {
            setText(prefs.getString("key", ""))
            setSingleLine(true)
            hint = "sk-ant-..."
        }
        col.addView(keyEt)

        col.addView(label("مدل"))
        modelEt = EditText(this).apply {
            setText(prefs.getString("model", Extractor.DEFAULT_MODEL))
            setSingleLine(true)
        }
        col.addView(modelEt)

        pkgView = TextView(this).apply { setPadding(0, dp(10), 0, 0) }
        col.addView(pkgView)
        col.addView(btn("انتخاب اپ تیپاکس از لیست برنامه‌ها") { chooseApp() })

        svcView = TextView(this).apply { setPadding(0, dp(10), 0, 0) }
        col.addView(svcView)
        col.addView(btn("تنظیمات Accessibility") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        col.addView(btn("انتخاب عکس(های) برچسب") { pickImages() })

        status = TextView(this).apply { setPadding(0, dp(10), 0, dp(10)) }
        col.addView(status)

        form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(form)

        setContentView(scroll)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
    }

    override fun onResume() {
        super.onResume()
        pkgView.text = "اپ تیپاکس: " + (prefs.getString("pkg", "") ?: "").ifEmpty { "انتخاب نشده" }
        svcView.text = "سرویس Accessibility: " + if (Bridge.service != null) "روشن ✓" else "خاموش ✗"
        if (Bridge.finished) {
            Bridge.finished = false
            if (jobs.isNotEmpty()) {
                cur++
                if (cur < jobs.size) {
                    showJob()
                } else {
                    form.removeAllViews()
                    status.text = "همه‌ی برچسب‌ها تمام شد ✓"
                }
            }
        }
    }

    private fun saveCfg() {
        prefs.edit()
            .putString("key", keyEt.text.toString().trim())
            .putString("model", modelEt.text.toString().trim())
            .apply()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    // ------------------------------------------------------------ choose Tipax app
    private fun chooseApp() {
        val pm = packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(i, 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .distinctBy { it.second }
            .sortedBy { it.first }
        AlertDialog.Builder(this)
            .setTitle("اپ تیپاکس کدومه؟")
            .setItems(apps.map { "${it.first}\n${it.second}" }.toTypedArray()) { _, idx ->
                prefs.edit().putString("pkg", apps[idx].second).apply()
                onResume()
            }
            .show()
    }

    // ------------------------------------------------------------ pick + read photos
    private fun pickImages() {
        saveCfg()
        if (keyEt.text.isBlank()) { toast("اول کلید API را وارد کن"); return }
        val i = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "image/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(Intent.createChooser(i, "عکس برچسب"), 1)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 1 || resultCode != RESULT_OK || data == null) return

        val uris = ArrayList<Uri>()
        val cd = data.clipData
        if (cd != null) {
            for (i in 0 until cd.itemCount) uris.add(cd.getItemAt(i).uri)
        } else {
            data.data?.let { uris.add(it) }
        }
        if (uris.isEmpty()) return

        val key = keyEt.text.toString().trim()
        val model = modelEt.text.toString().trim()
        jobs.clear()
        form.removeAllViews()

        thread {
            for ((i, u) in uris.withIndex()) {
                runOnUiThread { status.text = "در حال خواندن عکس ${i + 1} از ${uris.size}…" }
                try {
                    jobs.add(Extractor.read(this, u, key, model))
                } catch (e: Exception) {
                    runOnUiThread { status.text = "خطا در عکس ${i + 1}: ${e.message}" }
                }
            }
            runOnUiThread {
                if (jobs.isNotEmpty()) {
                    cur = 0
                    status.text = ""
                    showJob()
                }
            }
        }
    }

    // ------------------------------------------------------------ review form
    private fun showJob() {
        form.removeAllViews()
        inputs.clear()
        val f = jobs[cur]

        form.addView(TextView(this).apply {
            text = "برچسب ${cur + 1} از ${jobs.size}  (بررسی و اصلاح کن)"
            textSize = 18f
        })
        for ((k, lab) in FIELDS) {
            form.addView(label(lab))
            val et = EditText(this).apply {
                setText(f[k] ?: "")
                setSingleLine(true)
            }
            inputs[k] = et
            form.addView(et)
        }

        form.addView(label("نوع تحویل گیرنده"))
        deliverySp = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("آدرس گیرنده", "لاکر جابار")
            )
        }
        form.addView(deliverySp)

        form.addView(label("نوع مرسوله"))
        typeSp = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("بسته", "مینی پک", "حجیم و سنگین", "نامتعارف", "پاکات")
            )
        }
        form.addView(typeSp)

        form.addView(btn("شروع ثبت در تیپاکس") { start() })
    }

    private fun start() {
        saveCfg()
        val f = LinkedHashMap<String, String>()
        for ((k, et) in inputs) f[k] = et.text.toString().trim()

        val svc = Bridge.service
        if (svc == null) {
            toast("اول سرویس Accessibility را روشن کن")
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        val pkg = prefs.getString("pkg", "") ?: ""
        if (pkg.isEmpty()) { toast("اپ تیپاکس را انتخاب کن"); return }
        if ((f["sender_mobile"] ?: "").isEmpty() || (f["receiver_mobile"] ?: "").isEmpty()) {
            toast("موبایل فرستنده و گیرنده لازم است")
            return
        }
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        if (launch == null) { toast("اپ تیپاکس پیدا نشد"); return }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)

        val delivery = deliverySp?.selectedItem?.toString() ?: "آدرس گیرنده"
        val ptype = typeSp?.selectedItem?.toString() ?: "بسته"
        svc.startJob(Job(f, delivery, ptype, pkg))
        startActivity(launch)
    }
}
