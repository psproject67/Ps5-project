package com.tipaxbot

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.io.File
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var keyEt: EditText
    private lateinit var modelEt: EditText
    private lateinit var baseEt: EditText
    private lateinit var aiKeyEt: EditText
    private lateinit var aiModelEt: EditText
    private lateinit var pkgView: TextView
    private lateinit var svcView: TextView
    private lateinit var status: TextView
    private lateinit var form: LinearLayout

    private val jobs = ArrayList<LinkedHashMap<String, String>>()
    private var cur = 0
    private val inputs = LinkedHashMap<String, EditText>()
    private var deliverySp: Spinner? = null
    private var typeSp: Spinner? = null

    private val FIELDS = listOf(
        "sender_name" to "فرستنده: نام",
        "sender_family" to "فرستنده: نام خانوادگی",
        "sender_mobile" to "فرستنده: موبایل",
        "sender_postal" to "فرستنده: کد پستی",
        "receiver_name" to "گیرنده: نام",
        "receiver_family" to "گیرنده: نام خانوادگی",
        "receiver_mobile" to "گیرنده: موبایل",
        "receiver_postal" to "گیرنده: کد پستی",
        "receiver_province" to "گیرنده: استان",
        "receiver_city" to "گیرنده: شهر",
        "receiver_nearby" to "شهرهای نزدیک (با , جدا کن)",
        "receiver_street" to "گیرنده: خیابان اصلی",
        "receiver_plate" to "گیرنده: پلاک",
        "receiver_unit" to "گیرنده: واحد",
        "value_rial" to "ارزش مرسوله (ریال) - خالی یعنی ندارد",
        "length_cm" to "طول (cm)",
        "width_cm" to "عرض (cm)",
        "height_cm" to "ارتفاع (cm)",
        "weight_kg" to "وزن (kg)"
    )

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private val BG = Color.parseColor("#0D1117")
    private val CARD = Color.parseColor("#161B22")
    private val STROKE = Color.parseColor("#30363D")
    private val TXT = Color.parseColor("#E6EDF3")
    private val SUB = Color.parseColor("#8B949E")
    private val GREEN = Color.parseColor("#238636")
    private val BTN = Color.parseColor("#21262D")

    private fun box(fill: Int, stroke: Int) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(8).toFloat()
        setStroke(dp(1), stroke)
    }

    private val ACCENT = Color.parseColor("#58A6FF")
    private val OK = Color.parseColor("#3FB950")
    private val BAD = Color.parseColor("#F85149")

    private fun card(title: String) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = box(CARD, STROKE)
        setPadding(dp(14), dp(14), dp(14), dp(14))
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.bottomMargin = dp(12)
        layoutParams = lp
        addView(TextView(this@MainActivity).apply {
            text = title
            textSize = 15f
            setTextColor(ACCENT)
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
    }

    private fun label(t: String) = TextView(this).apply {
        text = t
        setTextColor(SUB)
        textSize = 13f
        setPadding(0, dp(12), 0, dp(4))
    }

    private fun styleField(et: EditText) {
        et.setTextColor(TXT)
        et.setHintTextColor(SUB)
        et.background = box(BG, STROKE)
        et.setPadding(dp(12), dp(10), dp(12), dp(10))
    }

    private fun btn(t: String, primary: Boolean = false, onClick: () -> Unit) = Button(this).apply {
        text = t
        setAllCaps(false)
        setTextColor(Color.WHITE)
        background = box(if (primary) GREEN else BTN, if (primary) GREEN else STROKE)
        setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = dp(8)
        layoutParams = lp
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        val scroll = ScrollView(this).apply { setBackgroundColor(BG) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(28))
        }
        scroll.addView(col)

        col.addView(TextView(this).apply {
            text = "📦 Tipax Bot"
            textSize = 26f
            setTextColor(TXT)
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        col.addView(TextView(this).apply {
            text = "ثبت خودکار مرسوله از روی عکس برچسب"
            textSize = 13f
            setTextColor(SUB)
            setPadding(0, dp(2), 0, dp(18))
        })

        val settingsCard = card("⚙️ تنظیمات")
        settingsCard.addView(label("کلید API (فارسی‌هوش / OpenRouter / Claude)"))
        keyEt = EditText(this).apply {
            setText(prefs.getString("key", ""))
            setSingleLine(true)
            hint = "fh_live_... / sk-or-v1-... / sk-ant-..."
        }
        styleField(keyEt)
        settingsCard.addView(keyEt)
        settingsCard.addView(label("آدرس سرور (اختیاری؛ خالی = OpenRouter/Claude)"))
        baseEt = EditText(this).apply {
            setText(prefs.getString("base", ""))
            setSingleLine(true)
            hint = "https://example.com/v1"
        }
        styleField(baseEt)
        settingsCard.addView(baseEt)
        settingsCard.addView(label("مدل (فارسی‌هوش: bina-0.2-rizeh)"))
        modelEt = EditText(this).apply {
            setText(prefs.getString("model", Extractor.DEFAULT_MODEL))
            setSingleLine(true)
        }
        styleField(modelEt)
        settingsCard.addView(modelEt)
        settingsCard.addView(label("🤖 هوش مصنوعی برای تشخیص فیلدها (اختیاری ولی پیشنهادی)"))
        aiKeyEt = EditText(this).apply {
            setText(prefs.getString("aikey", ""))
            setSingleLine(true)
            hint = "کلید Claude (sk-ant-...) یا OpenRouter (sk-or-...)"
        }
        styleField(aiKeyEt)
        settingsCard.addView(aiKeyEt)
        settingsCard.addView(label("مدل هوش مصنوعی (خالی = پیش‌فرض)"))
        aiModelEt = EditText(this).apply {
            setText(prefs.getString("aimodel", ""))
            setSingleLine(true)
        }
        styleField(aiModelEt)
        settingsCard.addView(aiModelEt)
        col.addView(settingsCard)

        val linkCard = card("🔗 اتصال به تیپاکس")
        pkgView = TextView(this).apply { setPadding(0, dp(10), 0, 0); setTextColor(TXT) }
        linkCard.addView(pkgView)
        linkCard.addView(btn("انتخاب اپ تیپاکس از لیست برنامه‌ها") { chooseApp() })
        svcView = TextView(this).apply { setPadding(0, dp(14), 0, 0); setTextColor(TXT) }
        linkCard.addView(svcView)
        linkCard.addView(btn("تنظیمات Accessibility") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(linkCard)

        col.addView(btn("📷 گرفتن عکس برچسب با دوربین", true) { takePhoto() })

        status = TextView(this).apply { setPadding(0, dp(12), 0, dp(12)); setTextColor(SUB) }
        col.addView(status)

        form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(form)

        setContentView(scroll)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
    }

    override fun onResume() {
        super.onResume()
        pkgView.text = "اپ تیپاکس: " + (prefs.getString("pkg", "") ?: "").ifEmpty { "انتخاب نشده" }
        val on = Bridge.service != null
        svcView.text = "سرویس Accessibility: " + if (on) "روشن ✓" else "خاموش ✗"
        svcView.setTextColor(if (on) OK else BAD)
        if (Bridge.finished) {
            Bridge.finished = false
            if (jobs.isNotEmpty()) {
                cur++
                if (cur < jobs.size) {
                    showJob()
                } else {
                    form.removeAllViews()
                    status.text = "همه‌ی برچسب‌ها تمام شد ✓"
                }
            }
        }
    }

    private fun saveCfg() {
        prefs.edit()
            .putString("key", keyEt.text.toString().trim())
            .putString("model", modelEt.text.toString().trim())
            .putString("base", baseEt.text.toString().trim())
            .putString("aikey", aiKeyEt.text.toString().trim())
            .putString("aimodel", aiModelEt.text.toString().trim())
            .apply()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    // ------------------------------------------------------------ choose Tipax app
    private fun chooseApp() {
        val pm = packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(i, 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .distinctBy { it.second }
            .sortedBy { it.first }
        AlertDialog.Builder(this)
            .setTitle("اپ تیپاکس کدومه؟")
            .setItems(apps.map { "${it.first}\n${it.second}" }.toTypedArray()) { _, idx ->
                prefs.edit().putString("pkg", apps[idx].second).apply()
                onResume()
            }
            .show()
    }

    // ------------------------------------------------------------ camera + read photo
    private fun takePhoto() {
        saveCfg()
        if (keyEt.text.isBlank()) { toast("اول کلید API را وارد کن"); return }
        val name = "label_${System.currentTimeMillis()}.jpg"
        File(cacheDir, "capture").mkdirs()
        val uri = Uri.parse("content://com.tipaxbot.capture/$name")
        prefs.edit().putString("cap_name", name).apply()
        val i = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
            putExtra(MediaStore.EXTRA_OUTPUT, uri)
            addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            clipData = ClipData.newRawUri("", uri)
        }
        try {
            startActivityForResult(i, 1)
        } catch (e: ActivityNotFoundException) {
            toast("برنامه‌ی دوربین پیدا نشد")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 1 || resultCode != RESULT_OK) return

        val name = prefs.getString("cap_name", "") ?: ""
        val file = File(File(cacheDir, "capture"), name)
        if (name.isEmpty() || !file.exists() || file.length() == 0L) { toast("عکس ذخیره نشد؛ دوباره بگیر"); return }
        val uri = Uri.parse("content://com.tipaxbot.capture/$name")

        val key = keyEt.text.toString().trim()
        val model = modelEt.text.toString().trim()
        val base = baseEt.text.toString().trim()
        val aiKey = aiKeyEt.text.toString().trim()
        val aiModel = aiModelEt.text.toString().trim()

        status.text = "در حال خواندن عکس…"
        thread {
            try {
                val job = Extractor.read(this, uri, key, model, base, aiKey, aiModel)
                runOnUiThread {
                    jobs.add(job)
                    cur = jobs.size - 1
                    status.text = ""
                    showJob()
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "خطا در خواندن عکس: ${e.message}" }
            } finally {
                file.delete()
            }
        }
    }

    // ------------------------------------------------------------ AI spell check
    private fun spellCheck() {
        val aiKey = aiKeyEt.text.toString().trim().ifBlank {
            val k = keyEt.text.toString().trim()
            if (FarsiHoosh.isFarsiHoosh(k, baseEt.text.toString().trim())) "" else k
        }
        if (aiKey.isEmpty()) { toast("کلید هوش مصنوعی (Claude یا OpenRouter) را در تنظیمات بزن"); return }
        val aiModel = aiModelEt.text.toString().trim()
        val cur0 = cur
        val vals = LinkedHashMap<String, String>()
        for ((k, et) in inputs) vals[k] = et.text.toString().trim()

        status.text = "در حال غلط‌یابی املایی…"
        thread {
            try {
                val fixed = Extractor.spellFix(vals, aiKey, aiModel)
                runOnUiThread {
                    status.text = ""
                    if (cur != cur0) return@runOnUiThread
                    val changes = ArrayList<String>()
                    for ((k, nv) in fixed) {
                        val et = inputs[k] ?: continue
                        val old = et.text.toString().trim()
                        if (nv.isNotEmpty() && nv != old) {
                            et.setText(nv)
                            et.background = box(BG, OK)
                            changes.add("$old  ←  $nv")
                        }
                    }
                    if (changes.isEmpty()) toast("غلط املایی پیدا نشد ✓")
                    else AlertDialog.Builder(this)
                        .setTitle("${changes.size} مورد اصلاح شد")
                        .setMessage(changes.joinToString("\n"))
                        .setPositiveButton("باشه", null)
                        .show()
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "غلط‌یابی ناموفق: ${e.message}" }
            }
        }
    }

    // ------------------------------------------------------------ review form
    private fun showJob() {
        form.removeAllViews()
        inputs.clear()
        val f = jobs[cur]

        form.addView(TextView(this).apply {
            text = "برچسب ${cur + 1} از ${jobs.size}"
            textSize = 18f
            setTextColor(TXT)
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        form.addView(TextView(this).apply {
            text = "اطلاعات خوانده‌شده را بررسی و اصلاح کن"
            textSize = 13f
            setTextColor(SUB)
            setPadding(0, dp(2), 0, dp(14))
        })

        val groups = listOf(
            "👤 فرستنده" to listOf("sender_name", "sender_family", "sender_mobile"),
            "📍 گیرنده" to listOf("receiver_name", "receiver_family", "receiver_mobile"),
            "🏠 آدرس گیرنده" to listOf(
                "receiver_province", "receiver_city", "receiver_nearby",
                "receiver_street", "receiver_plate", "receiver_unit"
            ),
            "📦 مرسوله" to listOf("value_rial", "length_cm", "width_cm", "height_cm", "weight_kg")
        )
        val names = FIELDS.toMap()
        for ((title, keys) in groups) {
            val c = card(title)
            for (k in keys) {
                c.addView(label((names[k] ?: k).substringAfter(": ")))
                val et = EditText(this).apply {
                    setText(f[k] ?: "")
                    setSingleLine(true)
                }
                styleField(et)
                if (k.endsWith("_mobile") || k.endsWith("_postal")) {
                    et.inputType = android.text.InputType.TYPE_CLASS_PHONE
                }
                inputs[k] = et
                c.addView(et)
            }
            form.addView(c)
        }

        f["_ai_error"]?.let { e ->
            form.addView(TextView(this).apply { text = "⚠️ $e"; setTextColor(BAD); setPadding(0, 0, 0, dp(10)) })
        }
        val raw = f["_raw"]
        if (raw != null) {
            val rc = card("🔎 متن خام خوانده‌شده (OCR)")
            val rawEt = EditText(this).apply {
                setText(raw)
                minLines = 4
                gravity = android.view.Gravity.TOP or android.view.Gravity.START
            }
            styleField(rawEt)
            rc.addView(rawEt)
            rc.addView(btn("تحلیل دوباره‌ی متن (بعد از اصلاح)") {
                val nf = Extractor.fromText(rawEt.text.toString())
                nf["_raw"] = rawEt.text.toString()
                jobs[cur] = nf
                showJob()
            })
            form.addView(rc)
        }

        form.addView(btn("✨ غلط‌یابی املایی با هوش مصنوعی") { spellCheck() })

        val optCard = card("🚚 نوع ارسال")
        optCard.addView(label("نوع تحویل گیرنده"))
        deliverySp = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("آدرس گیرنده", "لاکر جابار")
            )
        }
        optCard.addView(deliverySp)
        optCard.addView(label("نوع مرسوله"))
        typeSp = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("بسته", "مینی پک", "حجیم و سنگین", "نامتعارف", "پاکت")
            )
        }
        optCard.addView(typeSp)
        form.addView(optCard)

        form.addView(btn("🚀 شروع ثبت در تیپاکس", true) { start() })
    }

    private fun start() {
        saveCfg()
        val f = LinkedHashMap<String, String>()
        for ((k, et) in inputs) f[k] = et.text.toString().trim()

        val svc = Bridge.service
        if (svc == null) {
            toast("اول سرویس Accessibility را روشن کن")
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        val pkg = prefs.getString("pkg", "") ?: ""
        if (pkg.isEmpty()) { toast("اپ تیپاکس را انتخاب کن"); return }
        if ((f["sender_mobile"] ?: "").isEmpty() || (f["receiver_mobile"] ?: "").isEmpty()) {
            toast("موبایل فرستنده و گیرنده لازم است")
            return
        }
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        if (launch == null) { toast("اپ تیپاکس پیدا نشد"); return }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)

        val delivery = deliverySp?.selectedItem?.toString() ?: "آدرس گیرنده"
        val ptype = typeSp?.selectedItem?.toString() ?: "بسته"
        svc.startJob(Job(f, delivery, ptype, pkg))
        startActivity(launch)
    }
}
