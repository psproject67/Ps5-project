const { app, BrowserWindow, shell, Menu } = require("electron");
const path = require("path");
function create() {
  const w = new BrowserWindow({
    width: 1100, height: 800, minWidth: 380, minHeight: 600,
    backgroundColor: "#070b14", title: "انتخاب بازی PS5",
    icon: path.join(__dirname, "build", "icon.png"),
    webPreferences: { contextIsolation: true, sandbox: true, nodeIntegration: false }
  });
  Menu.setApplicationMenu(null);
  w.loadFile(path.join(__dirname, "www", "index.html"));
  w.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: "deny" }; });
  w.webContents.on("will-navigate", (e, url) => { if (!url.startsWith("file:")) { e.preventDefault(); shell.openExternal(url); } });
}
app.whenReady().then(create);
app.on("window-all-closed", () => { if (process.platform !== "darwin") app.quit(); });
app.on("activate", () => { if (!BrowserWindow.getAllWindows().length) create(); });
