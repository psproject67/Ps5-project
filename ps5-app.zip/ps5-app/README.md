# انتخاب بازی PS5 — وب، موبایل، دسکتاپ

یک کد (`www/index.html`) برای هر سه پلتفرم.

## وب (PWA)
پوشه‌ی `www` را روی هر هاستی آپلود کنید (Netlify، Vercel، GitHub Pages، ...).
روی گوشی از منوی مرورگر «Add to Home Screen» بزنید تا مثل اپ نصب شود و آفلاین هم باز شود.
تست محلی: `npm install` و بعد `npm run web`

## دسکتاپ (ویندوز / مک / لینوکس)
```
npm install
npm run desktop          # اجرای مستقیم
npm run desktop:build    # ساخت فایل نصبی در پوشه dist
```
(فایل نصبی هر سیستم‌عامل را باید روی همان سیستم‌عامل ساخت — یا از GitHub Actions استفاده کنید.)

## موبایل (اندروید / iOS)
```
npm install
npx cap add android      # و/یا: npx cap add ios
npx cap sync
npx cap open android     # باز شدن در Android Studio → Build APK
npx cap open ios         # فقط روی مک، با Xcode
```

## ساخت خودکار بدون نصب هیچ‌چیز
پروژه را در یک ریپوی GitHub بگذارید؛ workflow داخل `.github/workflows/build.yml`
فایل‌های exe / dmg / AppImage / apk را می‌سازد (تب Actions → Artifacts).

## تنظیم سرور (Supabase) برای قیمت و اطلاعات شاپ‌ها
فایل `supabase-setup.sql` را یک بار در Supabase ← SQL Editor اجرا کنید (کامل، بدون انتخاب بخشی از متن).
این فایل جدول و تابع‌های قیمت‌ها و اطلاعات/آدرس شاپ‌ها را می‌سازد و چند بار اجرا کردنش مشکلی ندارد.
نام ادمین‌های جدید را در `www/index.html` در متغیر `EXTRA_ADMINS` اضافه کنید.
