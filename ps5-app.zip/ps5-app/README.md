# انتخاب بازی PS5 — وب، موبایل، دسکتاپ

یک کد (`www/index.html`) برای هر سه پلتفرم.

## وب (PWA)
پوشه‌ی `www` را روی هر هاستی آپلود کنید (Netlify، Vercel، GitHub Pages، ...).
روی گوشی از منوی مرورگر «Add to Home Screen» بزنید تا مثل اپ نصب شود و آفلاین هم باز شود.
تست محلی: `npm install` و بعد `npm run web`

## دسکتاپ (ویندوز / مک / لینوکس)
```
npm install
npm run desktop          # اجرای مستقیم
npm run desktop:build    # ساخت فایل نصبی در پوشه dist
```
(فایل نصبی هر سیستم‌عامل را باید روی همان سیستم‌عامل ساخت — یا از GitHub Actions استفاده کنید.)

## موبایل (اندروید / iOS)
```
npm install
npx cap add android      # و/یا: npx cap add ios
npx cap sync
npx cap open android     # باز شدن در Android Studio → Build APK
npx cap open ios         # فقط روی مک، با Xcode
```

## ساخت خودکار بدون نصب هیچ‌چیز
پروژه را در یک ریپوی GitHub بگذارید؛ workflow داخل `.github/workflows/build.yml`
فایل‌های exe / dmg / AppImage / apk را می‌سازد (تب Actions → Artifacts).
