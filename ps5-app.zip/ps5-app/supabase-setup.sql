-- ===== جدول‌ها =====
create table if not exists public.shop_prices (shop text not null, game text not null, price bigint not null check (price > 0 and price <= 1000000000), primary key (shop, game));
create table if not exists public.shop_info (shop text primary key, info jsonb not null default '{}'::jsonb);

alter table public.shop_prices enable row level security;
alter table public.shop_info enable row level security;
revoke all on public.shop_prices from anon, authenticated;
revoke all on public.shop_info from anon, authenticated;

-- ===== قیمت‌ها =====
create or replace function public.shop_list() returns jsonb language sql security definer set search_path = public as $$
  select coalesce(jsonb_agg(distinct shop), '[]'::jsonb) from public.shop_prices;
$$;

create or replace function public.shop_prices_get(p_shop text) returns jsonb language sql security definer set search_path = public as $$
  select coalesce(jsonb_object_agg(game, price), '{}'::jsonb) from public.shop_prices
  where lower(regexp_replace(shop, '\s', '', 'g')) = lower(regexp_replace(coalesce(p_shop, ''), '\s', '', 'g'));
$$;

create or replace function public.shop_prices_set(p_code text, p_shop text, p_prices jsonb) returns void language plpgsql security definer set search_path = public as $$
begin
  perform public.admin_list(p_code);
  if coalesce(trim(p_shop), '') = '' then raise exception 'shop required'; end if;
  delete from public.shop_prices where lower(regexp_replace(shop, '\s', '', 'g')) = lower(regexp_replace(p_shop, '\s', '', 'g'));
  insert into public.shop_prices (shop, game, price)
  select p_shop, key, value::bigint from jsonb_each_text(coalesce(p_prices, '{}'::jsonb))
  where value ~ '^\d+$' and value::numeric > 0 and value::numeric <= 1000000000;
end;
$$;

-- ===== اطلاعات و آدرس شاپ =====
create or replace function public.shop_info_all() returns jsonb language sql security definer set search_path = public as $$
  select coalesce(jsonb_object_agg(shop, info), '{}'::jsonb) from public.shop_info;
$$;

create or replace function public.shop_info_set(p_code text, p_shop text, p_info jsonb) returns void language plpgsql security definer set search_path = public as $$
begin
  perform public.admin_list(p_code);
  if coalesce(trim(p_shop), '') = '' then raise exception 'shop required'; end if;
  delete from public.shop_info where lower(regexp_replace(shop, '\s', '', 'g')) = lower(regexp_replace(p_shop, '\s', '', 'g'));
  insert into public.shop_info (shop, info) values (p_shop, jsonb_build_object(
    'addr',  left(coalesce(p_info->>'addr',  ''), 300),
    'tel',   left(coalesce(p_info->>'tel',   ''), 40),
    'hours', left(coalesce(p_info->>'hours', ''), 60),
    'note',  left(coalesce(p_info->>'note',  ''), 200)));
end;
$$;

-- ===== دسترسی‌ها =====
grant execute on function public.shop_list() to anon, authenticated;
grant execute on function public.shop_prices_get(text) to anon, authenticated;
grant execute on function public.shop_prices_set(text, text, jsonb) to anon, authenticated;
grant execute on function public.shop_info_all() to anon, authenticated;
grant execute on function public.shop_info_set(text, text, jsonb) to anon, authenticated;

-- ===== بازی‌های اختصاصی هر شاپ (افزودن بازی + غیرفعال کردن بازی) =====
create table if not exists public.shop_games (shop text primary key, cfg jsonb not null default '{}'::jsonb);
alter table public.shop_games enable row level security;
revoke all on public.shop_games from anon, authenticated;

create or replace function public.shop_games_all() returns jsonb language sql security definer set search_path = public as $$
  select coalesce(jsonb_object_agg(shop, cfg), '{}'::jsonb) from public.shop_games;
$$;

create or replace function public.shop_games_set(p_code text, p_shop text, p_cfg jsonb) returns void language plpgsql security definer set search_path = public as $$
declare v_extra jsonb; v_hidden jsonb;
begin
  perform public.admin_list(p_code);
  if coalesce(trim(p_shop), '') = '' then raise exception 'shop required'; end if;
  select coalesce(jsonb_agg(e), '[]'::jsonb) into v_extra from (
    select e from jsonb_array_elements(case when jsonb_typeof(p_cfg->'extra') = 'array' then p_cfg->'extra' else '[]'::jsonb end) e
    where jsonb_typeof(e) = 'array' and jsonb_array_length(e) >= 3
      and jsonb_typeof(e->0) = 'string' and length(e->>0) between 1 and 60
      and (e->>1) ~ '^\d+(\.\d+)?$' and (e->>1)::numeric > 0 and (e->>1)::numeric <= 2000
      and (e->>2) in ('act','rpg','shoot','horror','sport','fight','fam')
    limit 300) s;
  select coalesce(jsonb_agg(h), '[]'::jsonb) into v_hidden from (
    select h from jsonb_array_elements(case when jsonb_typeof(p_cfg->'hidden') = 'array' then p_cfg->'hidden' else '[]'::jsonb end) h
    where jsonb_typeof(h) = 'string' and length(h #>> '{}') between 1 and 60
    limit 1000) s;
  delete from public.shop_games where lower(regexp_replace(shop, '\s', '', 'g')) = lower(regexp_replace(p_shop, '\s', '', 'g'));
  insert into public.shop_games (shop, cfg) values (p_shop, jsonb_build_object('extra', v_extra, 'hidden', v_hidden));
end;
$$;

grant execute on function public.shop_games_all() to anon, authenticated;
grant execute on function public.shop_games_set(text, text, jsonb) to anon, authenticated;

notify pgrst, 'reload schema';
